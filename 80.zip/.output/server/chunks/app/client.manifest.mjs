const client_manifest = {
  "Overlay.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Overlay.0615543b.css",
    "src": "Overlay.css"
  },
  "_Button.54a2de84.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Button.54a2de84.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_Overlay.a7dadf92.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Overlay.0615543b.css"
    ],
    "file": "Overlay.a7dadf92.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "Overlay.0615543b.css": {
    "file": "Overlay.0615543b.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_Product.vue.b46ee9b1.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Product.vue.b46ee9b1.js",
    "imports": [
      "_nuxt-icon.vue.bd722602.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_Sidebar.299d433c.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "assets": [
      "admin.2f3cd8c5.svg",
      "dashboard.d3a58301.svg",
      "groups.877e08d9.svg"
    ],
    "file": "Sidebar.299d433c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "admin.2f3cd8c5.svg": {
    "file": "admin.2f3cd8c5.svg",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml"
  },
  "dashboard.d3a58301.svg": {
    "file": "dashboard.d3a58301.svg",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml"
  },
  "groups.877e08d9.svg": {
    "file": "groups.877e08d9.svg",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml"
  },
  "_notifications.e9c50c29.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "assets": [
      "search.f0317912.svg",
      "notifications.830bd8c2.svg"
    ],
    "file": "notifications.e9c50c29.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "search.f0317912.svg": {
    "file": "search.f0317912.svg",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml"
  },
  "notifications.830bd8c2.svg": {
    "file": "notifications.830bd8c2.svg",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml"
  },
  "_nuxt-icon.vue.bd722602.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "nuxt-icon.4544dae2.css"
    ],
    "dynamicImports": [
      "assets/icons/bell.svg?raw",
      "assets/icons/check_circle.svg?raw",
      "assets/icons/close.svg?raw",
      "assets/icons/e_wallet.svg?raw",
      "assets/icons/email.svg?raw",
      "assets/icons/eye.svg?raw",
      "assets/icons/facebook.svg?raw",
      "assets/icons/favorite.svg?raw",
      "assets/icons/google.svg?raw",
      "assets/icons/info.svg?raw",
      "assets/icons/instagram.svg?raw",
      "assets/icons/lock.svg?raw",
      "assets/icons/logout.svg?raw",
      "assets/icons/moon.svg?raw",
      "assets/icons/people.svg?raw",
      "assets/icons/person.svg?raw",
      "assets/icons/search.svg?raw",
      "assets/icons/share.svg?raw",
      "assets/icons/shopping_cart.svg?raw",
      "assets/icons/sun.svg?raw",
      "assets/icons/verified.svg?raw"
    ],
    "file": "nuxt-icon.vue.bd722602.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "nuxt-icon.4544dae2.css": {
    "file": "nuxt-icon.4544dae2.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_nuxt-link.095d38ce.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "nuxt-link.095d38ce.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_slank.67a5c43f.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "slank.67a5c43f.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_useAuth.22e295fd.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useAuth.22e295fd.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "assets/icons/bell.svg?raw": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "bell.a6aa0acd.js",
    "isDynamicEntry": true,
    "src": "assets/icons/bell.svg?raw"
  },
  "assets/icons/check_circle.svg?raw": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "check_circle.7e3b5463.js",
    "isDynamicEntry": true,
    "src": "assets/icons/check_circle.svg?raw"
  },
  "assets/icons/close.svg?raw": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "close.ea3fcbd3.js",
    "isDynamicEntry": true,
    "src": "assets/icons/close.svg?raw"
  },
  "assets/icons/e_wallet.svg?raw": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "e_wallet.7d6bd715.js",
    "isDynamicEntry": true,
    "src": "assets/icons/e_wallet.svg?raw"
  },
  "assets/icons/email.svg?raw": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "email.2254005e.js",
    "isDynamicEntry": true,
    "src": "assets/icons/email.svg?raw"
  },
  "assets/icons/eye.svg?raw": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "eye.48a3d3cd.js",
    "isDynamicEntry": true,
    "src": "assets/icons/eye.svg?raw"
  },
  "assets/icons/facebook.svg": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml",
    "file": "facebook.a8b27b68.svg",
    "src": "assets/icons/facebook.svg"
  },
  "assets/icons/facebook.svg?raw": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "facebook.2c7f7a47.js",
    "isDynamicEntry": true,
    "src": "assets/icons/facebook.svg?raw"
  },
  "assets/icons/favorite.svg?raw": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "favorite.d04fd693.js",
    "isDynamicEntry": true,
    "src": "assets/icons/favorite.svg?raw"
  },
  "assets/icons/google.svg": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml",
    "file": "google.0d6251f6.svg",
    "src": "assets/icons/google.svg"
  },
  "assets/icons/google.svg?raw": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "google.691405ac.js",
    "isDynamicEntry": true,
    "src": "assets/icons/google.svg?raw"
  },
  "assets/icons/info.svg?raw": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "info.566c4558.js",
    "isDynamicEntry": true,
    "src": "assets/icons/info.svg?raw"
  },
  "assets/icons/instagram.svg": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml",
    "file": "instagram.5829a46a.svg",
    "src": "assets/icons/instagram.svg"
  },
  "assets/icons/instagram.svg?raw": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "instagram.8866fcb8.js",
    "isDynamicEntry": true,
    "src": "assets/icons/instagram.svg?raw"
  },
  "assets/icons/lock.svg?raw": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "lock.c2b05d0c.js",
    "isDynamicEntry": true,
    "src": "assets/icons/lock.svg?raw"
  },
  "assets/icons/logout.svg?raw": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "logout.2a6b6e88.js",
    "isDynamicEntry": true,
    "src": "assets/icons/logout.svg?raw"
  },
  "assets/icons/moon.svg?raw": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "moon.ea1f9778.js",
    "isDynamicEntry": true,
    "src": "assets/icons/moon.svg?raw"
  },
  "assets/icons/people.svg?raw": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "people.aa46e011.js",
    "isDynamicEntry": true,
    "src": "assets/icons/people.svg?raw"
  },
  "assets/icons/person.svg?raw": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "person.fefeba4e.js",
    "isDynamicEntry": true,
    "src": "assets/icons/person.svg?raw"
  },
  "assets/icons/search.svg?raw": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "search.46dd21e0.js",
    "isDynamicEntry": true,
    "src": "assets/icons/search.svg?raw"
  },
  "assets/icons/share.svg?raw": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "share.01c4c0a3.js",
    "isDynamicEntry": true,
    "src": "assets/icons/share.svg?raw"
  },
  "assets/icons/shopping_cart.svg?raw": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "shopping_cart.142fba0a.js",
    "isDynamicEntry": true,
    "src": "assets/icons/shopping_cart.svg?raw"
  },
  "assets/icons/sun.svg?raw": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sun.8a0cb529.js",
    "isDynamicEntry": true,
    "src": "assets/icons/sun.svg?raw"
  },
  "assets/icons/verified.svg?raw": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "verified.79137c13.js",
    "isDynamicEntry": true,
    "src": "assets/icons/verified.svg?raw"
  },
  "layouts/admin.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "admin.e32f8e61.js",
    "imports": [
      "_Sidebar.299d433c.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/admin.vue"
  },
  "layouts/default.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "default.7c897e69.css",
    "src": "layouts/default.css"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "assets": [
      "google.0d6251f6.svg",
      "facebook.a8b27b68.svg",
      "instagram.5829a46a.svg"
    ],
    "css": [],
    "file": "default.241bf034.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.095d38ce.js",
      "_Button.54a2de84.js",
      "_nuxt-icon.vue.bd722602.js",
      "_useAuth.22e295fd.js",
      "_Overlay.a7dadf92.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/default.vue"
  },
  "default.7c897e69.css": {
    "file": "default.7c897e69.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "google.0d6251f6.svg": {
    "file": "google.0d6251f6.svg",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml"
  },
  "facebook.a8b27b68.svg": {
    "file": "facebook.a8b27b68.svg",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml"
  },
  "instagram.5829a46a.svg": {
    "file": "instagram.5829a46a.svg",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "error-404.7fc72018.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "error-404.ee9cd6cd.js",
    "imports": [
      "_nuxt-link.095d38ce.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.7fc72018.css": {
    "file": "error-404.7fc72018.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "error-500.c5df6088.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "error-500.dcdec5d9.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.c5df6088.css": {
    "file": "error-500.c5df6088.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt-icons/dist/runtime/components/nuxt-icon.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "nuxt-icon.cc5e2d9a.js",
    "imports": [
      "_nuxt-icon.vue.bd722602.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/nuxt-icons/dist/runtime/components/nuxt-icon.vue"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "dynamicImports": [
      "layouts/admin.vue",
      "layouts/default.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "entry.bf5c5252.js",
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js",
    "_globalCSS": true
  },
  "nuxt-icon.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "nuxt-icon.4544dae2.css",
    "src": "nuxt-icon.css"
  },
  "pages/AboutUs.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "AboutUs.b417dc2e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/AboutUs.vue"
  },
  "pages/BuatLelangBaru.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "assets": [
      "select.0914e967.svg",
      "addphoto.cca01a4e.svg",
      "info.08d25ef0.svg"
    ],
    "file": "BuatLelangBaru.94dcd74f.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/BuatLelangBaru.vue"
  },
  "select.0914e967.svg": {
    "file": "select.0914e967.svg",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml"
  },
  "addphoto.cca01a4e.svg": {
    "file": "addphoto.cca01a4e.svg",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml"
  },
  "info.08d25ef0.svg": {
    "file": "info.08d25ef0.svg",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml"
  },
  "pages/Dashboard.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Dashboard.f8be3fbd.css",
    "src": "pages/Dashboard.css"
  },
  "pages/Dashboard.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "assets": [
      "description.12b34ef1.svg",
      "receipt.efbe20ba.svg",
      "check.0f57471f.svg",
      "volunter.2a11694c.svg"
    ],
    "css": [],
    "file": "Dashboard.cd578c43.js",
    "imports": [
      "_Sidebar.299d433c.js",
      "_notifications.e9c50c29.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/Dashboard.vue"
  },
  "Dashboard.f8be3fbd.css": {
    "file": "Dashboard.f8be3fbd.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "description.12b34ef1.svg": {
    "file": "description.12b34ef1.svg",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml"
  },
  "receipt.efbe20ba.svg": {
    "file": "receipt.efbe20ba.svg",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml"
  },
  "check.0f57471f.svg": {
    "file": "check.0f57471f.svg",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml"
  },
  "volunter.2a11694c.svg": {
    "file": "volunter.2a11694c.svg",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml"
  },
  "pages/Mitra.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Mitra.f63df422.css",
    "src": "pages/Mitra.css"
  },
  "pages/Mitra.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "Mitra.80e42693.js",
    "imports": [
      "_Sidebar.299d433c.js",
      "_notifications.e9c50c29.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/Mitra.vue"
  },
  "Mitra.f63df422.css": {
    "file": "Mitra.f63df422.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/Pengaturan.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Pengaturan.5c34219d.css",
    "src": "pages/Pengaturan.css"
  },
  "pages/Pengaturan.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "Pengaturan.47791dcc.js",
    "imports": [
      "_Sidebar.299d433c.js",
      "_notifications.e9c50c29.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/Pengaturan.vue"
  },
  "Pengaturan.5c34219d.css": {
    "file": "Pengaturan.5c34219d.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/PenjualanSaya.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "PenjualanSaya.59eaf0dd.css",
    "src": "pages/PenjualanSaya.css"
  },
  "pages/PenjualanSaya.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "PenjualanSaya.50c6414d.js",
    "imports": [
      "_Overlay.a7dadf92.js",
      "_useAuth.22e295fd.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/PenjualanSaya.vue"
  },
  "PenjualanSaya.59eaf0dd.css": {
    "file": "PenjualanSaya.59eaf0dd.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/Transaksi.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Transaksi.a2a285e4.css",
    "src": "pages/Transaksi.css"
  },
  "pages/Transaksi.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "Transaksi.36e5c14f.js",
    "imports": [
      "_useAuth.22e295fd.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/Transaksi.vue"
  },
  "Transaksi.a2a285e4.css": {
    "file": "Transaksi.a2a285e4.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/Verifikasi.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Verifikasi.5ddb9afd.css",
    "src": "pages/Verifikasi.css"
  },
  "pages/Verifikasi.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "Verifikasi.c716d43e.js",
    "imports": [
      "_Sidebar.299d433c.js",
      "_notifications.e9c50c29.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/Verifikasi.vue"
  },
  "Verifikasi.5ddb9afd.css": {
    "file": "Verifikasi.5ddb9afd.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/favorite.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "favorite.a9c43ea5.css",
    "src": "pages/favorite.css"
  },
  "pages/favorite.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "favorite.482030ac.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/favorite.vue"
  },
  "favorite.a9c43ea5.css": {
    "file": "favorite.a9c43ea5.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.6ce491ee.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.9ca07dc9.js",
    "imports": [
      "_nuxt-icon.vue.bd722602.js",
      "_Product.vue.b46ee9b1.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.6ce491ee.css": {
    "file": "index.6ce491ee.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/product/[id].css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "_id_.a04d6461.css",
    "src": "pages/product/[id].css"
  },
  "pages/product/[id].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "_id_.6098b1b5.js",
    "imports": [
      "_nuxt-link.095d38ce.js",
      "_nuxt-icon.vue.bd722602.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_Button.54a2de84.js",
      "_slank.67a5c43f.js",
      "_Product.vue.b46ee9b1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/product/[id].vue"
  },
  "_id_.a04d6461.css": {
    "file": "_id_.a04d6461.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/story.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "story.a5755279.css",
    "src": "pages/story.css"
  },
  "pages/story.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "story.a0616a25.js",
    "imports": [
      "_nuxt-icon.vue.bd722602.js",
      "_slank.67a5c43f.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/story.vue"
  },
  "story.a5755279.css": {
    "file": "story.a5755279.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "public/icons/addphoto.svg": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml",
    "file": "addphoto.cca01a4e.svg",
    "src": "public/icons/addphoto.svg"
  },
  "public/icons/admin.svg": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml",
    "file": "admin.2f3cd8c5.svg",
    "src": "public/icons/admin.svg"
  },
  "public/icons/check.svg": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml",
    "file": "check.0f57471f.svg",
    "src": "public/icons/check.svg"
  },
  "public/icons/dashboard.svg": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml",
    "file": "dashboard.d3a58301.svg",
    "src": "public/icons/dashboard.svg"
  },
  "public/icons/description.svg": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml",
    "file": "description.12b34ef1.svg",
    "src": "public/icons/description.svg"
  },
  "public/icons/groups.svg": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml",
    "file": "groups.877e08d9.svg",
    "src": "public/icons/groups.svg"
  },
  "public/icons/info.svg": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml",
    "file": "info.08d25ef0.svg",
    "src": "public/icons/info.svg"
  },
  "public/icons/notifications.svg": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml",
    "file": "notifications.830bd8c2.svg",
    "src": "public/icons/notifications.svg"
  },
  "public/icons/receipt.svg": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml",
    "file": "receipt.efbe20ba.svg",
    "src": "public/icons/receipt.svg"
  },
  "public/icons/search.svg": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml",
    "file": "search.f0317912.svg",
    "src": "public/icons/search.svg"
  },
  "public/icons/select.svg": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml",
    "file": "select.0914e967.svg",
    "src": "public/icons/select.svg"
  },
  "public/icons/volunter.svg": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml",
    "file": "volunter.2a11694c.svg",
    "src": "public/icons/volunter.svg"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
