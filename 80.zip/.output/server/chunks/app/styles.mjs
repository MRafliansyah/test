const interopDefault = r => r.default || r || [];
const styles = {
  "node_modules/nuxt/dist/app/entry.js": () => import('./_nuxt/entry-styles.881f2f95.mjs').then(interopDefault),
  "pages/Mitra.vue": () => import('./_nuxt/Mitra-styles.6e48f8e2.mjs').then(interopDefault),
  "pages/Dashboard.vue": () => import('./_nuxt/Dashboard-styles.9501aaaa.mjs').then(interopDefault),
  "pages/Transaksi.vue": () => import('./_nuxt/Transaksi-styles.f9343f19.mjs').then(interopDefault),
  "pages/Verifikasi.vue": () => import('./_nuxt/Verifikasi-styles.4f5c4e8b.mjs').then(interopDefault),
  "pages/favorite.vue": () => import('./_nuxt/favorite-styles.a4d85bef.mjs').then(interopDefault),
  "pages/index.vue": () => import('./_nuxt/index-styles.f310ac3b.mjs').then(interopDefault),
  "pages/Pengaturan.vue": () => import('./_nuxt/Pengaturan-styles.bba1bebd.mjs').then(interopDefault),
  "pages/PenjualanSaya.vue": () => import('./_nuxt/PenjualanSaya-styles.9ac42c2d.mjs').then(interopDefault),
  "pages/story.vue": () => import('./_nuxt/story-styles.7908fdb4.mjs').then(interopDefault),
  "pages/product/[id].vue": () => import('./_nuxt/_id_-styles.815fbc0a.mjs').then(interopDefault),
  "node_modules/nuxt-icons/dist/runtime/components/nuxt-icon.vue": () => import('./_nuxt/nuxt-icon-styles.a680ee0e.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": () => import('./_nuxt/error-404-styles.1e0dde27.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": () => import('./_nuxt/error-500-styles.cf4b3e80.mjs').then(interopDefault),
  "layouts/default.vue": () => import('./_nuxt/default-styles.255245dd.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
