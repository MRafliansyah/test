const Mitra_vue_vue_type_style_index_0_scoped_af61ebb0_lang = ".container[data-v-af61ebb0]{margin:0 auto;max-width:1200px}aside[data-v-af61ebb0]{background-color:#333}nav ul[data-v-af61ebb0]{list-style:none;padding:0}nav li[data-v-af61ebb0]{margin-bottom:10px}nav a[data-v-af61ebb0]{color:#fff}main[data-v-af61ebb0]{background-color:#000;flex:1}";

const Mitra_vue_vue_type_style_index_1_lang = ".bg-transparent:active svg path,.bg-transparent:hover svg path{fill:gold!important}";

const MitraStyles_6e48f8e2 = [Mitra_vue_vue_type_style_index_0_scoped_af61ebb0_lang, Mitra_vue_vue_type_style_index_1_lang, Mitra_vue_vue_type_style_index_0_scoped_af61ebb0_lang, Mitra_vue_vue_type_style_index_1_lang];

export { MitraStyles_6e48f8e2 as default };
//# sourceMappingURL=Mitra-styles.6e48f8e2.mjs.map
