const Dashboard_vue_vue_type_style_index_0_scoped_42b3ea95_lang = ".container[data-v-42b3ea95]{margin:0 auto;max-width:1200px}aside[data-v-42b3ea95]{background-color:#333}nav ul[data-v-42b3ea95]{list-style:none;padding:0}nav li[data-v-42b3ea95]{margin-bottom:10px}nav a[data-v-42b3ea95]{color:#fff}main[data-v-42b3ea95]{flex:1}";

const DashboardStyles_9501aaaa = [Dashboard_vue_vue_type_style_index_0_scoped_42b3ea95_lang, Dashboard_vue_vue_type_style_index_0_scoped_42b3ea95_lang];

export { DashboardStyles_9501aaaa as default };
//# sourceMappingURL=Dashboard-styles.9501aaaa.mjs.map
