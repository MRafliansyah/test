const Transaksi_vue_vue_type_style_index_0_scoped_faa1f47d_lang = ".btn-confirm[data-v-faa1f47d]:hover{background-color:var(--Dark-Grey-100,#242424)}";

const Transaksi_vue_vue_type_style_index_0_scoped_7cf9374b_lang = "@media (max-width:1600px){.header[data-v-7cf9374b]{font-size:45px}}@media (max-width:1400px){.header[data-v-7cf9374b]{font-size:40px}}";

const TransaksiStyles_f9343f19 = [Transaksi_vue_vue_type_style_index_0_scoped_faa1f47d_lang, Transaksi_vue_vue_type_style_index_0_scoped_7cf9374b_lang, Transaksi_vue_vue_type_style_index_0_scoped_7cf9374b_lang];

export { TransaksiStyles_f9343f19 as default };
//# sourceMappingURL=Transaksi-styles.f9343f19.mjs.map
