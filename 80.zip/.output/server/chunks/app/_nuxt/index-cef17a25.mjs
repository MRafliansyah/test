import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import _sfc_main$1 from './nuxt-icon-4e9d1e9b.mjs';
import { _ as _sfc_main$2 } from './Product-aaae4223.mjs';
import { mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderAttr, ssrRenderComponent, ssrRenderList } from 'vue/server-renderer';
import { _ as _export_sfc } from '../server.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _imports_0 = "" + publicAssetsURL("img/logistic.svg");
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_nuxt_icon = _sfc_main$1;
  const _component_CardProduct = _sfc_main$2;
  _push(`<main${ssrRenderAttrs(mergeProps({ class: "px-60 2xl:px-48 xl:px-40 sm:px-4" }, _attrs))} data-v-062cd4e7><div class="relative header" data-v-062cd4e7><div data-v-062cd4e7><h1 class="font-bold text-primary" data-v-062cd4e7> Cari Barang Artis Kesayanganmu </h1><h2 data-v-062cd4e7> Menang langsung bawa pulang! </h2></div><img${ssrRenderAttr("src", _imports_0)} alt="Logistic" class="absolute top-0 right-0 bg-img sm:hidden" data-v-062cd4e7></div><section class="mt-32 xl:mt-24 sm:mt-8 flex flex-col gap32" data-v-062cd4e7><label class="flex relative search" data-v-062cd4e7><input type="text" placeholder="Cari tiket atau lelang yang kamu pengen!" class="rounded-lg w-full shadow-32 py-4 pr-6 xl:py-3 pl-14 xl:pl-10 text-[19px] 2xl:text-base xl:text-sm sm:text-xs leading-tight bg-white dark:bg-darkGrey-100 placeholder:text-inherit-50" data-v-062cd4e7>`);
  _push(ssrRenderComponent(_component_nuxt_icon, {
    name: "search",
    class: "absolute text24 top-1/2 -translate-y-1/2 left-4 xl:left-3"
  }, null, _parent));
  _push(`</label><div data-v-062cd4e7><h3 class="font-bold text24" data-v-062cd4e7>Lelang Paling Baru</h3><p class="mt-2 xl:mt-1 text16" data-v-062cd4e7>Lelang yang sedang terjadi baru-baru ini, cepetan bid secepat mungkin!!!</p></div><div class="flex gap32" data-v-062cd4e7>`);
  _push(ssrRenderComponent(_component_CardProduct, null, null, _parent));
  _push(ssrRenderComponent(_component_CardProduct, null, null, _parent));
  _push(ssrRenderComponent(_component_CardProduct, null, null, _parent));
  _push(ssrRenderComponent(_component_CardProduct, null, null, _parent));
  _push(`<button class="font-bold text-inherit-50 hover:text-inherit text16 p12-16 min-w-fit" data-v-062cd4e7> Lihat Semua </button></div><div class="mt-8 xl:mt-6" data-v-062cd4e7><h3 class="font-bold text24" data-v-062cd4e7>Buy It Now!</h3><p class="mt-2 xl:mt-1 text16" data-v-062cd4e7>Kamu bisa beli barang ini langsung tanpa harus bid.</p></div><div class="grid grid-cols-5 gap32" data-v-062cd4e7>`);
  _push(ssrRenderComponent(_component_CardProduct, null, null, _parent));
  _push(ssrRenderComponent(_component_CardProduct, null, null, _parent));
  _push(ssrRenderComponent(_component_CardProduct, null, null, _parent));
  _push(ssrRenderComponent(_component_CardProduct, null, null, _parent));
  _push(ssrRenderComponent(_component_CardProduct, null, null, _parent));
  _push(ssrRenderComponent(_component_CardProduct, null, null, _parent));
  _push(ssrRenderComponent(_component_CardProduct, null, null, _parent));
  _push(ssrRenderComponent(_component_CardProduct, null, null, _parent));
  _push(ssrRenderComponent(_component_CardProduct, null, null, _parent));
  _push(ssrRenderComponent(_component_CardProduct, null, null, _parent));
  _push(`</div><div class="mt-8 xl:mt-6" data-v-062cd4e7><h3 class="font-bold text24" data-v-062cd4e7>Tiket Konser</h3><p class="mt-2 xl:mt-1 text16" data-v-062cd4e7>Kamu juga bisa beli tiket konser band lokal kesayanganmu lho.</p></div><div class="grid grid-cols-5 gap32" data-v-062cd4e7><!--[-->`);
  ssrRenderList(5, (n) => {
    _push(ssrRenderComponent(_component_CardProduct, {
      key: n,
      ticket: ""
    }, null, _parent));
  });
  _push(`<!--]--></div></section></main>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender], ["__scopeId", "data-v-062cd4e7"]]);

export { index as default };
//# sourceMappingURL=index-cef17a25.mjs.map
