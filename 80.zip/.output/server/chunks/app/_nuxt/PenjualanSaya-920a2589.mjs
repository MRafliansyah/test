import { _ as __nuxt_component_0$1 } from './Overlay-68678bd7.mjs';
import { useSSRContext, defineComponent, ref, unref, withCtx, createVNode, mergeProps } from 'vue';
import { u as useAuthStore } from './useAuth-653aac8a.mjs';
import { ssrRenderStyle, ssrRenderAttr, ssrInterpolate, ssrRenderComponent, ssrRenderAttrs } from 'vue/server-renderer';
import { _ as _export_sfc } from '../server.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'vue-router';

const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "PenjualanSaya",
  __ssrInlineRender: true,
  setup(__props) {
    const showConfirmation = ref(false);
    const showConfirmation2 = ref(false);
    useAuthStore();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ModalsOverlay = __nuxt_component_0$1;
      _push(`<!--[--><div class="flex shadow-32 rounded-lg grow cursor-pointer bg-white dark:bg-darkGrey-100" style="${ssrRenderStyle({ "height": "277px", "width": "718px" })}" data-v-6734ec46><div class="flex flex-col flex-1 p-4 xl:p-3 py-6 px-6" data-v-6734ec46><div class="w-20 h-20" data-v-6734ec46><img${ssrRenderAttr("src", `/img/sample_${_ctx.PenjualanSaya ? "concert" : "makki"}.png`)} alt="Foto Sampel" data-v-6734ec46></div></div><div class="flex flex-col py-6 mr-48" data-v-6734ec46><div class="flex items-center gap-2" data-v-6734ec46><p class="text-sm 2xl:text-[18px] leading-tight" data-v-6734ec46>Musisi</p><svg xmlns="http://www.w3.org/2000/svg" width="4" height="5" viewBox="0 0 4 5" fill="none" data-v-6734ec46><circle cx="2" cy="2.5" r="2" fill="white" fill-opacity="0.5" data-v-6734ec46></circle></svg><p class="text-sm 2xl:text-[18px] leading-tight" data-v-6734ec46>Lelang</p><svg xmlns="http://www.w3.org/2000/svg" width="4" height="5" viewBox="0 0 4 5" fill="none" data-v-6734ec46><circle cx="2" cy="2.5" r="2" fill="white" fill-opacity="0.5" data-v-6734ec46></circle></svg><p class="text-green-100" data-v-6734ec46>Transaksi Sukses</p><svg xmlns="http://www.w3.org/2000/svg" width="4" height="5" viewBox="0 0 4 5" fill="none" data-v-6734ec46><circle cx="2" cy="2.5" r="2" fill="white" fill-opacity="0.5" data-v-6734ec46></circle></svg><div class="bg-[rgba(255,181,99,0.2)] flex flex-col w-24 h-6 items-center py-1" data-v-6734ec46><div class="text-xs font-[&#39;Plus_Jakarta_Sans&#39;] text-[#ffb563]" data-v-6734ec46> Belum Dikirim </div></div></div><div class="flex flex-col mt-2 xl:flex-row xl:items-center gap-3" data-v-6734ec46><div class="flex-1" data-v-6734ec46><p class="text-xl 2xl:text-[20px] leading-tight font-bold" data-v-6734ec46>${ssrInterpolate(_ctx.PenjualanSaya ? "Tiket Konser Ungu" : "Bass Putih Makki Omar Parikesit")}</p><p class="text-[15px] leading-tight py-3 text-inherit-50" data-v-6734ec46>Total Dilihat: <span class="font-bold" data-v-6734ec46>100</span></p><p class="text-sm 2xl:text-[20px]" data-v-6734ec46>${ssrInterpolate(_ctx.PenjualanSaya ? "Online" : "Last Bid")}: <span class="text-green-100 font-bold" data-v-6734ec46>Rp. 3.900.000</span></p></div><div class="flex gap-1" data-v-6734ec46><div data-v-6734ec46><p class="text-sm 2xl:text-[14px] leading-tight" data-v-6734ec46>Status: <span class="font-bold" data-v-6734ec46>Publish/Draft</span></p></div></div></div><div class="flex ml-[19rem] mt-8 gap-2" data-v-6734ec46><button class="bg-transparent border border-white p-2 xl:p-4 rounded-lg text-sm xl:text-base" style="${ssrRenderStyle({ "width": "82px", "height": "44px" })}" data-v-6734ec46> Hapus </button><button class="bg-primary p-2 xl:p-4 font-bold rounded-lg text-sm xl:text-base dark:text-dark-100" style="${ssrRenderStyle({ "width": "168px", "height": "44px" })}" data-v-6734ec46> Edit ${ssrInterpolate(_ctx.PenjualanSaya ? "Edit" : "Lelang")}</button></div></div></div>`);
      if (unref(showConfirmation)) {
        _push(`<div class="notification" data-v-6734ec46>`);
        _push(ssrRenderComponent(_component_ModalsOverlay, null, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div style="${ssrRenderStyle({ "background-color": "var(--Dark-Grey-100, #242424)", "font-family": "'Plus Jakarta Sans', sans-serif", "color": "white" })}" class="w-10px h-10px rounded-lg flex flex-col gap-32 ml-4" data-v-6734ec46${_scopeId}><div class="h-[30rem] w-[24rem]" data-v-6734ec46${_scopeId}><h2 class="font-bold py-4 px-6" data-v-6734ec46${_scopeId}>Konfirmasi</h2><p class="mt-[13rem] px-6" data-v-6734ec46${_scopeId}> Apakah Anda yakin ingin membuat lelang baru? Lelang akan dikirim kepada admin HistoryOutlet untuk ditindak lanjuti. Cek secara berkala pada bagian Penjualan atau hubungi HO jika ada kendala. </p><div class="flex mt-[2rem] gap-2 justify-center" data-v-6734ec46${_scopeId}><div data-v-6734ec46${_scopeId}><button class="btn-confirm font-bold rounded-lg" style="${ssrRenderStyle({ "font-family": "'Plus Jakarta Sans', sans-serif", "font-size": "16px", "width": "168px", "height": "44px", "transition": "background-color 0.3s", "display": "flex", "align-items": "center", "justify-content": "center" })}" data-v-6734ec46${_scopeId}> Tidak </button></div><div data-v-6734ec46${_scopeId}><button class="btn-confirm bg-primary p-2 xl:p-4 font-bold rounded-lg text-sm xl:text-base dark:text-dark-100" style="${ssrRenderStyle({ "font-family": "'Plus Jakarta Sans', sans-serif", "font-size": "16px", "width": "168px", "height": "44px", "transition": "background-color 0.3s", "display": "flex", "align-items": "center", "justify-content": "center" })}" data-v-6734ec46${_scopeId}> Ya </button></div></div></div></div>`);
            } else {
              return [
                createVNode("div", {
                  style: { "background-color": "var(--Dark-Grey-100, #242424)", "font-family": "'Plus Jakarta Sans', sans-serif", "color": "white" },
                  class: "w-10px h-10px rounded-lg flex flex-col gap-32 ml-4"
                }, [
                  createVNode("div", { class: "h-[30rem] w-[24rem]" }, [
                    createVNode("h2", { class: "font-bold py-4 px-6" }, "Konfirmasi"),
                    createVNode("p", { class: "mt-[13rem] px-6" }, " Apakah Anda yakin ingin membuat lelang baru? Lelang akan dikirim kepada admin HistoryOutlet untuk ditindak lanjuti. Cek secara berkala pada bagian Penjualan atau hubungi HO jika ada kendala. "),
                    createVNode("div", { class: "flex mt-[2rem] gap-2 justify-center" }, [
                      createVNode("div", null, [
                        createVNode("button", {
                          class: "btn-confirm font-bold rounded-lg",
                          style: { "font-family": "'Plus Jakarta Sans', sans-serif", "font-size": "16px", "width": "168px", "height": "44px", "transition": "background-color 0.3s", "display": "flex", "align-items": "center", "justify-content": "center" }
                        }, " Tidak ")
                      ]),
                      createVNode("div", null, [
                        createVNode("button", {
                          class: "btn-confirm bg-primary p-2 xl:p-4 font-bold rounded-lg text-sm xl:text-base dark:text-dark-100",
                          style: { "font-family": "'Plus Jakarta Sans', sans-serif", "font-size": "16px", "width": "168px", "height": "44px", "transition": "background-color 0.3s", "display": "flex", "align-items": "center", "justify-content": "center" },
                          onClick: ($event) => showConfirmation2.value = !unref(showConfirmation2)
                        }, " Ya ", 8, ["onClick"])
                      ])
                    ])
                  ])
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(showConfirmation2)) {
        _push(`<div class="notification" data-v-6734ec46>`);
        _push(ssrRenderComponent(_component_ModalsOverlay, null, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div style="${ssrRenderStyle({ "background-color": "var(--Dark-Grey-100, #242424)", "font-family": "'Plus Jakarta Sans', sans-serif", "font-size": "16px" })}" class="w-10px h-10px rounded-lg flex flex-col gap-32 ml-4" data-v-6734ec46${_scopeId}><div class="h-[30rem] w-[24rem]" data-v-6734ec46${_scopeId}><h2 class="font-bold py-4 px-6" data-v-6734ec46${_scopeId}>Konfirmasi</h2><p class="mt-[16rem] px-6" data-v-6734ec46${_scopeId}> Silahkan tekan tombol Whatsapp dibawah untuk berkomunikasi lebih lanjut, atau hubungi 0898-9893-9090. </p><div class="flex mt-[2rem] gap-2 justify-center" data-v-6734ec46${_scopeId}><div data-v-6734ec46${_scopeId}><button class="btn-confirm font-bold rounded-lg" style="${ssrRenderStyle({ "font-family": "'Plus Jakarta Sans', sans-serif", "font-size": "16px", "width": "168px", "height": "44px", "transition": "background-color 0.3s", "display": "flex", "align-items": "center", "justify-content": "center" })}" data-v-6734ec46${_scopeId}><a href="/penjualansaya" data-v-6734ec46${_scopeId}>Tidak</a></button></div><div data-v-6734ec46${_scopeId}><button class="btn-confirm bg-primary p-2 xl:p-4 font-bold rounded-lg text-sm xl:text-base dark:text-dark-100" style="${ssrRenderStyle({ "font-family": "'Plus Jakarta Sans', sans-serif", "font-size": "16px", "width": "168px", "height": "44px", "transition": "background-color 0.3s", "display": "flex", "align-items": "center", "justify-content": "center" })}" data-v-6734ec46${_scopeId}> Buka Whatsapp </button></div></div></div></div>`);
            } else {
              return [
                createVNode("div", {
                  style: { "background-color": "var(--Dark-Grey-100, #242424)", "font-family": "'Plus Jakarta Sans', sans-serif", "font-size": "16px" },
                  class: "w-10px h-10px rounded-lg flex flex-col gap-32 ml-4"
                }, [
                  createVNode("div", { class: "h-[30rem] w-[24rem]" }, [
                    createVNode("h2", { class: "font-bold py-4 px-6" }, "Konfirmasi"),
                    createVNode("p", { class: "mt-[16rem] px-6" }, " Silahkan tekan tombol Whatsapp dibawah untuk berkomunikasi lebih lanjut, atau hubungi 0898-9893-9090. "),
                    createVNode("div", { class: "flex mt-[2rem] gap-2 justify-center" }, [
                      createVNode("div", null, [
                        createVNode("button", {
                          class: "btn-confirm font-bold rounded-lg",
                          style: { "font-family": "'Plus Jakarta Sans', sans-serif", "font-size": "16px", "width": "168px", "height": "44px", "transition": "background-color 0.3s", "display": "flex", "align-items": "center", "justify-content": "center" }
                        }, [
                          createVNode("a", { href: "/penjualansaya" }, "Tidak")
                        ])
                      ]),
                      createVNode("div", null, [
                        createVNode("button", {
                          class: "btn-confirm bg-primary p-2 xl:p-4 font-bold rounded-lg text-sm xl:text-base dark:text-dark-100",
                          style: { "font-family": "'Plus Jakarta Sans', sans-serif", "font-size": "16px", "width": "168px", "height": "44px", "transition": "background-color 0.3s", "display": "flex", "align-items": "center", "justify-content": "center" }
                        }, " Buka Whatsapp ")
                      ])
                    ])
                  ])
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Card/PenjualanSaya.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-6734ec46"]]);
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_CardPenjualanSaya = __nuxt_component_0;
  _push(`<main${ssrRenderAttrs(mergeProps({ class: "px-60 2xl:px-48 xl:px-40 sm:px-4" }, _attrs))} data-v-05e5e390><section class="mt-32 xl:mt-24 sm:mt-8 flex flex-col gap-32 justify-center items-center" data-v-05e5e390><div class="flex gap-4 font-medium text16 mr-[33rem] -mt-16" data-v-05e5e390><a href="/" class="text-dark-50 cursor-pointer" data-v-05e5e390>Beranda</a><p class="text-dark-100 cursor-default" data-v-05e5e390>/</p><p class="text-yellow-100 cursor-pointer" data-v-05e5e390>Penjualan Saya</p></div><div class="mr-[14rem] -mt-24" data-v-05e5e390><h3 style="${ssrRenderStyle({ "font-family": "'Plus Jakarta Sans'", "font-weight": "bold", "font-size": "25px" })}" data-v-05e5e390>Lihat Semua Penjualan Saya</h3><p class="-mt-2 xl:mt-1 font-normal font-size: 16px;" data-v-05e5e390>Isi semua penjualan saya yang sedang berjalan atau sudah selesai</p></div><div class="flex flex-col gap-4 -mt-[6rem]" data-v-05e5e390>`);
  _push(ssrRenderComponent(_component_CardPenjualanSaya, null, null, _parent));
  _push(ssrRenderComponent(_component_CardPenjualanSaya, null, null, _parent));
  _push(ssrRenderComponent(_component_CardPenjualanSaya, null, null, _parent));
  _push(`</div></section></main>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/PenjualanSaya.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const PenjualanSaya = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender], ["__scopeId", "data-v-05e5e390"]]);

export { PenjualanSaya as default };
//# sourceMappingURL=PenjualanSaya-920a2589.mjs.map
