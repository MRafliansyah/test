import _sfc_main$1 from './nuxt-icon-4e9d1e9b.mjs';
import { defineComponent, mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderAttr, ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Product",
  __ssrInlineRender: true,
  props: {
    ticket: Boolean
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_nuxt_icon = _sfc_main$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex flex-col shadow-32 rounded-lg grow cursor-pointer bg-white dark:bg-darkGrey-100 hover:scale-105" }, _attrs))}><div class="p-2"><img${ssrRenderAttr("src", `/img/sample_${__props.ticket ? "concert" : "makki"}.png`)} alt="Sample Photo"></div><div class="p-4 xl:p-3"><div class="flex items-center gap-2 text-inherit-50">`);
      _push(ssrRenderComponent(_component_nuxt_icon, {
        name: "people",
        class: "text-lg 2xl:text-sm"
      }, null, _parent));
      _push(`<p class="text-sm 2xl:text-[10px]">100</p></div><p class="text-sm 2xl:text-[11px] leading-tight font-bold">${ssrInterpolate(__props.ticket ? "Tiket Konser Ungu" : "Bass Putih Makki Omar Parikesit")}</p></div><div class="p-4 xl:p-3 border-solid border-t border-dark-20 dark:border-white-20"><p class="text-sm 2xl:text-xs">${ssrInterpolate(__props.ticket ? "OTS" : "Bid")}: <span class="font-bold">Rp. 10.000</span></p><p class="text-sm 2xl:text-xs">${ssrInterpolate(__props.ticket ? "Online" : "Last Bid")}: <span class="text-green-100 font-bold">Rp. 3.900.000</span></p>`);
      if (!__props.ticket) {
        _push(`<p class="text-sm 2xl:text-xs">Bin: <span class="text-red-100 font-bold">Rp. 5.900.000</span></p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="flex justify-between mt-2 gap-1"><div><p class="text-sm 2xl:text-[11px] leading-tight">Berakhir</p><p class="font-bold text-sm 2xl:text-[11px] leading-tight">01 Des 2023</p></div><button class="bg-primary p12-16 font-bold rounded-lg text16 dark:text-dark-100"> Lihat ${ssrInterpolate(__props.ticket ? "Detail" : "Lelang")}! </button></div></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Card/Product.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as _ };
//# sourceMappingURL=Product-aaae4223.mjs.map
