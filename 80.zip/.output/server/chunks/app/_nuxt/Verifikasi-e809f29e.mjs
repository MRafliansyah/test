import { _ as __nuxt_component_0 } from './Sidebar-0c1aabc4.mjs';
import { mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderStyle, ssrRenderAttr } from 'vue/server-renderer';
import { _ as _imports_0, a as _imports_1 } from './notifications-0c94da73.mjs';
import { _ as _export_sfc } from '../server.mjs';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _sfc_main = {
  __name: "Verifikasi",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Sidebar = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-black min-h-screen top-0 absolute z-50 flex" }, _attrs))} data-v-b69f7540>`);
      _push(ssrRenderComponent(_component_Sidebar, null, null, _parent));
      _push(`<main class="flex-1 p-4" data-v-b69f7540><div class="container mx-auto flex justify-between items-center" data-v-b69f7540><div data-v-b69f7540><h2 style="${ssrRenderStyle({ "font-family": "'Plus Jakarta Sans'", "font-weight": "bold", "font-size": "2rem" })}" data-v-b69f7540>Verifikasi</h2><p class="text-inherit-50 -mt-2 xl:mt-1 font-normal font-size: 16px;" data-v-b69f7540>Tempat dimana anda dapat melakukan verifikasi data yang masuk.</p><div data-v-b69f7540></div></div><div class="relative -mr-[18rem] pl-52 -mt-16" style="${ssrRenderStyle({ "display": "flex", "width": "413px", "padding": "16px", "align-items": "center", "gap": "16px" })}" data-v-b69f7540><input type="text" placeholder="Cari" class="py-2 px-3 pl-12 rounded-lg border border-dark-100 focus:ring focus:ring-dark-100 focus:outline-none" style="${ssrRenderStyle({ "width": "100%", "border-radius": "8px", "border": "1px solid var(--White-20, rgba(255, 255, 255, 0.20))", "background": "var(--Dark-Grey-100, #242424)" })}" data-v-b69f7540><button class="absolute top-1/2 right-2 transform -translate-y-1/2 mr-[23rem]" data-v-b69f7540><div style="${ssrRenderStyle({ "float": "left" })}" data-v-b69f7540><img${ssrRenderAttr("src", _imports_0)} data-v-b69f7540></div></button></div><div class="ml-14 -mt-16 relative" style="${ssrRenderStyle({ "display": "flex", "padding": "8px", "align-items": "center", "gap": "8px", "border-radius": "8px", "border": "1px solid var(--White-20, rgba(255, 255, 255, 0.20))", "background": "var(--Dark-Grey-100, #242424)" })}" data-v-b69f7540><button class="relative" data-v-b69f7540><img${ssrRenderAttr("src", _imports_1)} data-v-b69f7540><span class="absolute top-0 left-1/2 -translate-x-1/2 h-2 w-2 bg-transparent rounded-full" data-v-b69f7540></span></button></div></div><div class="mt-[2rem]" data-v-b69f7540><button style="${ssrRenderStyle({ "width": "84px", "height": "44px" })}" data-v-b69f7540><div class="bg-transparent hover:gold-100 text-white py-2 px-4 hover:border-transparent rounded flex items-center" data-v-b69f7540><div class="text-inherit-50 hover:text-inherit font-semibold" data-v-b69f7540> Lelang </div></div></button><button style="${ssrRenderStyle({ "width": "128px", "height": "44px" })}" data-v-b69f7540><div class="bg-transparent hover:gold-100 text-white py-2 px-4 hover:border-transparent rounded flex items-center justify-center" data-v-b69f7540><div class="text-inherit-50 hover:text-inherit font-semibold" data-v-b69f7540> Tiket Konser </div></div></button></div><div class="container mx-2" data-v-b69f7540><div class="grid grid-cols-4 gap-4 mt-6 justify-end" data-v-b69f7540><div class="flex" data-v-b69f7540><div class="w-1555 h-852 rounded-lg mt-5" style="${ssrRenderStyle({ "display": "flex", "width": "1199px", "height": "852px", "padding": "24px", "flex-direction": "column", "align-items": "flex-start", "gap": "24px", "flex-shrink": "0", "background": "var(--Dark-Grey-100, #242424)" })}" data-v-b69f7540><h2 style="${ssrRenderStyle({ "color": "var(--White-100, #FFF)", "font-family": "'Plus Jakarta Sans'", "font-size": "24px", "font-style": "normal", "font-weight": "600", "line-height": "normal" })}" data-v-b69f7540>Semua Permintaan Lelang</h2></div></div><div class="flex items-center justify-between -mt-[41rem] -ml-[17rem]" data-v-b69f7540><div class="flex items-center" data-v-b69f7540><p class="text-white" data-v-b69f7540>Filter</p><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" class="ml-2" data-v-b69f7540><g clip-path="url(#clip0_816_9925)" data-v-b69f7540><path d="M3.54169 4.67504C5.22503 6.83337 8.33336 10.8334 8.33336 10.8334V15.8334C8.33336 16.2917 8.70836 16.6667 9.16669 16.6667H10.8334C11.2917 16.6667 11.6667 16.2917 11.6667 15.8334V10.8334C11.6667 10.8334 14.7667 6.83337 16.45 4.67504C16.875 4.12504 16.4834 3.33337 15.7917 3.33337H4.20003C3.50836 3.33337 3.11669 4.12504 3.54169 4.67504Z" fill="white" data-v-b69f7540></path></g><defs data-v-b69f7540><clipPath id="clip0_816_9925" data-v-b69f7540><rect width="20" height="20" fill="white" data-v-b69f7540></rect></clipPath></defs></svg></div></div><div class="border-solid border-white/20 bg-[#242424] flex flex-row justify-center gap-8 w-40 h-8 items-center border rounded-lg mt-24 -ml-[30rem]" data-v-b69f7540><div class="font-[&#39;Plus_Jakarta_Sans&#39;] text-white" data-v-b69f7540>Kategori</div><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" data-v-b69f7540><g clip-path="url(#clip0_1816_118)" data-v-b69f7540><path d="M6.175 7.15845L10 10.9751L13.825 7.15845L15 8.33345L10 13.3334L5 8.33345L6.175 7.15845Z" fill="white" data-v-b69f7540></path></g><defs data-v-b69f7540><clipPath id="clip0_1816_118" data-v-b69f7540><rect width="20" height="20" fill="white" data-v-b69f7540></rect></clipPath></defs></svg></div><div class="border-solid border-white/20 bg-[#242424] flex flex-row justify-center gap-16 w-40 h-8 items-center border rounded-lg mt-24 -ml-[37rem]" data-v-b69f7540><div class="font-[&#39;Plus_Jakarta_Sans&#39;] text-white ml-[34rem]" data-v-b69f7540>CSR</div><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" data-v-b69f7540><g clip-path="url(#clip0_1816_118)" data-v-b69f7540><path d="M6.175 7.15845L10 10.9751L13.825 7.15845L15 8.33345L10 13.3334L5 8.33345L6.175 7.15845Z" fill="white" data-v-b69f7540></path></g><defs data-v-b69f7540><clipPath id="clip0_1816_118" data-v-b69f7540><rect width="20" height="20" fill="white" data-v-b69f7540></rect></clipPath></defs></svg><div class="border-solid border-white/20 bg-[#242424] flex flex-row justify-center gap-2 w-60 h-8 items-center border rounded-lg mr-[17rem]" data-v-b69f7540><input type="text" placeholder="Cari Lelang/Tiket" class="font-[&#39;Plus_Jakarta_Sans&#39;] text-white/50 bg-transparent border-none focus:outline-none ml-3" data-v-b69f7540><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" class="mr-3" data-v-b69f7540><g clip-path="url(#clip0_1816_168)" data-v-b69f7540><path d="M12.9167 11.6667H12.2583L12.025 11.4417C12.8417 10.4917 13.3333 9.25833 13.3333 7.91667C13.3333 4.925 10.9083 2.5 7.91667 2.5C4.925 2.5 2.5 4.925 2.5 7.91667C2.5 10.9083 4.925 13.3333 7.91667 13.3333C9.25833 13.3333 10.4917 12.8417 11.4417 12.025L11.6667 12.2583V12.9167L15.8333 17.075L17.075 15.8333L12.9167 11.6667ZM7.91667 11.6667C5.84167 11.6667 4.16667 9.99167 4.16667 7.91667C4.16667 5.84167 5.84167 4.16667 7.91667 4.16667C9.99167 4.16667 11.6667 5.84167 11.6667 7.91667C11.6667 9.99167 9.99167 11.6667 7.91667 11.6667Z" fill="white" data-v-b69f7540></path></g><defs data-v-b69f7540><clipPath id="clip0_1816_168" data-v-b69f7540><rect width="20" height="20" fill="white" data-v-b69f7540></rect></clipPath></defs></svg></div></div></div></div></main></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/Verifikasi.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Verifikasi = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-b69f7540"]]);

export { Verifikasi as default };
//# sourceMappingURL=Verifikasi-e809f29e.mjs.map
