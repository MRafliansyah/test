const nuxtIcon_vue_vue_type_style_index_0_lang = ".nuxt-icon svg{height:1em;margin-bottom:.125em;vertical-align:middle;width:1em}.nuxt-icon.nuxt-icon--fill,.nuxt-icon.nuxt-icon--fill *{fill:currentColor!important}.nuxt-icon.nuxt-icon--stroke,.nuxt-icon.nuxt-icon--stroke *{stroke:currentColor!important}";

const nuxtIconStyles_a680ee0e = [nuxtIcon_vue_vue_type_style_index_0_lang];

export { nuxtIconStyles_a680ee0e as default };
//# sourceMappingURL=nuxt-icon-styles.a680ee0e.mjs.map
