import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import { mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderAttr } from 'vue/server-renderer';
import { _ as _export_sfc } from '../server.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _imports_0 = "" + publicAssetsURL("img/person_phone.svg");
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<main${ssrRenderAttrs(mergeProps({ class: "px-60 2xl:px-48 xl:px-40 sm:px-4 mt-[10.5vh]" }, _attrs))} data-v-682e3b6a><div class="mb-16 xl:mb-11" data-v-682e3b6a><h1 class="text-primary font-bold" data-v-682e3b6a>Favorit</h1><h1 data-v-682e3b6a>Kumpulan barang paling disukai</h1></div><section class="flex flex-col gap-4 xl:gap-3 w-full items-center phone-img mx-auto" data-v-682e3b6a><img${ssrRenderAttr("src", _imports_0)} alt="Person with phone" class="phone-img" data-v-682e3b6a><div class="flex flex-col gap-2 xl:gap-1 cursor-default" data-v-682e3b6a><p class="font-bold text24 text-center" data-v-682e3b6a>Favorit belum tersedia</p><p class="text-center text16" data-v-682e3b6a>Fitur Favorit hanya bisa digunakan untuk user yang sudah login. Silahkan login atau buat akun baru dibawah!</p></div><div class="flex gap-4 w-full" data-v-682e3b6a><button class="rounded-lg py-3 xl:py-2 px-4 xl:px-3 grow font-bold text-inherit-50 hover:text-inherit text16" data-v-682e3b6a>Daftar</button><button class="rounded-lg bg-primary p12-16 grow font-bold text16 text-dark-100" data-v-682e3b6a>Login</button></div></section></main>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/favorite.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const favorite = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender], ["__scopeId", "data-v-682e3b6a"]]);

export { favorite as default };
//# sourceMappingURL=favorite-18283e4f.mjs.map
