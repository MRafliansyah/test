import { mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs } from 'vue/server-renderer';
import { _ as _export_sfc } from '../server.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'vue-router';

const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex flex-col items-center" }, _attrs))}><div class="text-3xl font-[&#39;Plus_Jakarta_Sans&#39;] font-medium mt-4"> Tentang Kami </div><div class="flex flex-row items-center gap-12 w-900 H-382 text-lg font-[&#39;Plus_Jakarta_Sans&#39;] font-medium w-2/3 mt-4"><img src="https://file.rendit.io/n/uzKuHlmWtLVBRboUvryG.png" class="self-start" id="LogoHO"> HISTORI OUTLET adalah aplikasi untuk melelang barang - barang dan pembelian tiket konser. Dengan tujuan membangun aplikasi yang menggabungkan fitur lelang barang dan pembelian tiket konser dapat menjadi proyek yang menarik dan bermanfaat bagi pengguna. </div></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/AboutUs.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const AboutUs = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { AboutUs as default };
//# sourceMappingURL=AboutUs-743b81f8.mjs.map
