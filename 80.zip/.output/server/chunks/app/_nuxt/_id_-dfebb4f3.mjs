import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import { _ as __nuxt_component_0 } from './nuxt-link-afaf4e47.mjs';
import _sfc_main$5 from './nuxt-icon-4e9d1e9b.mjs';
import { useSSRContext, mergeProps, withCtx, createTextVNode, ref, unref } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrRenderList, ssrRenderStyle, ssrRenderSlot } from 'vue/server-renderer';
import { _ as _export_sfc } from '../server.mjs';
import { _ as __nuxt_component_0$1 } from './Button-67e12de3.mjs';
import { _ as _imports_0$1 } from './slank-d260c789.mjs';
import { _ as _sfc_main$6 } from './Product-aaae4223.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _sfc_main$4 = {};
function _sfc_ssrRender$3(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "p-3 2xl:p-[10px] xl:p-2 bg-dark-100 rounded-lg w-[52px] 2xl:w-[42px] xl:w-[37px] text-white font-bold text32 text-center" }, _attrs))}>`);
  ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
  _push(`</div>`);
}
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Product/Time.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["ssrRender", _sfc_ssrRender$3]]);
const _sfc_main$3 = {};
function _sfc_ssrRender$2(_ctx, _push, _parent, _attrs) {
  _push(`<button${ssrRenderAttrs(mergeProps({ class: "py-4 2xl:py-3 px-8 2xl:px-[26px] xl:px-6 sm:px-1 rounded-lg" }, _attrs))}>`);
  ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
  _push(`</button>`);
}
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/BigButton.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_3 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["ssrRender", _sfc_ssrRender$2]]);
const _sfc_main$2 = {};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs) {
  const _component_nuxt_icon = _sfc_main$5;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex gap32 py-4 2xl:py-3 justify-between items-center border-solid border-y border-dark-20" }, _attrs))}><div class="flex flex-col"><p class="text32 font-bold">50%</p><p class="text16">Komisi Artis</p></div><div class="flex flex-col"><p class="text32 font-bold">30%</p><p class="text16">Galang Dana CSR</p></div><div class="flex flex-col"><p class="text32 font-bold">20%</p><p class="text16">Komisi History Outlet</p></div>`);
  _push(ssrRenderComponent(_component_nuxt_icon, {
    name: "info",
    class: "text24 cursor-pointer"
  }, null, _parent));
  _push(`</div>`);
}
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Product/Comission.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_4 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["ssrRender", _sfc_ssrRender$1]]);
const _imports_3 = "" + publicAssetsURL("img/user2.png");
const _sfc_main$1 = {
  __name: "Description",
  __ssrInlineRender: true,
  setup(__props) {
    const activeTab = ref(1);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Button = __nuxt_component_0$1;
      const _component_nuxt_icon = _sfc_main$5;
      _push(`<div${ssrRenderAttrs(_attrs)} data-v-ce7e6781><div class="flex gap32 p12-16 rounded-lg border border-solid border-dark-20" data-v-ce7e6781>`);
      _push(ssrRenderComponent(_component_Button, {
        onClick: ($event) => activeTab.value = 1,
        class: ["font-bold text16 text-dark-50", { active: unref(activeTab) == 1 }]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Deskripsi Barang`);
          } else {
            return [
              createTextVNode("Deskripsi Barang")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_Button, {
        onClick: ($event) => activeTab.value = 2,
        class: ["font-bold text16 text-dark-50", { active: unref(activeTab) == 2 }]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`History Kepemilikan`);
          } else {
            return [
              createTextVNode("History Kepemilikan")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_Button, {
        onClick: ($event) => activeTab.value = 3,
        class: ["font-bold text16 text-dark-50", { active: unref(activeTab) == 3 }]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Sertifikasi`);
          } else {
            return [
              createTextVNode("Sertifikasi")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_Button, {
        onClick: ($event) => activeTab.value = 4,
        class: ["font-bold text16 text-dark-50", { active: unref(activeTab) == 4 }]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Bids`);
          } else {
            return [
              createTextVNode("Bids")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="mt-6 2xl:mt-5 xl:mt-4" data-v-ce7e6781><div style="${ssrRenderStyle(unref(activeTab) == 1 ? null : { display: "none" })}" class="flex flex-col gap16" data-v-ce7e6781><p class="font-bold text24" data-v-ce7e6781>Deskripsi Barang</p><p class="text16 text-dark-50" data-v-ce7e6781>Lorem ipsum dolor sit amet consectetur. Ut faucibus tincidunt scelerisque eget augue amet. Interdum ultrices tristique facilisis in. Potenti semper malesuada ultrices mauris habitasse arcu turpis. Lorem fermentum pellentesque varius id porta dis nibh eget commodo. Eu neque nibh felis at molestie netus. Vestibulum sed lacus aliquam semper faucibus eu vitae. Adipiscing erat elementum feugiat lectus fusce venenatis est. Eget nec euismod id proin mus donec purus. Nibh egestas ac quis maecenas bibendum urna vulputate. Aliquam ornare magna turpis in.</p></div><div style="${ssrRenderStyle(unref(activeTab) == 2 ? null : { display: "none" })}" class="flex flex-col gap16" data-v-ce7e6781><p class="font-bold text24" data-v-ce7e6781>History Kepemilikan</p><p class="text16 text-dark-50" data-v-ce7e6781>Untuk riwayat kepemilikan yang sudah terverifikasi oleh History Outlet dapat dilihat di bawah ini: </p><p class="text16 text-dark-50" data-v-ce7e6781>Catatan: Jika pemilik lebih dari satu, maka pemilik nomor terakhir adalah pemilik barang ini.</p><div class="flex items-center gap16" data-v-ce7e6781><img${ssrRenderAttr("src", _imports_0$1)} alt="User img" class="w-16 2xl:w-[52px] xl:w-11" data-v-ce7e6781><div class="flex flex-col gap-1 2xl:gap-[2px]" data-v-ce7e6781><p class="font-bold text24" data-v-ce7e6781>Slank</p><div class="flex items-center" data-v-ce7e6781><p class="mr-3 text16" data-v-ce7e6781>Verified Owner</p>`);
      _push(ssrRenderComponent(_component_nuxt_icon, {
        name: "check_circle",
        class: "text20 text-yellow-100"
      }, null, _parent));
      _push(`</div><p class="text16" data-v-ce7e6781>Pemilik ke-1</p></div></div></div><div style="${ssrRenderStyle(unref(activeTab) == 3 ? null : { display: "none" })}" class="flex flex-col gap16" data-v-ce7e6781><p class="font-bold text24" data-v-ce7e6781>Sertifikasi</p><p class="text16 text-dark-50" data-v-ce7e6781>Silahkan cek dibawah ini untuk memeriksa keaslian sertifikasi yang dipublikasikan oleh History Outlet.</p><div class="flex flex-col gap-3 2xl:gap-2 p-4 2xl:p-3 bg-white shadow-32 rounded-lg max-w-fit" data-v-ce7e6781><p class="font-bold text16" data-v-ce7e6781>Authentic Owner Certification</p><div class="rounded-full h-2 w-[90%] bg-dark-100" data-v-ce7e6781></div><div class="rounded-full h-2 w-[80%] bg-dark-100" data-v-ce7e6781></div><div class="rounded-full h-2 w-[70%] bg-dark-100" data-v-ce7e6781></div><div class="rounded-full h-2 w-[60%] bg-dark-100" data-v-ce7e6781></div><div class="rounded-full h-2 w-[50%] bg-dark-100" data-v-ce7e6781></div></div></div><div style="${ssrRenderStyle(unref(activeTab) == 4 ? null : { display: "none" })}" class="flex flex-col gap16" data-v-ce7e6781><div class="flex gap16 justify-between" data-v-ce7e6781><p class="font-bold text24" data-v-ce7e6781>Bids</p>`);
      _push(ssrRenderComponent(_component_Button, { class: "text-dark-50 hover:text-dark-100 font-bold text16" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Lihat Semua Bidder`);
          } else {
            return [
              createTextVNode("Lihat Semua Bidder")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="flex gap16 items-center" data-v-ce7e6781><img${ssrRenderAttr("src", _imports_3)} alt="Highest bid user" class="w-16 2xl:w-[52px] xl:w-11" data-v-ce7e6781><div class="flex flex-col gap-1 2xl:gap-[3px]" data-v-ce7e6781><p class="text-dark-50 text16" data-v-ce7e6781>Bid tertinggi sementara:</p><p class="font-bold text24" data-v-ce7e6781>Agus Subagja</p><p class="font-bold text24 text-green-100" data-v-ce7e6781>Rp. 3.900.000</p></div></div><div class="border border-solid border-dark-20" data-v-ce7e6781></div><div class="flex gap16 items-center" data-v-ce7e6781><img${ssrRenderAttr("src", _imports_3)} alt="Highest bid user" class="w-16 2xl:w-[52px] xl:w-11" data-v-ce7e6781><div class="flex flex-col gap-1 2xl:gap-[3px]" data-v-ce7e6781><p class="text-dark-50 text16" data-v-ce7e6781>10.30</p><p class="font-bold text24" data-v-ce7e6781>Agus Subagja</p><p class="font-bold text24 text-green-100" data-v-ce7e6781>Rp. 3.900.000</p></div></div><!--[-->`);
      ssrRenderList(5, (n) => {
        _push(`<div class="flex gap16 items-center" data-v-ce7e6781><img${ssrRenderAttr("src", _imports_3)} alt="Highest bid user" class="w-16 2xl:w-[52px] xl:w-11" data-v-ce7e6781><div class="flex flex-col gap-1 2xl:gap-[3px]" data-v-ce7e6781><p class="text-dark-50 text16" data-v-ce7e6781>10.30</p><p class="font-bold text24" data-v-ce7e6781>Agus Subagja</p><p class="font-bold text24 text-red-100" data-v-ce7e6781>Rp. 3.900.000</p></div></div>`);
      });
      _push(`<!--]--></div></div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Product/Description.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_5 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-ce7e6781"]]);
const _imports_0 = "" + publicAssetsURL("img/sample_jacket.png");
const _imports_1 = "" + publicAssetsURL("img/sample_jacket_mini.png");
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_NuxtLink = __nuxt_component_0;
  const _component_nuxt_icon = _sfc_main$5;
  const _component_ProductTime = __nuxt_component_2;
  const _component_BigButton = __nuxt_component_3;
  const _component_ProductComission = __nuxt_component_4;
  const _component_ProductDescription = __nuxt_component_5;
  const _component_CardProduct = _sfc_main$6;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "px-60 2xl:px-48 xl:px-40 mt-44 2xl:mt-[140px] xl:mt-28" }, _attrs))}><div class="flex gap-4 font-medium text16">`);
  _push(ssrRenderComponent(_component_NuxtLink, {
    to: "/",
    class: "text-dark-50 cursor-pointer"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Beranda`);
      } else {
        return [
          createTextVNode("Beranda")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`<p class="text-dark-100 cursor-default">/</p><p class="text-yellow-100 cursor-pointer">Detail Lelang</p></div><div class="mt-8 2xl:mt-6 flex gap-16 2xl:gap-[52px] xl:gap-11"><section class="flex flex-col gap32 w-[30.2vw] shrink-0"><div class=""><img${ssrRenderAttr("src", _imports_0)} alt="Main image" class="p-4 border border-dark-20 border-solid rounded-lg w-full"></div><div class="flex gap32 justify-between"><div class="p-2 bg-yellow-100 border border-solid border-dark-20 rounded-lg cursor-pointer"><img${ssrRenderAttr("src", _imports_1)} alt="Mini image"></div><div class="p-2 border border-solid border-dark-20 rounded-lg cursor-pointer"><img${ssrRenderAttr("src", _imports_1)} alt="Mini image"></div><div class="p-2 border border-solid border-dark-20 rounded-lg cursor-pointer"><img${ssrRenderAttr("src", _imports_1)} alt="Mini image"></div><div class="p-2 border border-solid border-dark-20 rounded-lg cursor-pointer"><img${ssrRenderAttr("src", _imports_1)} alt="Mini image"></div></div></section><section class="flex flex-col gap32"><div class="flex gap32"><div class="flex flex-col gap16 text-dark-100"><p class="font-medium text32">Barang Bekas Artis</p><p class="font-semibold text-[64px] 2xl:text-[52px] xl:text[45px] leading-none">Jaket Kulit Artis Papan Atas SLANK</p></div><div class="flex flex-col py-6 px-4 gap-6 border border-solid border-dark-20 rounded-full self-start"><div class="flex flex-col gap-1 items-center cursor-pointer">`);
  _push(ssrRenderComponent(_component_nuxt_icon, {
    name: "favorite",
    class: "text24 text-dark-100"
  }, null, _parent));
  _push(`<p class="text-dark-50 text-[13px] 2xl:text-[10px] leading-none">Like</p></div><div class="flex flex-col gap-1 items-center cursor-pointer">`);
  _push(ssrRenderComponent(_component_nuxt_icon, {
    name: "share",
    class: "text24 text-dark-100"
  }, null, _parent));
  _push(`<p class="text-dark-50 text-[13px] 2xl:text-[10px] leading-none">Share</p></div></div></div><div class="flex"><div class="flex flex-col gap32"><div class="flex items-center gap16"><img${ssrRenderAttr("src", _imports_0$1)} alt="User img" class="w-16 2xl:w-[52px] xl:w-11"><div class="flex flex-col"><p class="font-bold text24">Slank</p><div class="flex items-center"><p class="mr-3 text16">Verified Owner</p>`);
  _push(ssrRenderComponent(_component_nuxt_icon, {
    name: "check_circle",
    class: "text20 text-yellow-100"
  }, null, _parent));
  _push(`</div></div></div><div class="flex gap16 items-center"><img${ssrRenderAttr("src", _imports_3)} alt="Highest bid user" class="w-16 2xl:w-[52px] xl:w-11"><div class="flex flex-col gap-1 2xl:gap-[3px]"><p class="text-dark-50 text16">Bid tertinggi sementara:</p><p class="font-bold text24">Agus Subagja</p><p class="font-bold text24 text-green-100">Rp. 3.900.000</p></div></div><div class="flex flex-col gap16"><div class="flex flex-col"><p class="font-bold text24">Waktu Lelang Tersisa</p><p class="text16">19 Maret 2023</p></div><div class="flex gap16"><div class="flex flex-col gap-2"><div class="flex gap-2">`);
  _push(ssrRenderComponent(_component_ProductTime, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`0`);
      } else {
        return [
          createTextVNode("0")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_ProductTime, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`1`);
      } else {
        return [
          createTextVNode("1")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div><p class="text-center text16">Hari</p></div><div class="flex flex-col gap-2"><div class="flex gap-2">`);
  _push(ssrRenderComponent(_component_ProductTime, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`0`);
      } else {
        return [
          createTextVNode("0")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_ProductTime, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`1`);
      } else {
        return [
          createTextVNode("1")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div><p class="text-center text16">Jam</p></div><div class="flex flex-col gap-2"><div class="flex gap-2">`);
  _push(ssrRenderComponent(_component_ProductTime, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`0`);
      } else {
        return [
          createTextVNode("0")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_ProductTime, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`1`);
      } else {
        return [
          createTextVNode("1")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div><p class="text-center text16">Menit</p></div><div class="flex flex-col gap-2"><div class="flex gap-2">`);
  _push(ssrRenderComponent(_component_ProductTime, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`0`);
      } else {
        return [
          createTextVNode("0")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_ProductTime, null, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`2`);
      } else {
        return [
          createTextVNode("2")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div><p class="text-center text16">Detik</p></div></div></div></div><div class="flex flex-col gap16 w-full items-center"><div class="flex flex-col gap8 w-full items-center"><p class="font-bold text24 text-red-100">Rp. 10.000.000</p>`);
  _push(ssrRenderComponent(_component_BigButton, { class: "bg-yellow-100 font-bold text24 w-full" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Buy It Now! `);
      } else {
        return [
          createTextVNode(" Buy It Now! ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div><div class="flex flex-col gap8 w-full items-center"><p class="font-bold text24">Rp. 10.000</p>`);
  _push(ssrRenderComponent(_component_BigButton, { class: "font-bold text24 w-full border border-solid border-dark-20" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Bid `);
      } else {
        return [
          createTextVNode(" Bid ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div></div></div>`);
  _push(ssrRenderComponent(_component_ProductComission, null, null, _parent));
  _push(ssrRenderComponent(_component_ProductDescription, null, null, _parent));
  _push(`</section></div><div class="flex flex-col gap32 mt-16"><div class="flex flex-col gap-2 text-dark-100 cursor-default"><h3 class="font-bold text24">Cek Lelang yang lain</h3><p class="text16">Mungkin ada lelang yang kamu suka di bawah ini</p></div><div class="grid grid-cols-5 gap32"><!--[-->`);
  ssrRenderList(10, (n) => {
    _push(ssrRenderComponent(_component_CardProduct, { key: n }, null, _parent));
  });
  _push(`<!--]--></div></div></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/product/[id].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const _id_ = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { _id_ as default };
//# sourceMappingURL=_id_-dfebb4f3.mjs.map
