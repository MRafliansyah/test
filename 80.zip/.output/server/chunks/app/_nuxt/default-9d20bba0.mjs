import { p as publicAssetsURL, b as buildAssetsURL } from '../../handlers/renderer.mjs';
import { useSSRContext, computed, watch, withCtx, createTextVNode, createVNode, unref, defineComponent, mergeProps, ref, withModifiers, toDisplayString } from 'vue';
import { u as useHead } from './index-dd5a448f.mjs';
import { _ as __nuxt_component_0 } from './nuxt-link-afaf4e47.mjs';
import { _ as __nuxt_component_0$2 } from './Button-67e12de3.mjs';
import _sfc_main$8 from './nuxt-icon-4e9d1e9b.mjs';
import { u as useAuthStore } from './useAuth-653aac8a.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderSlot, ssrRenderAttr, ssrInterpolate } from 'vue/server-renderer';
import { b as useState, a as useRoute, _ as _export_sfc } from '../server.mjs';
import { _ as __nuxt_component_0$1 } from './Overlay-68678bd7.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const removeUndefinedProps = (props) => Object.fromEntries(Object.entries(props).filter(([, value]) => value !== void 0));
const setupForUseMeta = (metaFactory, renderChild) => (props, ctx) => {
  useHead(() => metaFactory({ ...removeUndefinedProps(props), ...ctx.attrs }, ctx));
  return () => {
    var _a, _b;
    return renderChild ? (_b = (_a = ctx.slots).default) == null ? void 0 : _b.call(_a) : null;
  };
};
const globalProps = {
  accesskey: String,
  autocapitalize: String,
  autofocus: {
    type: Boolean,
    default: void 0
  },
  class: [String, Object, Array],
  contenteditable: {
    type: Boolean,
    default: void 0
  },
  contextmenu: String,
  dir: String,
  draggable: {
    type: Boolean,
    default: void 0
  },
  enterkeyhint: String,
  exportparts: String,
  hidden: {
    type: Boolean,
    default: void 0
  },
  id: String,
  inputmode: String,
  is: String,
  itemid: String,
  itemprop: String,
  itemref: String,
  itemscope: String,
  itemtype: String,
  lang: String,
  nonce: String,
  part: String,
  slot: String,
  spellcheck: {
    type: Boolean,
    default: void 0
  },
  style: String,
  tabindex: String,
  title: String,
  translate: String
};
const Link = /* @__PURE__ */ defineComponent({
  // eslint-disable-next-line vue/no-reserved-component-names
  name: "Link",
  inheritAttrs: false,
  props: {
    ...globalProps,
    as: String,
    crossorigin: String,
    disabled: Boolean,
    fetchpriority: String,
    href: String,
    hreflang: String,
    imagesizes: String,
    imagesrcset: String,
    integrity: String,
    media: String,
    prefetch: {
      type: Boolean,
      default: void 0
    },
    referrerpolicy: String,
    rel: String,
    sizes: String,
    title: String,
    type: String,
    /** @deprecated **/
    methods: String,
    /** @deprecated **/
    target: String,
    body: Boolean,
    renderPriority: [String, Number]
  },
  setup: setupForUseMeta((link) => ({
    link: [link]
  }))
});
const Title = /* @__PURE__ */ defineComponent({
  // eslint-disable-next-line vue/no-reserved-component-names
  name: "Title",
  inheritAttrs: false,
  setup: setupForUseMeta((_, { slots }) => {
    var _a, _b, _c;
    return {
      title: ((_c = (_b = (_a = slots.default) == null ? void 0 : _a.call(slots)) == null ? void 0 : _b[0]) == null ? void 0 : _c.children) || null
    };
  })
});
const Head = /* @__PURE__ */ defineComponent({
  // eslint-disable-next-line vue/no-reserved-component-names
  name: "Head",
  inheritAttrs: false,
  setup: (_props, ctx) => () => {
    var _a, _b;
    return (_b = (_a = ctx.slots).default) == null ? void 0 : _b.call(_a);
  }
});
const _sfc_main$7 = /* @__PURE__ */ defineComponent({
  __name: "Menu",
  __ssrInlineRender: true,
  setup(__props) {
    useAuthStore();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0;
      const _component_nuxt_icon = _sfc_main$8;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-beige p-4 xl:p-3 flex flex-col gap-8 xl:gap-5 shadow-32 rounded-lg mt-4 min-w-fit cursor-default" }, _attrs))} data-v-abdc4926><div class="flex flex-col gap-4 xl:gap-3" data-v-abdc4926><p class="font-bold text-xl xl:text-base text-dark-100" data-v-abdc4926>Profil</p><p class="py-3 xl:py-2 px-4 xl:px-3 xl:text-xs text-dark-100" data-v-abdc4926>Ubah Informasi Profil</p><p class="py-3 xl:py-2 px-4 xl:px-3 xl:text-xs text-dark-100" data-v-abdc4926>Ubah Password</p></div><div class="spacer" data-v-abdc4926></div><div class="flex flex-col gap-4 xl:gap-3" data-v-abdc4926><p class="font-bold text-xl xl:text-base text-dark-100" data-v-abdc4926>Lelang/Tiket</p><p class="py-3 xl:py-2 px-4 xl:px-3 xl:text-xs text-dark-100" data-v-abdc4926>daftar Menjadi Partner HO</p><p class="py-3 xl:py-2 px-4 xl:px-3 xl:text-xs text-dark-100" data-v-abdc4926>Buat Lelang/Tiket Konser Baru</p><p class="py-3 xl:py-2 px-4 xl:px-3 xl:text-xs text-dark-100" data-v-abdc4926>`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/PenjualanSaya" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Lihat Penjualan Saya`);
          } else {
            return [
              createTextVNode("Lihat Penjualan Saya")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</p></div><div class="spacer" data-v-abdc4926></div><div class="flex flex-col gap-4 xl:gap-3" data-v-abdc4926><p class="font-bold text-xl xl:text-base text-dark-100" data-v-abdc4926>Transaksi</p><p class="py-3 xl:py-2 px-4 xl:px-3 xl:text-xs text-dark-100" data-v-abdc4926>`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/Transaksi" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Lihat Transaksi`);
          } else {
            return [
              createTextVNode("Lihat Transaksi")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</p></div><div class="spacer" data-v-abdc4926></div><div class="flex flex-col gap-4 xl:gap-3" data-v-abdc4926><p class="font-bold text-xl xl:text-base text-dark-100" data-v-abdc4926>Saldo</p><div class="flex py-3 xl:py-2 px-4 xl:px-3 gap-4 xl:gap-3 min-w-max justify-between" data-v-abdc4926><div class="flex gap-4 xl:gap-3" data-v-abdc4926>`);
      _push(ssrRenderComponent(_component_nuxt_icon, {
        name: "e_wallet",
        class: "text-xl xl:text-base text-dark-100"
      }, null, _parent));
      _push(`<p class="text-dark-100 xl:text-xs" data-v-abdc4926>Saldo Utama</p></div><p class="text-dark-100 font-bold ml-4 xl:text-xs" data-v-abdc4926>Rp. 2.000.000</p></div><div class="flex py-3 xl:py-2 px-4 xl:px-3 gap-4 xl:gap-3 justify-between" data-v-abdc4926><div class="flex gap-4 xl:gap-3" data-v-abdc4926>`);
      _push(ssrRenderComponent(_component_nuxt_icon, {
        name: "verified",
        class: "text-xl xl:text-base text-dark-100"
      }, null, _parent));
      _push(`<p class="text-dark-100 xl:text-xs" data-v-abdc4926>Reward</p></div><p class="text-dark-100 font-bold xl:text-xs" data-v-abdc4926>8.898</p></div></div><div class="spacer" data-v-abdc4926></div><div class="flex flex-col gap-4 xl:gap-3" data-v-abdc4926><p class="font-bold text-xl xl:text-base text-dark-100" data-v-abdc4926>Pengaturan</p><div class="flex gap-4 xl:gap-3 py-3 xl:py-2 px-4 xl:px-3 cursor-pointer items-center" data-v-abdc4926>`);
      _push(ssrRenderComponent(_component_nuxt_icon, {
        name: "logout",
        class: "text-xl xl:text-base text-red-100"
      }, null, _parent));
      _push(`<p class="text-red-100 xl:text-xs" data-v-abdc4926>Logout</p></div></div></div>`);
    };
  }
});
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/User/Menu.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$7, [["__scopeId", "data-v-abdc4926"]]);
const _imports_0$2 = "" + publicAssetsURL("img/user.png");
const _sfc_main$6 = /* @__PURE__ */ defineComponent({
  __name: "Header",
  __ssrInlineRender: true,
  setup(__props) {
    const userMenu = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_nuxt_icon = _sfc_main$8;
      const _component_UserMenu = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex gap-4 xl:gap-3 items-center text-dark-100 relative" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_nuxt_icon, {
        name: "shopping_cart",
        class: "text-xl xl:text-base p-[6px] xl:p-1 cursor-pointer border-solid border border-dark-20 rounded-lg"
      }, null, _parent));
      _push(ssrRenderComponent(_component_nuxt_icon, {
        name: "bell",
        class: "text-xl xl:text-base p-[6px] xl:p-1 cursor-pointer border-solid border border-dark-20 rounded-lg"
      }, null, _parent));
      _push(`<div class="flex gap-4 xl:gap-3 cursor-pointer items-center"><img${ssrRenderAttr("src", _imports_0$2)} alt="User" class="w-9 xl:w-6"><p class="font-semibold xl:text-sm select-none">Asep Saepudin</p>`);
      _push(ssrRenderComponent(_component_UserMenu, {
        style: unref(userMenu) ? null : { display: "none" },
        onClick: () => {
        },
        class: "absolute top-full"
      }, null, _parent));
      _push(`</div></div>`);
    };
  }
});
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/User/Header.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const _imports_0$1 = "" + buildAssetsURL("google.0d6251f6.svg");
const _imports_1 = "" + buildAssetsURL("facebook.a8b27b68.svg");
const _imports_2 = "" + buildAssetsURL("instagram.5829a46a.svg");
const _sfc_main$5 = /* @__PURE__ */ defineComponent({
  __name: "Login",
  __ssrInlineRender: true,
  emits: [
    "close",
    "register",
    "login"
  ],
  setup(__props, { emit }) {
    const passwordState = ref(true);
    const showPassword = computed(() => {
      return passwordState.value ? "password" : "text";
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ModalsOverlay = __nuxt_component_0$1;
      const _component_nuxt_icon = _sfc_main$8;
      _push(ssrRenderComponent(_component_ModalsOverlay, mergeProps({
        onClick: ($event) => emit("close")
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="bg-beige p-16 2xl:p-11 rounded-lg modals-container flex flex-col gap32" data-v-ed88f856${_scopeId}>`);
            _push2(ssrRenderComponent(_component_nuxt_icon, {
              onClick: ($event) => emit("close"),
              name: "close",
              alt: "",
              class: "text24 self-end cursor-pointer"
            }, null, _parent2, _scopeId));
            _push2(`<div data-v-ed88f856${_scopeId}><h2 class="text-dark-100 text32 font-bold text-center mb-3 2xl:mb-2" data-v-ed88f856${_scopeId}>Login Disini!</h2><h3 class="text-dark-100 font-normal text24 text-center" data-v-ed88f856${_scopeId}>Halo bidders... silahkan login di bawah untuk melakukan bidding atau transaksi lelangan.</h3></div><form class="flex flex-col gap32" data-v-ed88f856${_scopeId}><div class="flex flex-col gap16" data-v-ed88f856${_scopeId}><p class="text16 text-dark-100" data-v-ed88f856${_scopeId}>Email</p><label class="flex relative" data-v-ed88f856${_scopeId}><input type="email" placeholder="Email" required class="py-4 pr-4 2xl:py-3 pl-14 2xl:pl-10 rounded-lg font-normal text20 text-dark-100 placeholder:text-dark-50 w-full" data-v-ed88f856${_scopeId}>`);
            _push2(ssrRenderComponent(_component_nuxt_icon, {
              name: "email",
              alt: "email",
              class: "text24 absolute top-1/2 -translate-y-1/2 left-4 xl:left-3"
            }, null, _parent2, _scopeId));
            _push2(`</label><p class="text16 text-dark-100" data-v-ed88f856${_scopeId}>Password</p><label class="flex relative" data-v-ed88f856${_scopeId}><input${ssrRenderAttr("type", unref(showPassword))} placeholder="Password" required class="py-4 2xl:py-3 px-14 2xl:px-10 rounded-lg font-normal text20 text-dark-100 placeholder:text-dark-50 w-full" data-v-ed88f856${_scopeId}>`);
            _push2(ssrRenderComponent(_component_nuxt_icon, {
              name: "lock",
              class: "text24 absolute top-1/2 -translate-y-1/2 left-4 xl:left-3"
            }, null, _parent2, _scopeId));
            _push2(`<div class="absolute right-0 flex items-center justify-center h-full w-14 2xl:w-10 cursor-pointer" data-v-ed88f856${_scopeId}>`);
            _push2(ssrRenderComponent(_component_nuxt_icon, {
              name: "eye",
              class: "text24"
            }, null, _parent2, _scopeId));
            _push2(`</div></label></div><p class="text-blue-100 text-lg 2xl:text-sm italic cursor-pointer" data-v-ed88f856${_scopeId}>Belum punya akun? Daftar disini!</p><button class="py-4 2xl:py-3 bg-yellow-100 text-dark-100 font-bold text24 rounded-lg" data-v-ed88f856${_scopeId}> Login </button></form><p class="text-lg 2xl:text-sm text-dark-100 text-center" data-v-ed88f856${_scopeId}>Atau login menggunakan</p><div class="flex gap16" data-v-ed88f856${_scopeId}><div class="bg-white flex items-center grow cursor-pointer select-none p-4 2xl:p-3 rounded-lg border-dark-20 border-solid border" data-v-ed88f856${_scopeId}><img${ssrRenderAttr("src", _imports_0$1)} alt="Google Logo" class="w-6 2xl:w-5 xl:w-4 mr-4 2xl:mr-3" data-v-ed88f856${_scopeId}><p class="text-lg 2xl:text-base xl:text-sm text-dark-50" data-v-ed88f856${_scopeId}>Google</p></div><div class="bg-white flex items-center grow cursor-pointer select-none p-4 2xl:p-3 rounded-lg border-dark-20 border-solid border" data-v-ed88f856${_scopeId}><img${ssrRenderAttr("src", _imports_1)} alt="Facebook Logo" class="w-6 2xl:w-5 xl:w-4 mr-4 2xl:mr-3" data-v-ed88f856${_scopeId}><p class="text-lg 2xl:text-base xl:text-sm text-dark-50" data-v-ed88f856${_scopeId}>Facebook</p></div><div class="bg-white flex items-center grow cursor-pointer select-none p-4 2xl:p-3 rounded-lg border-dark-20 border-solid border" data-v-ed88f856${_scopeId}><img${ssrRenderAttr("src", _imports_2)} alt="Instagram Logo" class="w-6 2xl:w-5 xl:w-4 mr-4 2xl:mr-3" data-v-ed88f856${_scopeId}><p class="text-lg 2xl:text-base xl:text-sm text-dark-50" data-v-ed88f856${_scopeId}>Instagram</p></div></div></div>`);
          } else {
            return [
              createVNode("div", {
                onClick: withModifiers(() => {
                }, ["stop"]),
                class: "bg-beige p-16 2xl:p-11 rounded-lg modals-container flex flex-col gap32"
              }, [
                createVNode(_component_nuxt_icon, {
                  onClick: ($event) => emit("close"),
                  name: "close",
                  alt: "",
                  class: "text24 self-end cursor-pointer"
                }, null, 8, ["onClick"]),
                createVNode("div", null, [
                  createVNode("h2", { class: "text-dark-100 text32 font-bold text-center mb-3 2xl:mb-2" }, "Login Disini!"),
                  createVNode("h3", { class: "text-dark-100 font-normal text24 text-center" }, "Halo bidders... silahkan login di bawah untuk melakukan bidding atau transaksi lelangan.")
                ]),
                createVNode("form", {
                  onSubmit: withModifiers(() => {
                  }, ["prevent"]),
                  class: "flex flex-col gap32"
                }, [
                  createVNode("div", { class: "flex flex-col gap16" }, [
                    createVNode("p", { class: "text16 text-dark-100" }, "Email"),
                    createVNode("label", { class: "flex relative" }, [
                      createVNode("input", {
                        type: "email",
                        placeholder: "Email",
                        required: "",
                        class: "py-4 pr-4 2xl:py-3 pl-14 2xl:pl-10 rounded-lg font-normal text20 text-dark-100 placeholder:text-dark-50 w-full"
                      }),
                      createVNode(_component_nuxt_icon, {
                        name: "email",
                        alt: "email",
                        class: "text24 absolute top-1/2 -translate-y-1/2 left-4 xl:left-3"
                      })
                    ]),
                    createVNode("p", { class: "text16 text-dark-100" }, "Password"),
                    createVNode("label", { class: "flex relative" }, [
                      createVNode("input", {
                        type: unref(showPassword),
                        placeholder: "Password",
                        required: "",
                        class: "py-4 2xl:py-3 px-14 2xl:px-10 rounded-lg font-normal text20 text-dark-100 placeholder:text-dark-50 w-full"
                      }, null, 8, ["type"]),
                      createVNode(_component_nuxt_icon, {
                        name: "lock",
                        class: "text24 absolute top-1/2 -translate-y-1/2 left-4 xl:left-3"
                      }),
                      createVNode("div", {
                        onClick: ($event) => passwordState.value = !unref(passwordState),
                        class: "absolute right-0 flex items-center justify-center h-full w-14 2xl:w-10 cursor-pointer"
                      }, [
                        createVNode(_component_nuxt_icon, {
                          name: "eye",
                          class: "text24"
                        })
                      ], 8, ["onClick"])
                    ])
                  ]),
                  createVNode("p", {
                    class: "text-blue-100 text-lg 2xl:text-sm italic cursor-pointer",
                    onClick: ($event) => emit("register")
                  }, "Belum punya akun? Daftar disini!", 8, ["onClick"]),
                  createVNode("button", {
                    onClick: ($event) => emit("login"),
                    class: "py-4 2xl:py-3 bg-yellow-100 text-dark-100 font-bold text24 rounded-lg"
                  }, " Login ", 8, ["onClick"])
                ], 40, ["onSubmit"]),
                createVNode("p", { class: "text-lg 2xl:text-sm text-dark-100 text-center" }, "Atau login menggunakan"),
                createVNode("div", { class: "flex gap16" }, [
                  createVNode("div", { class: "bg-white flex items-center grow cursor-pointer select-none p-4 2xl:p-3 rounded-lg border-dark-20 border-solid border" }, [
                    createVNode("img", {
                      src: _imports_0$1,
                      alt: "Google Logo",
                      class: "w-6 2xl:w-5 xl:w-4 mr-4 2xl:mr-3"
                    }),
                    createVNode("p", { class: "text-lg 2xl:text-base xl:text-sm text-dark-50" }, "Google")
                  ]),
                  createVNode("div", { class: "bg-white flex items-center grow cursor-pointer select-none p-4 2xl:p-3 rounded-lg border-dark-20 border-solid border" }, [
                    createVNode("img", {
                      src: _imports_1,
                      alt: "Facebook Logo",
                      class: "w-6 2xl:w-5 xl:w-4 mr-4 2xl:mr-3"
                    }),
                    createVNode("p", { class: "text-lg 2xl:text-base xl:text-sm text-dark-50" }, "Facebook")
                  ]),
                  createVNode("div", { class: "bg-white flex items-center grow cursor-pointer select-none p-4 2xl:p-3 rounded-lg border-dark-20 border-solid border" }, [
                    createVNode("img", {
                      src: _imports_2,
                      alt: "Instagram Logo",
                      class: "w-6 2xl:w-5 xl:w-4 mr-4 2xl:mr-3"
                    }),
                    createVNode("p", { class: "text-lg 2xl:text-base xl:text-sm text-dark-50" }, "Instagram")
                  ])
                ])
              ], 8, ["onClick"])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Modals/Login.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const __nuxt_component_3$1 = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["__scopeId", "data-v-ed88f856"]]);
const _sfc_main$4 = /* @__PURE__ */ defineComponent({
  __name: "Register",
  __ssrInlineRender: true,
  emits: [
    "close"
  ],
  setup(__props, { emit }) {
    const passwordState = ref(true);
    const passwordState2 = ref(true);
    const showPassword = computed(() => {
      return passwordState.value ? "password" : "text";
    });
    const showPassword2 = computed(() => {
      return passwordState2.value ? "password" : "text";
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ModalsOverlay = __nuxt_component_0$1;
      const _component_nuxt_icon = _sfc_main$8;
      _push(ssrRenderComponent(_component_ModalsOverlay, mergeProps({
        onClick: ($event) => emit("close")
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="bg-beige p-16 2xl:p-8 rounded-lg modals-container flex flex-col gap32" data-v-f127e67d${_scopeId}>`);
            _push2(ssrRenderComponent(_component_nuxt_icon, {
              onClick: ($event) => emit("close"),
              name: "close",
              alt: "",
              class: "text24 self-end cursor-pointer"
            }, null, _parent2, _scopeId));
            _push2(`<div data-v-f127e67d${_scopeId}><h2 class="text-dark-100 text32 font-bold text-center mb-3 2xl:mb-2" data-v-f127e67d${_scopeId}> Daftar Disini! </h2><h3 class="text-dark-100 font-medium px-2 text24 text-center" data-v-f127e67d${_scopeId}> Halo bidders... belum punya akun? Silahkan daftar di bawah ini!</h3></div><form class="flex flex-col gap32" data-v-f127e67d${_scopeId}><div class="flex flex-col gap16" data-v-f127e67d${_scopeId}><p class="text16 text-dark-100" data-v-f127e67d${_scopeId}>Nama</p><label class="flex relative" data-v-f127e67d${_scopeId}><input type="text" placeholder="Nama Lengkap" required class="py-3 pr-4 2xl:py-2 pl-14 2xl:pl-10 rounded-lg font-normal text20 text-dark-100 placeholder:text-dark-50 w-full" data-v-f127e67d${_scopeId}>`);
            _push2(ssrRenderComponent(_component_nuxt_icon, {
              name: "person",
              class: "text24 absolute top-1/2 -translate-y-1/2 left-4 2xl:left-3"
            }, null, _parent2, _scopeId));
            _push2(`</label><p class="text16 text-dark-100" data-v-f127e67d${_scopeId}>Email</p><label class="flex relative" data-v-f127e67d${_scopeId}><input type="email" placeholder="Email" required class="py-3 pr-4 2xl:py-2 pl-14 2xl:pl-10 rounded-lg font-normal text20 text-dark-100 placeholder:text-dark-50 w-full" data-v-f127e67d${_scopeId}>`);
            _push2(ssrRenderComponent(_component_nuxt_icon, {
              name: "email",
              class: "text24 absolute top-1/2 -translate-y-1/2 left-4 2xl:left-3"
            }, null, _parent2, _scopeId));
            _push2(`</label><p class="text16 text-dark-100" data-v-f127e67d${_scopeId}>Password</p><label class="flex relative" data-v-f127e67d${_scopeId}><input${ssrRenderAttr("type", unref(showPassword))} placeholder="Password" required class="py-3 2xl:py-2 px-14 2xl:px-10 rounded-lg font-normal text20 text-dark-100 placeholder:text-dark-50 w-full" data-v-f127e67d${_scopeId}>`);
            _push2(ssrRenderComponent(_component_nuxt_icon, {
              name: "lock",
              class: "text24 absolute top-1/2 -translate-y-1/2 left-4 2xl:left-3"
            }, null, _parent2, _scopeId));
            _push2(`<div class="absolute right-0 flex items-center justify-center h-full w-14 2xl:w-10 cursor-pointer" data-v-f127e67d${_scopeId}>`);
            _push2(ssrRenderComponent(_component_nuxt_icon, {
              name: "eye",
              class: "text24"
            }, null, _parent2, _scopeId));
            _push2(`</div></label><p class="text16 text-dark-100" data-v-f127e67d${_scopeId}>Ulangi Password</p><label class="flex relative" data-v-f127e67d${_scopeId}><input${ssrRenderAttr("type", unref(showPassword2))} placeholder="Ulangi Password" required class="py-3 2xl:py-2 px-14 2xl:px-10 rounded-lg font-normal text20 text-dark-100 placeholder:text-dark-50 w-full" data-v-f127e67d${_scopeId}>`);
            _push2(ssrRenderComponent(_component_nuxt_icon, {
              name: "lock",
              class: "text24 absolute top-1/2 -translate-y-1/2 left-4 2xl:left-3"
            }, null, _parent2, _scopeId));
            _push2(`<div class="absolute right-0 flex items-center justify-center h-full w-14 2xl:w-10 cursor-pointer" data-v-f127e67d${_scopeId}>`);
            _push2(ssrRenderComponent(_component_nuxt_icon, {
              name: "eye",
              class: "text24"
            }, null, _parent2, _scopeId));
            _push2(`</div></label></div><button class="py-4 2xl:py-3 bg-yellow-100 text-dark-100 font-bold text24 rounded-lg" data-v-f127e67d${_scopeId}> Daftar </button></form><p class="text-lg 2xl:text-base xl:text-sm text-dark-100 text-center" data-v-f127e67d${_scopeId}>Atau daftar menggunakan</p><div class="flex gap16" data-v-f127e67d${_scopeId}><div class="bg-white flex items-center grow cursor-pointer select-none p-4 2xl:p-3 rounded-lg border-dark-20 border-solid border" data-v-f127e67d${_scopeId}><img${ssrRenderAttr("src", _imports_0$1)} alt="Google Logo" class="w-6 2xl:w-5 xl:w-4 mr-4 2xl:mr-3" data-v-f127e67d${_scopeId}><p class="text-lg 2xl:text-base xl:text-sm text-dark-50" data-v-f127e67d${_scopeId}>Google</p></div><div class="bg-white flex items-center grow cursor-pointer select-none p-4 2xl:p-3 rounded-lg border-dark-20 border-solid border" data-v-f127e67d${_scopeId}><img${ssrRenderAttr("src", _imports_1)} alt="Facebook Logo" class="w-6 2xl:w-5 xl:w-4 mr-4 2xl:mr-3" data-v-f127e67d${_scopeId}><p class="text-lg 2xl:text-base xl:text-sm text-dark-50" data-v-f127e67d${_scopeId}>Facebook</p></div><div class="bg-white flex items-center grow cursor-pointer select-none p-4 2xl:p-3 rounded-lg border-dark-20 border-solid border" data-v-f127e67d${_scopeId}><img${ssrRenderAttr("src", _imports_2)} alt="Instagram Logo" class="w-6 2xl:w-5 xl:w-4 mr-4 2xl:mr-3" data-v-f127e67d${_scopeId}><p class="text-lg 2xl:text-base xl:text-sm text-dark-50" data-v-f127e67d${_scopeId}>Instagram</p></div></div></div>`);
          } else {
            return [
              createVNode("div", {
                class: "bg-beige p-16 2xl:p-8 rounded-lg modals-container flex flex-col gap32",
                onClick: withModifiers(() => {
                }, ["stop"])
              }, [
                createVNode(_component_nuxt_icon, {
                  onClick: ($event) => emit("close"),
                  name: "close",
                  alt: "",
                  class: "text24 self-end cursor-pointer"
                }, null, 8, ["onClick"]),
                createVNode("div", null, [
                  createVNode("h2", { class: "text-dark-100 text32 font-bold text-center mb-3 2xl:mb-2" }, " Daftar Disini! "),
                  createVNode("h3", { class: "text-dark-100 font-medium px-2 text24 text-center" }, " Halo bidders... belum punya akun? Silahkan daftar di bawah ini!")
                ]),
                createVNode("form", {
                  onSubmit: withModifiers(() => {
                  }, ["prevent"]),
                  class: "flex flex-col gap32"
                }, [
                  createVNode("div", { class: "flex flex-col gap16" }, [
                    createVNode("p", { class: "text16 text-dark-100" }, "Nama"),
                    createVNode("label", { class: "flex relative" }, [
                      createVNode("input", {
                        type: "text",
                        placeholder: "Nama Lengkap",
                        required: "",
                        class: "py-3 pr-4 2xl:py-2 pl-14 2xl:pl-10 rounded-lg font-normal text20 text-dark-100 placeholder:text-dark-50 w-full"
                      }),
                      createVNode(_component_nuxt_icon, {
                        name: "person",
                        class: "text24 absolute top-1/2 -translate-y-1/2 left-4 2xl:left-3"
                      })
                    ]),
                    createVNode("p", { class: "text16 text-dark-100" }, "Email"),
                    createVNode("label", { class: "flex relative" }, [
                      createVNode("input", {
                        type: "email",
                        placeholder: "Email",
                        required: "",
                        class: "py-3 pr-4 2xl:py-2 pl-14 2xl:pl-10 rounded-lg font-normal text20 text-dark-100 placeholder:text-dark-50 w-full"
                      }),
                      createVNode(_component_nuxt_icon, {
                        name: "email",
                        class: "text24 absolute top-1/2 -translate-y-1/2 left-4 2xl:left-3"
                      })
                    ]),
                    createVNode("p", { class: "text16 text-dark-100" }, "Password"),
                    createVNode("label", { class: "flex relative" }, [
                      createVNode("input", {
                        type: unref(showPassword),
                        placeholder: "Password",
                        required: "",
                        class: "py-3 2xl:py-2 px-14 2xl:px-10 rounded-lg font-normal text20 text-dark-100 placeholder:text-dark-50 w-full"
                      }, null, 8, ["type"]),
                      createVNode(_component_nuxt_icon, {
                        name: "lock",
                        class: "text24 absolute top-1/2 -translate-y-1/2 left-4 2xl:left-3"
                      }),
                      createVNode("div", {
                        onClick: ($event) => passwordState.value = !unref(passwordState),
                        class: "absolute right-0 flex items-center justify-center h-full w-14 2xl:w-10 cursor-pointer"
                      }, [
                        createVNode(_component_nuxt_icon, {
                          name: "eye",
                          class: "text24"
                        })
                      ], 8, ["onClick"])
                    ]),
                    createVNode("p", { class: "text16 text-dark-100" }, "Ulangi Password"),
                    createVNode("label", { class: "flex relative" }, [
                      createVNode("input", {
                        type: unref(showPassword2),
                        placeholder: "Ulangi Password",
                        required: "",
                        class: "py-3 2xl:py-2 px-14 2xl:px-10 rounded-lg font-normal text20 text-dark-100 placeholder:text-dark-50 w-full"
                      }, null, 8, ["type"]),
                      createVNode(_component_nuxt_icon, {
                        name: "lock",
                        class: "text24 absolute top-1/2 -translate-y-1/2 left-4 2xl:left-3"
                      }),
                      createVNode("div", {
                        onClick: ($event) => passwordState2.value = !unref(passwordState2),
                        class: "absolute right-0 flex items-center justify-center h-full w-14 2xl:w-10 cursor-pointer"
                      }, [
                        createVNode(_component_nuxt_icon, {
                          name: "eye",
                          class: "text24"
                        })
                      ], 8, ["onClick"])
                    ])
                  ]),
                  createVNode("button", { class: "py-4 2xl:py-3 bg-yellow-100 text-dark-100 font-bold text24 rounded-lg" }, " Daftar ")
                ], 40, ["onSubmit"]),
                createVNode("p", { class: "text-lg 2xl:text-base xl:text-sm text-dark-100 text-center" }, "Atau daftar menggunakan"),
                createVNode("div", { class: "flex gap16" }, [
                  createVNode("div", { class: "bg-white flex items-center grow cursor-pointer select-none p-4 2xl:p-3 rounded-lg border-dark-20 border-solid border" }, [
                    createVNode("img", {
                      src: _imports_0$1,
                      alt: "Google Logo",
                      class: "w-6 2xl:w-5 xl:w-4 mr-4 2xl:mr-3"
                    }),
                    createVNode("p", { class: "text-lg 2xl:text-base xl:text-sm text-dark-50" }, "Google")
                  ]),
                  createVNode("div", { class: "bg-white flex items-center grow cursor-pointer select-none p-4 2xl:p-3 rounded-lg border-dark-20 border-solid border" }, [
                    createVNode("img", {
                      src: _imports_1,
                      alt: "Facebook Logo",
                      class: "w-6 2xl:w-5 xl:w-4 mr-4 2xl:mr-3"
                    }),
                    createVNode("p", { class: "text-lg 2xl:text-base xl:text-sm text-dark-50" }, "Facebook")
                  ]),
                  createVNode("div", { class: "bg-white flex items-center grow cursor-pointer select-none p-4 2xl:p-3 rounded-lg border-dark-20 border-solid border" }, [
                    createVNode("img", {
                      src: _imports_2,
                      alt: "Instagram Logo",
                      class: "w-6 2xl:w-5 xl:w-4 mr-4 2xl:mr-3"
                    }),
                    createVNode("p", { class: "text-lg 2xl:text-base xl:text-sm text-dark-50" }, "Instagram")
                  ])
                ])
              ], 8, ["onClick"])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Modals/Register.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_4$1 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["__scopeId", "data-v-f127e67d"]]);
const _imports_0 = "" + publicAssetsURL("img/logo.png");
const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "Header",
  __ssrInlineRender: true,
  setup(__props) {
    const modalLogin = ref(false);
    const modalRegister = ref(false);
    const authStore = useAuthStore();
    const showRegister = () => {
      modalLogin.value = false;
      modalRegister.value = true;
    };
    const login = () => {
      authStore.login();
      modalLogin.value = false;
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0;
      const _component_Button = __nuxt_component_0$2;
      const _component_UserHeader = _sfc_main$6;
      const _component_ModalsLogin = __nuxt_component_3$1;
      const _component_ModalsRegister = __nuxt_component_4$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "defaultheader flex items-center justify-between px-60 xl:px-40 sm:p-4 border-b border-solid border-dark-20 dark:border-white-20" }, _attrs))} data-v-58adf75d><img${ssrRenderAttr("src", _imports_0)} alt="Logo" class="my-6 2xl:my-4 w-[156px] 2xl:w-[126px] xl:w-28 sm:hidden" data-v-58adf75d><div class="flex items-center gap-8 xl:gap-5 sm:gap-2" data-v-58adf75d>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/",
        class: "text24 font-bold text-inherit-50 hover:text-inherit"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Beranda `);
          } else {
            return [
              createTextVNode(" Beranda ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="spacer bg-dark-20 dark:bg-white-20" data-v-58adf75d></div>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/story",
        class: "text24 font-bold text-inherit-50 hover:text-inherit"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Cerita `);
          } else {
            return [
              createTextVNode(" Cerita ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="spacer bg-dark-20 dark:bg-white-20" data-v-58adf75d></div>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/favorite",
        class: "text24 font-bold text-inherit-50 hover:text-inherit"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Favorit `);
          } else {
            return [
              createTextVNode(" Favorit ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
      if (!unref(authStore).loginStatus) {
        _push(`<div class="flex sm:hidden" data-v-58adf75d>`);
        _push(ssrRenderComponent(_component_Button, {
          class: "text-inherit-50 hover:text-inherit mr-4 font-bold text16",
          onClick: ($event) => modalLogin.value = true
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`Login`);
            } else {
              return [
                createTextVNode("Login")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(ssrRenderComponent(_component_Button, {
          class: "bg-primary text-dark-100 font-bold text16",
          onClick: ($event) => modalRegister.value = true
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`Daftar`);
            } else {
              return [
                createTextVNode("Daftar")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div>`);
      } else {
        _push(`<div data-v-58adf75d>`);
        _push(ssrRenderComponent(_component_UserHeader, null, null, _parent));
        _push(`</div>`);
      }
      if (unref(modalLogin)) {
        _push(ssrRenderComponent(_component_ModalsLogin, {
          onClose: ($event) => modalLogin.value = false,
          onRegister: showRegister,
          onLogin: login
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(modalRegister)) {
        _push(ssrRenderComponent(_component_ModalsRegister, {
          onClose: ($event) => modalRegister.value = false
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
});
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Header.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_3 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["__scopeId", "data-v-58adf75d"]]);
const _sfc_main$2 = {
  __name: "FilterNav",
  __ssrInlineRender: true,
  setup(__props) {
    const route = useRoute();
    const storyRoute = computed(() => route.name.includes("story"));
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Button = __nuxt_component_0$2;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex gap-2 justify-center sm:justify-start border-solid border-b border-dark-20 dark:border-white-20 p-2 2xl:p-1 sm:px-4 overflow-scroll no-scrollbar" }, _attrs))} data-v-631a0a90>`);
      _push(ssrRenderComponent(_component_Button, { class: "text-inherit-50 hover:text-inherit font-medium text-sm 2xl:text-xs active" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Semua ${ssrInterpolate(unref(storyRoute) ? "Cerita" : "Barang")}`);
          } else {
            return [
              createTextVNode(" Semua " + toDisplayString(unref(storyRoute) ? "Cerita" : "Barang"), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_Button, { class: "text-inherit-50 hover:text-inherit font-medium text-sm 2xl:text-xs" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Musisi `);
          } else {
            return [
              createTextVNode(" Musisi ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_Button, { class: "text-inherit-50 hover:text-inherit font-medium text-sm 2xl:text-xs" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Seniman `);
          } else {
            return [
              createTextVNode(" Seniman ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_Button, { class: "text-inherit-50 hover:text-inherit font-medium text-sm 2xl:text-xs" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Olahragawan `);
          } else {
            return [
              createTextVNode(" Olahragawan ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_Button, { class: "text-inherit-50 hover:text-inherit font-medium text-sm 2xl:text-xs" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Aktris `);
          } else {
            return [
              createTextVNode(" Aktris ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_Button, { class: "text-inherit-50 hover:text-inherit font-medium text-sm 2xl:text-xs" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Negarawan `);
          } else {
            return [
              createTextVNode(" Negarawan ")
            ];
          }
        }),
        _: 1
      }, _parent));
      if (!unref(storyRoute)) {
        _push(ssrRenderComponent(_component_Button, { class: "text-inherit-50 hover:text-inherit font-medium text-sm 2xl:text-xs" }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` Tiket Konser `);
            } else {
              return [
                createTextVNode(" Tiket Konser ")
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/FilterNav.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_4 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-631a0a90"]]);
const _sfc_main$1 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_NuxtLink = __nuxt_component_0;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "defaultfooter mt-52 xl:mt-36 px-60 2xl:px-48 xl:px-40 py-24 2xl:py-16 sm:p-4 bg-dark-100 dark:bg-darkGrey-100" }, _attrs))} data-v-66a8c74b><div class="flex justify-between" data-v-66a8c74b><div class="column-wrapper" data-v-66a8c74b><h3 data-v-66a8c74b>Navigasi</h3><p data-v-66a8c74b>Beranda</p><p data-v-66a8c74b>Lelang Terbaru</p><p data-v-66a8c74b>Favorit</p></div><div class="column-wrapper" data-v-66a8c74b><h3 data-v-66a8c74b>Tentang</h3><p data-v-66a8c74b>`);
  _push(ssrRenderComponent(_component_NuxtLink, { to: "/aboutUs" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Tentang Kami`);
      } else {
        return [
          createTextVNode("Tentang Kami")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</p><p data-v-66a8c74b>Kontak Kami</p><p data-v-66a8c74b>FAQ</p></div><div class="column-wrapper sm:hidden" data-v-66a8c74b><h3 data-v-66a8c74b>Filter</h3><p data-v-66a8c74b>Barang Bekas Artis</p><p data-v-66a8c74b>Pusaka</p><p data-v-66a8c74b>Benda Bersejarah</p><p data-v-66a8c74b>Teknologi</p><p data-v-66a8c74b>Fashion</p><p data-v-66a8c74b>Tiket Konser</p></div><div class="column-wrapper" data-v-66a8c74b><h3 data-v-66a8c74b>Anekaragam</h3><p data-v-66a8c74b>About Us</p><p data-v-66a8c74b>Contact Us</p><p data-v-66a8c74b>FAQ</p></div><div class="column-wrapper" data-v-66a8c74b><h3 data-v-66a8c74b>Sosial</h3><p data-v-66a8c74b>Twitter</p><p data-v-66a8c74b>Facebook</p><p data-v-66a8c74b>Instagram</p><p data-v-66a8c74b>Linkedin</p></div></div><h4 data-v-66a8c74b>Copyright \xA9 2023 History Outlet. All rights reserved.</h4></div>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Footer.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_5 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender], ["__scopeId", "data-v-66a8c74b"]]);
const _sfc_main = {
  __name: "default",
  __ssrInlineRender: true,
  setup(__props) {
    const showFilterList = ["index", "story"];
    const darkMode = useState("darkMode", () => void 0);
    const route = useRoute();
    const showFilter = computed(() => showFilterList.includes(route.name));
    const changeTheme = (dark) => {
      if (dark) {
        document.documentElement.classList.add("dark");
      } else {
        document.documentElement.classList.remove("dark");
      }
      localStorage.setItem("darkMode", dark ? "true" : "false");
    };
    watch(darkMode, (dark) => {
      changeTheme(dark);
    });
    useHead({
      script: [{
        children: `if (localStorage.darkMode === "true") {
      document.documentElement.classList.add('dark')
    }`
      }]
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Head = Head;
      const _component_Title = Title;
      const _component_Link = Link;
      const _component_Header = __nuxt_component_3;
      const _component_FilterNav = __nuxt_component_4;
      const _component_Footer = __nuxt_component_5;
      const _component_nuxt_icon = _sfc_main$8;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_Head, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Title, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`History Outlet`);
                } else {
                  return [
                    createTextVNode("History Outlet")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_Link, {
              rel: "preconnect",
              href: "https://fonts.googleapis.com"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_Link, {
              rel: "preconnect",
              href: "https://fonts.gstatic.com",
              crossorigin: ""
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_Link, {
              href: "https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:ital,wght@0,400;0,500;0,600;0,700;1,400&display=swap",
              rel: "stylesheet"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Title, null, {
                default: withCtx(() => [
                  createTextVNode("History Outlet")
                ]),
                _: 1
              }),
              createVNode(_component_Link, {
                rel: "preconnect",
                href: "https://fonts.googleapis.com"
              }),
              createVNode(_component_Link, {
                rel: "preconnect",
                href: "https://fonts.gstatic.com",
                crossorigin: ""
              }),
              createVNode(_component_Link, {
                href: "https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:ital,wght@0,400;0,500;0,600;0,700;1,400&display=swap",
                rel: "stylesheet"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="mb-16 2xl:mb-12 xl:mb-11">`);
      _push(ssrRenderComponent(_component_Header, null, null, _parent));
      if (unref(showFilter)) {
        _push(ssrRenderComponent(_component_FilterNav, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(ssrRenderComponent(_component_Footer, null, null, _parent));
      _push(`<div class="cursor-pointer">`);
      _push(ssrRenderComponent(_component_nuxt_icon, {
        name: unref(darkMode) ? "moon" : "sun",
        class: "text32 text-yellow-100 dark:text-white fixed bottom-[3%] right-[3%]"
      }, null, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/default.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=default-9d20bba0.mjs.map
