import { useSSRContext, defineComponent, ref, mergeProps } from 'vue';
import { u as useAuthStore } from './useAuth-653aac8a.mjs';
import { ssrRenderAttrs, ssrRenderAttr, ssrInterpolate, ssrRenderStyle, ssrRenderComponent } from 'vue/server-renderer';
import { _ as _export_sfc } from '../server.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'vue-router';

const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "Transaksi",
  __ssrInlineRender: true,
  setup(__props) {
    ref(false);
    ref(false);
    useAuthStore();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: "flex shadow-32 rounded-lg grow cursor-pointer bg-white dark:bg-darkGrey-100",
        style: { "height": "140px", "width": "718px" }
      }, _attrs))} data-v-faa1f47d><div class="flex flex-col py-7 px-6" data-v-faa1f47d><div class="w-20 h-20" data-v-faa1f47d><img${ssrRenderAttr("src", `/img/sample_${_ctx.PenjualanSaya ? "concert" : "makki"}.png`)} alt="Foto Sampel" data-v-faa1f47d></div></div><div class="flex flex-col py-6 mr-[15rem]" data-v-faa1f47d><div class="flex items-center gap-2" data-v-faa1f47d><p class="text-sm 2xl:text-[18\\px] leading-tight" data-v-faa1f47d>Musisi</p><svg xmlns="http://www.w3.org/2000/svg" width="4" height="5" viewBox="0 0 4 5" fill="none" data-v-faa1f47d><circle cx="2" cy="2.5" r="2" fill="white" fill-opacity="0.5" data-v-faa1f47d></circle></svg><p class="text-sm 2xl:text-[18px] leading-tight" data-v-faa1f47d>Lelang</p><svg xmlns="http://www.w3.org/2000/svg" width="4" height="5" viewBox="0 0 4 5" fill="none" data-v-faa1f47d><circle cx="2" cy="2.5" r="2" fill="white" fill-opacity="0.5" data-v-faa1f47d></circle></svg><p class="text-red-100" data-v-faa1f47d>kalah lelang</p></div><div class="flex flex-col mt-2 xl:flex-row xl:items-center" data-v-faa1f47d><div class="flex-1" data-v-faa1f47d><p class="text-xl 2xl:text-[20px] leading-tight font-bold" data-v-faa1f47d>${ssrInterpolate(_ctx.PenjualanSaya ? "Tiket Konser Ungu" : "Bass Putih Makki Omar Parikesit")}</p></div></div><div class="flex flex-col mt-2 xl:flex-row xl:items-center" data-v-faa1f47d><div class="flex-1" data-v-faa1f47d><p class="text-sm 2xl:text-[20px]" data-v-faa1f47d>${ssrInterpolate(_ctx.PenjualanSaya ? "Online" : "Last Bid")}: <span class="text-red-100 font-bold" data-v-faa1f47d>Rp. 110.000</span></p></div></div></div></div>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Card/Transaksi.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-faa1f47d"]]);
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_CardTransaksi = __nuxt_component_0;
  _push(`<main${ssrRenderAttrs(mergeProps({ class: "px-60 2xl:px-48 xl:px-40 sm:px-4" }, _attrs))} data-v-7cf9374b><section class="mt-32 xl:mt-24 sm:mt-8 flex flex-col gap-32 justify-center items-center" data-v-7cf9374b><div class="flex gap-4 font-medium text16 mr-[36rem] -mt-16" data-v-7cf9374b><a href="/" class="text-dark-50 cursor-pointer" data-v-7cf9374b>Beranda</a><p class="text-dark-100 cursor-default" data-v-7cf9374b>/</p><p class="text-yellow-100 cursor-pointer" data-v-7cf9374b>Transaksi</p></div><div class="mr-[17rem] -mt-24" data-v-7cf9374b><h3 style="${ssrRenderStyle({ "font-family": "'Plus Jakarta Sans'", "font-weight": "bold", "font-size": "25px" })}" data-v-7cf9374b>Lihat Semua Transaksi</h3><p class="-mt-2 xl:mt-1 font-normal font-size: 16px;" data-v-7cf9374b>Isi semua transaksi yang sedang berjalan atau sudah selesai</p></div><div class="flex flex-col gap-4 -mt-[6rem]" data-v-7cf9374b>`);
  _push(ssrRenderComponent(_component_CardTransaksi, null, null, _parent));
  _push(ssrRenderComponent(_component_CardTransaksi, null, null, _parent));
  _push(ssrRenderComponent(_component_CardTransaksi, null, null, _parent));
  _push(ssrRenderComponent(_component_CardTransaksi, null, null, _parent));
  _push(ssrRenderComponent(_component_CardTransaksi, null, null, _parent));
  _push(`</div></section></main>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/Transaksi.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Transaksi = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender], ["__scopeId", "data-v-7cf9374b"]]);

export { Transaksi as default };
//# sourceMappingURL=Transaksi-664b2265.mjs.map
