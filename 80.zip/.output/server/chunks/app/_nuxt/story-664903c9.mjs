import _sfc_main$2 from './nuxt-icon-4e9d1e9b.mjs';
import { useSSRContext, mergeProps } from 'vue';
import { ssrRenderAttrs, ssrRenderAttr, ssrRenderComponent, ssrRenderStyle } from 'vue/server-renderer';
import { _ as _imports_0$1 } from './slank-d260c789.mjs';
import { _ as _export_sfc } from '../server.mjs';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _sfc_main$1 = {};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex flex-col shadow-32 rounded-lg grow cursor-pointer bg-white dark:bg-darkGrey-100 hover:scale-105" }, _attrs))}><div class="flex flex-col gap-1 items-start pl-[5rem]"><img${ssrRenderAttr("src", _imports_0$1)} alt="User img" class="w-16 2xl:w-[52px] xl:w-11 -ml-[4rem] mt-4"><div class="text-xl font-[&#39;Plus_Jakarta_Sans&#39;] font-bold -mt-14"> UNGU </div></div><div class="ml-[8rem] -mt-3"><svg xmlns="http://www.w3.org/2000/svg" width="21" height="21" viewBox="0 0 21 21" fill="none" class="ml-20 mt-3"><g clip-path="url(#clip0_1720_5506)"><path d="M10.6666 2.16602C6.06659 2.16602 2.33325 5.89935 2.33325 10.4993C2.33325 15.0993 6.06659 18.8327 10.6666 18.8327C15.2666 18.8327 18.9999 15.0993 18.9999 10.4993C18.9999 5.89935 15.2666 2.16602 10.6666 2.16602ZM8.99992 14.666L4.83325 10.4993L6.00825 9.32435L8.99992 12.3077L15.3249 5.98268L16.4999 7.16602L8.99992 14.666Z" fill="url(#paint0_linear_1720_5506)"></path></g><defs><linearGradient id="paint0_linear_1720_5506" x1="2.33325" y1="2.16602" x2="21.021" y2="4.87122" gradientUnits="userSpaceOnUse"><stop stop-color="#FFD849"></stop><stop offset="0.266791" stop-color="#FFC937"></stop><stop offset="0.543874" stop-color="#FFE88C"></stop><stop offset="0.945848" stop-color="#FFD546"></stop></linearGradient><clipPath id="clip0_1720_5506"><rect width="20" height="20" fill="white" transform="translate(0.666626 0.5)"></rect></clipPath></defs></svg></div><div class="font-[&#39;Plus_Jakarta_Sans&#39;] -mt-6 ml-[5rem]"> Verified Owner </div><div class="flex justify-center p-2 mt-2"><img${ssrRenderAttr("src", `/img/sample_${_ctx.story ? "concert" : "makki"}.png`)} alt="Sample Photo" width="700" height="393"></div><div class="flex items-center"><div class="mt-4"><p class="flex items-center ml-4 nuxt-icon nuxt-icon--fill text-white-100"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M12 21.35L10.55 20.03C5.4 15.36 2 12.28 2 8.5C2 5.42 4.42 3 7.5 3C9.24 3 10.91 3.81 12 5.09C13.09 3.81 14.76 3 16.5 3C19.58 3 22 5.42 22 8.5C22 12.28 18.6 15.36 13.45 20.04L12 21.35Z" fill="white"></path></svg>500 </p><p class="flex items-center pl-20 -mt-6 ml-20 nuxt-icon nuxt-icon--fill"><svg xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none"><g clip-path="url(#clip0_1921_6074)"><path d="M12.3334 12.75C13.9634 12.75 15.4034 13.14 16.5734 13.65C17.6534 14.13 18.3334 15.21 18.3334 16.38V18H6.33337V16.39C6.33337 15.21 7.01337 14.13 8.09337 13.66C9.26337 13.14 10.7034 12.75 12.3334 12.75ZM4.33337 13C5.43337 13 6.33337 12.1 6.33337 11C6.33337 9.9 5.43337 9 4.33337 9C3.23337 9 2.33337 9.9 2.33337 11C2.33337 12.1 3.23337 13 4.33337 13ZM5.46337 14.1C5.09337 14.04 4.72337 14 4.33337 14C3.34337 14 2.40337 14.21 1.55337 14.58C0.813374 14.9 0.333374 15.62 0.333374 16.43V18H4.83337V16.39C4.83337 15.56 5.06337 14.78 5.46337 14.1ZM20.3334 13C21.4334 13 22.3334 12.1 22.3334 11C22.3334 9.9 21.4334 9 20.3334 9C19.2334 9 18.3334 9.9 18.3334 11C18.3334 12.1 19.2334 13 20.3334 13ZM24.3334 16.43C24.3334 15.62 23.8534 14.9 23.1134 14.58C22.2634 14.21 21.3234 14 20.3334 14C19.9434 14 19.5734 14.04 19.2034 14.1C19.6034 14.78 19.8334 15.56 19.8334 16.39V18H24.3334V16.43ZM12.3334 6C13.9934 6 15.3334 7.34 15.3334 9C15.3334 10.66 13.9934 12 12.3334 12C10.6734 12 9.33337 10.66 9.33337 9C9.33337 7.34 10.6734 6 12.3334 6Z" fill="white"></path></g><defs><clipPath id="clip0_1921_6074"><rect width="24" height="24" fill="white" transform="translate(0.333374)"></rect></clipPath></defs></svg> 700 </p></div><p class="flex items-center ml-20 mt-4 nuxt-icon nuxt-icon--fill"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><g clip-path="url(#clip0_559_1003)"><path d="M18 16.08C17.24 16.08 16.56 16.38 16.04 16.85L8.91 12.7C8.96 12.47 9 12.24 9 12C9 11.76 8.96 11.53 8.91 11.3L15.96 7.19C16.5 7.69 17.21 8 18 8C19.66 8 21 6.66 21 5C21 3.34 19.66 2 18 2C16.34 2 15 3.34 15 5C15 5.24 15.04 5.47 15.09 5.7L8.04 9.81C7.5 9.31 6.79 9 6 9C4.34 9 3 10.34 3 12C3 13.66 4.34 15 6 15C6.79 15 7.5 14.69 8.04 14.19L15.16 18.35C15.11 18.56 15.08 18.78 15.08 19C15.08 20.61 16.39 21.92 18 21.92C19.61 21.92 20.92 20.61 20.92 19C20.92 17.39 19.61 16.08 18 16.08Z" fill="#222831"></path></g><defs><clipPath id="clip0_559_1003"><rect width="26" height="24" fill="white"></rect></clipPath></defs></svg></p></div><div class="p-4 mt-30" style="${ssrRenderStyle({ "font-family": "'Plus Jakarta Sans'", "font-size": "16px", "font-style": "normal", "font-weight": "400", "line-height": "normal" })}"> Makki Omar Parikesit (lahir 23 Oktober 1971) adalah Bassis dan pendiri Ungu yang didirikan pada tahun 1996. <br><br> Saat sedang mengambil gelar di Indiana University, Amerika Serikat, Makki memperkaya kemampuan bermusiknya dengan bermain bersama sebuah band yang bernama Joint Session, yang selain menjadi band keliling di sekitar Midwest, juga merupakan band pembuka beberapa konser grup musik ternama seperti Toad the Wet Sprocket dan John Mellencamp. <br><br> Kembali ke Jakarta tahun 1996, Makki sempat bergabung dengan Harris Ioni dan beberapa sesi in-promptu sampai akhirnya membentuk UNGU. </div></div>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Card/Story.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender$1]]);
const _imports_0 = "" + __publicAssetsURL("img/story.svg");
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_nuxt_icon = _sfc_main$2;
  const _component_CardStory = __nuxt_component_1;
  _push(`<main${ssrRenderAttrs(mergeProps({ class: "px-60 2xl:px-48 xl:px-40 sm:px-4" }, _attrs))} data-v-a33fee3f><div class="relative header" data-v-a33fee3f><div data-v-a33fee3f><h1 class="font-bold text-primary" data-v-a33fee3f> Cerita Dari Artis Kesayangan </h1><h2 data-v-a33fee3f> Lihat ceritanya sekarang! </h2></div><img${ssrRenderAttr("src", _imports_0)} alt="Story" class="absolute top-0 right-0 bg-img sm:hidden" data-v-a33fee3f></div><section class="mt-32 xl:mt-24 sm:mt-8 flex flex-col gap32" data-v-a33fee3f><label class="flex relative search" data-v-a33fee3f><input type="text" placeholder="Cari cerita yang kamu inginkan" class="rounded-lg w-full shadow-32 py-4 pr-6 xl:py-3 pl-14 xl:pl-10 text-[19px] 2xl:text-base xl:text-sm sm:text-xs leading-tight bg-white dark:bg-darkGrey-100 placeholder:text-inherit-50" data-v-a33fee3f>`);
  _push(ssrRenderComponent(_component_nuxt_icon, {
    name: "search",
    class: "absolute text24 top-1/2 -translate-y-1/2 left-4 xl:left-3"
  }, null, _parent));
  _push(`</label><div data-v-a33fee3f><h3 class="font-bold text24" data-v-a33fee3f>Semua Cerita</h3><p class="mt-2 xl:mt-1 text16" data-v-a33fee3f>Semua cerita ada di sini</p></div><div class="flex gap32" data-v-a33fee3f>`);
  _push(ssrRenderComponent(_component_CardStory, null, null, _parent));
  _push(ssrRenderComponent(_component_CardStory, null, null, _parent));
  _push(ssrRenderComponent(_component_CardStory, null, null, _parent));
  _push(`</div></section></main>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/story.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const story = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender], ["__scopeId", "data-v-a33fee3f"]]);

export { story as default };
//# sourceMappingURL=story-664903c9.mjs.map
