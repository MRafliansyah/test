import { b as buildAssetsURL } from '../../handlers/renderer.mjs';

const _imports_0 = "" + buildAssetsURL("search.f0317912.svg");
const _imports_1 = "" + buildAssetsURL("notifications.830bd8c2.svg");

export { _imports_0 as _, _imports_1 as a };
//# sourceMappingURL=notifications-0c94da73.mjs.map
