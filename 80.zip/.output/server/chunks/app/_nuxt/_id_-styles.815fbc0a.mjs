const Description_vue_vue_type_style_index_0_scoped_ce7e6781_lang = ".active[data-v-ce7e6781]{background-color:#ffd41b;color:#222831}";

const _id_Styles_815fbc0a = [Description_vue_vue_type_style_index_0_scoped_ce7e6781_lang];

export { _id_Styles_815fbc0a as default };
//# sourceMappingURL=_id_-styles.815fbc0a.mjs.map
