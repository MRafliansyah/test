import { d as defineStore } from '../server.mjs';

const state = () => ({
  loginStatus: false
});
const getters = {};
const actions = {
  logout() {
    this.loginStatus = false;
  },
  login() {
    this.loginStatus = true;
  }
};
const useAuthStore = defineStore("auth", {
  state,
  getters,
  actions
});

export { useAuthStore as u };
//# sourceMappingURL=useAuth-653aac8a.mjs.map
