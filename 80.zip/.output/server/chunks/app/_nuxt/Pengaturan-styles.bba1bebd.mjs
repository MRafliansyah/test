const Pengaturan_vue_vue_type_style_index_0_scoped_170dddde_lang = ".header[data-v-170dddde]{font-size:56px;line-height:normal}.bg-img[data-v-170dddde]{width:25vw}.search[data-v-170dddde]{width:30.7vw}@media (max-width:1600px){.header[data-v-170dddde]{font-size:45px}}@media (max-width:1400px){.header[data-v-170dddde]{font-size:40px}}@media (max-width:639px){.header[data-v-170dddde]{font-size:22px}.search[data-v-170dddde]{width:80vw}}main[data-v-170dddde]{background-color:#000;flex:1}";

const PengaturanStyles_bba1bebd = [Pengaturan_vue_vue_type_style_index_0_scoped_170dddde_lang, Pengaturan_vue_vue_type_style_index_0_scoped_170dddde_lang];

export { PengaturanStyles_bba1bebd as default };
//# sourceMappingURL=Pengaturan-styles.bba1bebd.mjs.map
