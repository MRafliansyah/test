const story_vue_vue_type_style_index_0_scoped_a33fee3f_lang = ".header[data-v-a33fee3f]{font-size:56px;line-height:normal}.bg-img[data-v-a33fee3f]{width:25vw}.search[data-v-a33fee3f]{width:30.7vw}@media (max-width:1600px){.header[data-v-a33fee3f]{font-size:45px}}@media (max-width:1400px){.header[data-v-a33fee3f]{font-size:40px}}@media (max-width:639px){.header[data-v-a33fee3f]{font-size:22px}.search[data-v-a33fee3f]{width:80vw}}";

const storyStyles_7908fdb4 = [story_vue_vue_type_style_index_0_scoped_a33fee3f_lang, story_vue_vue_type_style_index_0_scoped_a33fee3f_lang];

export { storyStyles_7908fdb4 as default };
//# sourceMappingURL=story-styles.7908fdb4.mjs.map
