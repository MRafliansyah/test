const Menu_vue_vue_type_style_index_0_scoped_abdc4926_lang = ".spacer[data-v-abdc4926]{border:1px solid rgba(34,40,49,.2)}";

const Login_vue_vue_type_style_index_0_scoped_ed88f856_lang = "input[data-v-ed88f856]{border:1px solid rgba(34,40,49,.2)}.modals-container[data-v-ed88f856]{width:35.2vw}";

const Register_vue_vue_type_style_index_0_scoped_f127e67d_lang = "input[data-v-f127e67d]{border:1px solid rgba(34,40,49,.2)}.modals-container[data-v-f127e67d]{width:35.2vw}";

const Header_vue_vue_type_style_index_0_scoped_58adf75d_lang = ".router-link-active[data-v-58adf75d]{color:inherit}.spacer[data-v-58adf75d]{border-radius:50%;height:8px;width:8px}@media (max-width:1400px){.spacer[data-v-58adf75d]{height:6px;width:6px}}@media (max-width:639px){.spacer[data-v-58adf75d]{height:2px;width:2px}}";

const FilterNav_vue_vue_type_style_index_0_scoped_631a0a90_lang = ".active[data-v-631a0a90]{color:inherit}";

const Footer_vue_vue_type_style_index_0_scoped_66a8c74b_lang = ".column-wrapper[data-v-66a8c74b]{display:flex;flex-direction:column;flex-grow:1;gap:1.5rem}h3[data-v-66a8c74b]{cursor:default;font-weight:700}h3[data-v-66a8c74b],h4[data-v-66a8c74b]{color:#fff}h4[data-v-66a8c74b]{margin-top:72px}p[data-v-66a8c74b]{color:hsla(0,0%,100%,.5)}p[data-v-66a8c74b]:hover{color:#fff;cursor:pointer}@media (max-width:1600px){.column-wrapper[data-v-66a8c74b]{font-size:12px;gap:1rem}h4[data-v-66a8c74b]{font-size:14px;margin-top:51px}}@media (max-width:639px){.column-wrapper[data-v-66a8c74b]{font-size:8px;gap:.7rem}h4[data-v-66a8c74b]{font-size:12px;margin-top:48px}}";

const defaultStyles_255245dd = [Menu_vue_vue_type_style_index_0_scoped_abdc4926_lang, Login_vue_vue_type_style_index_0_scoped_ed88f856_lang, Register_vue_vue_type_style_index_0_scoped_f127e67d_lang, Header_vue_vue_type_style_index_0_scoped_58adf75d_lang, FilterNav_vue_vue_type_style_index_0_scoped_631a0a90_lang, Footer_vue_vue_type_style_index_0_scoped_66a8c74b_lang];

export { defaultStyles_255245dd as default };
//# sourceMappingURL=default-styles.255245dd.mjs.map
