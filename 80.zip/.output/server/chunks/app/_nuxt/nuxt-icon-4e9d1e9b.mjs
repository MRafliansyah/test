import { defineComponent, ref, withAsyncContext, watchEffect, mergeProps, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs } from 'vue/server-renderer';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "nuxt-icon",
  __ssrInlineRender: true,
  props: {
    name: {},
    filled: { type: Boolean, default: false }
  },
  async setup(__props) {
    let __temp, __restore;
    const props = __props;
    const icon = ref("");
    let hasStroke = false;
    async function getIcon() {
      try {
        const iconsImport = /* @__PURE__ */ Object.assign({
          "/assets/icons/bell.svg": () => import('./bell-0d8c261b.mjs').then((m) => m["default"]),
          "/assets/icons/check_circle.svg": () => import('./check_circle-142a5161.mjs').then((m) => m["default"]),
          "/assets/icons/close.svg": () => import('./close-8c22c2bb.mjs').then((m) => m["default"]),
          "/assets/icons/e_wallet.svg": () => import('./e_wallet-ccc0a46f.mjs').then((m) => m["default"]),
          "/assets/icons/email.svg": () => import('./email-c8fee307.mjs').then((m) => m["default"]),
          "/assets/icons/eye.svg": () => import('./eye-44affbf6.mjs').then((m) => m["default"]),
          "/assets/icons/facebook.svg": () => import('./facebook-2ccdd9bc.mjs').then((m) => m["default"]),
          "/assets/icons/favorite.svg": () => import('./favorite-cb5f8bae.mjs').then((m) => m["default"]),
          "/assets/icons/google.svg": () => import('./google-5bc5aca0.mjs').then((m) => m["default"]),
          "/assets/icons/info.svg": () => import('./info-3c79f1bf.mjs').then((m) => m["default"]),
          "/assets/icons/instagram.svg": () => import('./instagram-e7889c62.mjs').then((m) => m["default"]),
          "/assets/icons/lock.svg": () => import('./lock-3ace724f.mjs').then((m) => m["default"]),
          "/assets/icons/logout.svg": () => import('./logout-058dcc96.mjs').then((m) => m["default"]),
          "/assets/icons/moon.svg": () => import('./moon-40a40f31.mjs').then((m) => m["default"]),
          "/assets/icons/people.svg": () => import('./people-60e930e1.mjs').then((m) => m["default"]),
          "/assets/icons/person.svg": () => import('./person-0bd0237c.mjs').then((m) => m["default"]),
          "/assets/icons/search.svg": () => import('./search-d366c138.mjs').then((m) => m["default"]),
          "/assets/icons/share.svg": () => import('./share-c325c37d.mjs').then((m) => m["default"]),
          "/assets/icons/shopping_cart.svg": () => import('./shopping_cart-83f4d607.mjs').then((m) => m["default"]),
          "/assets/icons/sun.svg": () => import('./sun-123ba673.mjs').then((m) => m["default"]),
          "/assets/icons/verified.svg": () => import('./verified-615b0c58.mjs').then((m) => m["default"])
        });
        const rawIcon = await iconsImport[`/assets/icons/${props.name}.svg`]();
        if (rawIcon.includes("stroke")) {
          hasStroke = true;
        }
        icon.value = rawIcon;
      } catch {
        console.error(
          `[nuxt-icons] Icon '${props.name}' doesn't exist in 'assets/icons'`
        );
      }
    }
    [__temp, __restore] = withAsyncContext(() => getIcon()), await __temp, __restore();
    watchEffect(getIcon);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<span${ssrRenderAttrs(mergeProps({
        class: ["nuxt-icon", { "nuxt-icon--fill": !_ctx.filled, "nuxt-icon--stroke": unref(hasStroke) && !_ctx.filled }]
      }, _attrs))}>${unref(icon)}</span>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("node_modules/nuxt-icons/dist/runtime/components/nuxt-icon.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=nuxt-icon-4e9d1e9b.mjs.map
