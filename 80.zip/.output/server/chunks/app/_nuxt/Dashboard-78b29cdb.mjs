import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import { _ as __nuxt_component_0 } from './Sidebar-0c1aabc4.mjs';
import { mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderStyle, ssrRenderAttr } from 'vue/server-renderer';
import { _ as _imports_0, a as _imports_1 } from './notifications-0c94da73.mjs';
import { _ as _export_sfc } from '../server.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _imports_2 = "" + buildAssetsURL("description.12b34ef1.svg");
const _imports_3 = "" + buildAssetsURL("receipt.efbe20ba.svg");
const _imports_4 = "" + buildAssetsURL("check.0f57471f.svg");
const _imports_5 = "" + buildAssetsURL("volunter.2a11694c.svg");
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Sidebar = __nuxt_component_0;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-black min-h-screen top-0 absolute z-50 flex" }, _attrs))} data-v-42b3ea95>`);
  _push(ssrRenderComponent(_component_Sidebar, null, null, _parent));
  _push(`<main class="bg-black flex-1 px-4" style="${ssrRenderStyle({ "background-color": "black !important" })}" data-v-42b3ea95><div class="container mx-auto flex justify-between items-center" data-v-42b3ea95><div data-v-42b3ea95><h2 style="${ssrRenderStyle({ "font-family": "'Plus Jakarta Sans'", "font-weight": "bold", "font-size": "2rem" })}" data-v-42b3ea95>Dashboard</h2><p class="text-inherit-50 -mt-2 xl:mt-1 font-normal font-size: 16px;" data-v-42b3ea95>Tempat dimana anda dapat melihat data secara realtime.</p></div><div class="bg-black relative -mr-[23rem] pl-52 mt-2" style="${ssrRenderStyle({ "display": "flex", "width": "413px", "padding": "16px", "align-items": "center", "gap": "16px" })}" data-v-42b3ea95><input type="text" placeholder="Cari" class="py-2 px-3 pl-12 rounded-lg border border-dark-100 focus:ring focus:ring-dark-100 focus:outline-none" style="${ssrRenderStyle({ "width": "100%", "border-radius": "8px", "border": "1px solid var(--White-20, rgba(255, 255, 255, 0.20))", "background": "var(--Dark-Grey-100, #242424)" })}" data-v-42b3ea95><button class="absolute top-1/2 right-2 transform -translate-y-1/2 mr-[23rem]" data-v-42b3ea95><div style="${ssrRenderStyle({ "float": "left" })}" data-v-42b3ea95><img${ssrRenderAttr("src", _imports_0)} data-v-42b3ea95></div></button></div><div class="bg-black ml-14 mt-2 relative" style="${ssrRenderStyle({ "display": "flex", "padding": "8px", "align-items": "center", "gap": "8px", "border-radius": "8px", "border": "1px solid var(--White-20, rgba(255, 255, 255, 0.20))", "background": "var(--Dark-Grey-100, #242424)" })}" data-v-42b3ea95><button class="relative" data-v-42b3ea95><img${ssrRenderAttr("src", _imports_1)} data-v-42b3ea95><span class="absolute top-0 left-1/2 -translate-x-1/2 h-2 w-2 bg-transparent rounded-full" data-v-42b3ea95></span></button></div></div><div class="bg-black container mx-2" data-v-42b3ea95><div class="grid grid-cols-4 gap-4 mt-6 justify-end" data-v-42b3ea95><div class="bg-red-100 p-4 rounded-lg shadow-md flex flex-col items-start" style="${ssrRenderStyle({ "display": "flex", "padding": "24px", "flex-direction": "column", "align-items": "flex-start", "flex": "1 0 0" })}" data-v-42b3ea95><img${ssrRenderAttr("src", _imports_2)} data-v-42b3ea95></div><div class="bg-green-100 p-4 rounded-lg shadow-md w-300 h-30 flex justify-center items-center" data-v-42b3ea95><div class="ml-auto" data-v-42b3ea95><img${ssrRenderAttr("src", _imports_3)} data-v-42b3ea95></div></div><div class="bg-blue-100 p-4 rounded-lg shadow-md w-300 h-30 flex justify-end items-center" data-v-42b3ea95><div class="ml-auto" data-v-42b3ea95><img${ssrRenderAttr("src", _imports_4)} data-v-42b3ea95></div></div><div class="bg-dark-100 p-4 rounded-lg shadow-md w-300 h-30 flex justify-end" data-v-42b3ea95><img${ssrRenderAttr("src", _imports_5)} data-v-42b3ea95></div><div class="flex" data-v-42b3ea95><div class="w-984 h-496 rounded-lg" style="${ssrRenderStyle({ "display": "flex", "width": "754px", "height": "396px", "padding": "24px", "flex-direction": "column", "align-items": "flex-start", "gap": "24px", "flex-shrink": "0", "background": "var(--Dark-Grey-100, #242424)" })}" data-v-42b3ea95><div style="${ssrRenderStyle({ "color": "white" })}" data-v-42b3ea95>Pesanan Diterima</div></div><div class="w-984 h-496 rounded-lg ml-5 mp-4" style="${ssrRenderStyle({ "display": "flex", "width": "426px", "height": "396px", "padding": "24px", "flex-direction": "column", "align-items": "flex-start", "gap": "24px", "flex-shrink": "0", "background": "var(--Dark-Grey-100, #242424)", "color": "white" })}" data-v-42b3ea95>Kategori</div><div class="w-80 h-64 md:w-100 md:h-32 rounded-lg" style="${ssrRenderStyle({ "background": "var(--Dark-Grey-100, #242424)" })}" data-v-42b3ea95></div><div class="w-80 h-64 md:w-100 md:h-32 rounded-lg ml-60" style="${ssrRenderStyle({ "background": "var(--Dark-Grey-100, #242424)" })}" data-v-42b3ea95></div></div></div></div></main></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/Dashboard.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Dashboard = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender], ["__scopeId", "data-v-42b3ea95"]]);

export { Dashboard as default };
//# sourceMappingURL=Dashboard-78b29cdb.mjs.map
