const Verifikasi_vue_vue_type_style_index_0_scoped_b69f7540_lang = ".container[data-v-b69f7540]{margin:0 auto;max-width:1200px}aside[data-v-b69f7540]{background-color:#333}nav ul[data-v-b69f7540]{list-style:none;padding:0}nav li[data-v-b69f7540]{margin-bottom:10px}nav a[data-v-b69f7540]{color:#fff}main[data-v-b69f7540]{background-color:#000;flex:1}";

const Verifikasi_vue_vue_type_style_index_1_lang = ".bg-transparent:active svg path,.bg-transparent:hover svg path{fill:gold!important}";

const Verifikasi_vue_vue_type_style_index_2_lang = "button:hover{background-color:gold}";

const VerifikasiStyles_4f5c4e8b = [Verifikasi_vue_vue_type_style_index_0_scoped_b69f7540_lang, Verifikasi_vue_vue_type_style_index_1_lang, Verifikasi_vue_vue_type_style_index_2_lang, Verifikasi_vue_vue_type_style_index_0_scoped_b69f7540_lang, Verifikasi_vue_vue_type_style_index_1_lang, Verifikasi_vue_vue_type_style_index_2_lang];

export { VerifikasiStyles_4f5c4e8b as default };
//# sourceMappingURL=Verifikasi-styles.4f5c4e8b.mjs.map
