const PenjualanSaya_vue_vue_type_style_index_0_scoped_6734ec46_lang = ".btn-confirm[data-v-6734ec46]:hover{background-color:var(--Dark-Grey-100,#242424)}";

const PenjualanSaya_vue_vue_type_style_index_0_scoped_05e5e390_lang = "@media (max-width:1600px){.header[data-v-05e5e390]{font-size:45px}}@media (max-width:1400px){.header[data-v-05e5e390]{font-size:40px}}";

const PenjualanSayaStyles_9ac42c2d = [PenjualanSaya_vue_vue_type_style_index_0_scoped_6734ec46_lang, PenjualanSaya_vue_vue_type_style_index_0_scoped_05e5e390_lang, PenjualanSaya_vue_vue_type_style_index_0_scoped_05e5e390_lang];

export { PenjualanSayaStyles_9ac42c2d as default };
//# sourceMappingURL=PenjualanSaya-styles.9ac42c2d.mjs.map
