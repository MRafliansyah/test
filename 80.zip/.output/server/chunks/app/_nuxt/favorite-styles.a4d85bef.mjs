const favorite_vue_vue_type_style_index_0_scoped_682e3b6a_lang = "h1[data-v-682e3b6a]{cursor:default;font-size:56px;line-height:71px}.phone-img[data-v-682e3b6a]{width:34vw}@media (max-width:1600px){h1[data-v-682e3b6a]{font-size:45px;line-height:56px}}@media (max-width:1400px){h1[data-v-682e3b6a]{font-size:40px;line-height:51px}}";

const favoriteStyles_a4d85bef = [favorite_vue_vue_type_style_index_0_scoped_682e3b6a_lang, favorite_vue_vue_type_style_index_0_scoped_682e3b6a_lang];

export { favoriteStyles_a4d85bef as default };
//# sourceMappingURL=favorite-styles.a4d85bef.mjs.map
