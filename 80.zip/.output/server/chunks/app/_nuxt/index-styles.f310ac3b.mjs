const index_vue_vue_type_style_index_0_scoped_062cd4e7_lang = ".header[data-v-062cd4e7]{font-size:56px;line-height:normal}.bg-img[data-v-062cd4e7]{width:36.6vw}.search[data-v-062cd4e7]{width:30.7vw}@media (max-width:1600px){.header[data-v-062cd4e7]{font-size:45px}}@media (max-width:1400px){.header[data-v-062cd4e7]{font-size:40px}}@media (max-width:639px){.header[data-v-062cd4e7]{font-size:22px}.search[data-v-062cd4e7]{width:80vw}}";

const indexStyles_f310ac3b = [index_vue_vue_type_style_index_0_scoped_062cd4e7_lang, index_vue_vue_type_style_index_0_scoped_062cd4e7_lang];

export { indexStyles_f310ac3b as default };
//# sourceMappingURL=index-styles.f310ac3b.mjs.map
