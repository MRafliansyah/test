const info = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">\r\n<g clip-path="url(#clip0_60_1718)">\r\n<path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12C22 6.48 17.52 2 12 2ZM13 17H11V11H13V17ZM13 9H11V7H13V9Z" fill="#222831"/>\r\n</g>\r\n<defs>\r\n<clipPath id="clip0_60_1718">\r\n<rect width="24" height="24" fill="white"/>\r\n</clipPath>\r\n</defs>\r\n</svg>\r\n';

export { info as default };
//# sourceMappingURL=info-3c79f1bf.mjs.map
