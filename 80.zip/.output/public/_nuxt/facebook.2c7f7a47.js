const A=`<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\r
<rect width="24" height="24" fill="url(#pattern0)" fill-opacity="0.5"/>\r
<defs>\r
<pattern id="pattern0" patternContentUnits="objectBoundingBox" width="1" height="1">\r
<use xlink:href="#image0_241_5421" transform="scale(0.0416667)"/>\r
</pattern>\r
<image id="image0_241_5421" width="24" height="24" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAABlUlEQVR4nN1VzU4CMRAuosa3gM4Gposx23FNTPSwd02MwawSX8D4AOrVeDFGfAIP/iEvwM2zRx8AFUl8BIUzmAICsXULy0kn6aX5+n0z801bxv515HK5WcelHY5UBkFVQGp2lqCq2ktnF7cVJhY5R9riQr6BoHbU4kLWQFB+DOowCYKKNmLQ1zljbMpKH5O83akG5Zm1LZZ2fAB6Bw7KlUxmCQD9BUBZGcY4rrdpJFdmWXregqy3qiUl6OpHFa9G49W0RGdPj8PJANIeCDriQj4ZWhWa2lOO7DHSZd8nlw4tfpR0c5Geow2kkwFW3loEqqYKGhaB476AoHsLtmGqoGkCp1LBnHEqBuceDNP2qVfQvZExBOS7oYIXHfhb2Sh31VQ4rjf/jU27/rLaA0GFzvhq5+SdSaAwhgelKKx6BDUB3/dnQFB9UgEuZC0IgmljP9U1n1CglUbaYBbTLiYQKLIRImF6UblFoPeSJkYR6JF468OeRAjUwZVrLF6E6vPJc6RryMr9vgDSKUe66f5kYTIm+R+JL9bzhodynQ5fAAAAAElFTkSuQmCC"/>\r
</defs>\r
</svg>\r
`;export{A as default};
