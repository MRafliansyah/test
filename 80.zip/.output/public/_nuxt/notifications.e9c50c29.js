import"./entry.bf5c5252.js";const r=""+new URL("search.f0317912.svg",import.meta.url).href,o=""+new URL("notifications.830bd8c2.svg",import.meta.url).href;export{r as _,o as a};
