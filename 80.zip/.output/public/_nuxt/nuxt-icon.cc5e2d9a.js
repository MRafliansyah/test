import{_ as m}from"./nuxt-icon.vue.bd722602.js";import"./entry.bf5c5252.js";export{m as default};
