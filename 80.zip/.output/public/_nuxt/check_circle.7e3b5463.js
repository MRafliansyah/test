const i=`<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">\r
<g clip-path="url(#clip0_59_1666)">\r
<path d="M10.0003 1.66667C5.40033 1.66667 1.66699 5.4 1.66699 10C1.66699 14.6 5.40033 18.3333 10.0003 18.3333C14.6003 18.3333 18.3337 14.6 18.3337 10C18.3337 5.4 14.6003 1.66667 10.0003 1.66667ZM8.33366 14.1667L4.16699 10L5.34199 8.825L8.33366 11.8083L14.6587 5.48333L15.8337 6.66667L8.33366 14.1667Z" fill="#FFD41B"/>\r
</g>\r
<defs>\r
<clipPath id="clip0_59_1666">\r
<rect width="20" height="20" fill="white"/>\r
</clipPath>\r
</defs>\r
</svg>\r
`;export{i as default};
