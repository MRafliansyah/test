const A=`<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\r
<rect width="24" height="24" fill="url(#pattern0)" fill-opacity="0.5"/>\r
<defs>\r
<pattern id="pattern0" patternContentUnits="objectBoundingBox" width="1" height="1">\r
<use xlink:href="#image0_241_160" transform="scale(0.0416667)"/>\r
</pattern>\r
<image id="image0_241_160" width="24" height="24" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAABvUlEQVR4nN1VTStEYRS+kw0boSgM13vm3jlnrsacY5AdZSellMLagr2NbK3JguQPyD/wsZF8JCk2ii3KRsoOzYzuYDL33pl752PDqbN73+d53ud8vJr27yNiiaFQlhTJMRA/KuR3QHkCknMgXjYstsoCDltWkyLeVMgfQJIpkimFvA3Q0xIYXI8mSaHc+QDnpSJ5sEX5gndSslWR3JcCDiRpiPJ8EPEhhXzqUod8CSRThsHNWRHxeCOQTHzVRVKKeDaQNUA87VKHvKJpkzUFBUW5XwsaivjCoXxbq1ZEuvs6sl7mwOWtA6WtegRRHs+3h3e9zinkSUA58Ml9l62AMuewZ9WLoAt5IUhnuV5fbYJOSrYWtwhlrwKCdDg8WJd30TDiYWeRTTPR7iTQ9aFaew5+J8R41FG/m0BtCsQ7dq9rxSNkN4TjBRueJ+1p9dgxa0UHjWTNeSdCyd6CahTJiYenV4A887MxDWOgXlHvGKAcuiffu3aVLrvMN/hzV0z0QOsaUG5LW9f8GsHEsC94jiSRaACU9ewP5qucz3RTYlo5YZp9oIgXAfnI/lSyPxzKCxBfA8oWxGSkLOA/E592nUFtL2UNrgAAAABJRU5ErkJggg=="/>\r
</defs>\r
</svg>\r
`;export{A as default};
