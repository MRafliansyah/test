import{D as t}from"./entry.bf5c5252.js";const s=()=>({loginStatus:!1}),o={},e={logout(){this.loginStatus=!1},login(){this.loginStatus=!0}},n=t("auth",{state:s,getters:o,actions:e});export{n as u};
