import"./entry.bf5c5252.js";const i=""+globalThis.__publicAssetsURL("img/slank.png");export{i as _};
