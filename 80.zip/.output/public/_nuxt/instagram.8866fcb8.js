const A=`<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\r
<rect width="24" height="24" fill="url(#pattern0)" fill-opacity="0.5"/>\r
<defs>\r
<pattern id="pattern0" patternContentUnits="objectBoundingBox" width="1" height="1">\r
<use xlink:href="#image0_241_96" transform="scale(0.0416667)"/>\r
</pattern>\r
<image id="image0_241_96" width="24" height="24" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAABSklEQVR4nO1UuU4DMRDdioajpcWz0c7gIjuzkShQEEebRHwOUkSHIsLfIELL8TEk9CQ9aHYjQcD2Bm+bkUayfMx7fvPsJNlETKQZXwLKK6AsgOQzmCgLQ/JiUAZrFTfI49qi5M1RPfOIwinyMWSdro4NFX0vQClLDPOs0zWHxUkFIM8BeWTuKmBI7g+IT/fb7W3NFPMzIH5w7+UP/w3cDK8C/Rq6zqwNoMx13lq7ZZDvAHkGxFM1gs5VsvIkGkBl8TlL53Qtxfw8GsBau7NkOfvrf37XNUTcbQ5APHXI96ZrrdbRXjSAusUnEaDclmey4iIaQK34o8nj6ia/myyPDQBEmzn07ke5/pdNfQ8NkCfqFu2JZimLg3ntQ9NfMeqroBWAp9ANBk0BgPKeF2DZh1ED9jfB4t9SFX39Fb09WTGBzFWWWuabSDzxBV/EgZF+i3F5AAAAAElFTkSuQmCC"/>\r
</defs>\r
</svg>\r
`;export{A as default};
