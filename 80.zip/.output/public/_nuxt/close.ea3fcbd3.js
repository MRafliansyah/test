const i=`<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">\r
<g clip-path="url(#clip0_110_2739)">\r
<path d="M19 6.41L17.59 5L12 10.59L6.41 5L5 6.41L10.59 12L5 17.59L6.41 19L12 13.41L17.59 19L19 17.59L13.41 12L19 6.41Z" fill="#222831"/>\r
</g>\r
<defs>\r
<clipPath id="clip0_110_2739">\r
<rect width="24" height="24" fill="white"/>\r
</clipPath>\r
</defs>\r
</svg>\r
`;export{i as default};
