<!-- <template>
    <div>
        <Sidebar/>
        <nuxt/>
    </div>
</template>

<script>
</script> -->