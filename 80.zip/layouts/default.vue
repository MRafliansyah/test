<script setup>
const showFilterList = ['index', 'story']
const darkMode = useState("darkMode", () => undefined)

const route = useRoute();
const showFilter = computed(() => showFilterList.includes(route.name));

const changeTheme = (dark) => {
  if (dark) {
    document.documentElement.classList.add('dark')
  } else {
    document.documentElement.classList.remove('dark')
  }
  localStorage.setItem("darkMode", dark ? "true" : "false")
}

onMounted(() => {
  console.log()
  darkMode.value = localStorage.getItem("darkMode") === "true"
})

watch(darkMode, dark => {
  changeTheme(dark)
})

useHead({
  script: [{
    children: `if (localStorage.darkMode === "true") {
      document.documentElement.classList.add('dark')
    }`}]
})
</script>

<template>
  <div v-if="!['dashboard', 'mitra', 'verifikasi', 'pengaturan'].includes(route.fullPath.replace('/', ''))">

    <Head>
      <Title>History Outlet</Title>
      <Link rel="preconnect" href="https://fonts.googleapis.com" />
      <Link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="" />
      <Link
        href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:ital,wght@0,400;0,500;0,600;0,700;1,400&display=swap"
        rel="stylesheet" />
    </Head>
    <div class="mb-16 2xl:mb-12 xl:mb-11">
      <Header />
      <FilterNav v-if="showFilter" />
    </div>

    <slot />

    <Footer />
    <div @click="darkMode = !darkMode" class="cursor-pointer">
      <nuxt-icon :name="darkMode ? 'moon' : 'sun'"
        class="text32 text-yellow-100 dark:text-white fixed bottom-[3%] right-[3%]" />
    </div>
  </div>
  <div v-else> 
    <Head>
      <Title>History Outlet</Title>
      <Link rel="preconnect" href="https://fonts.googleapis.com" />
      <Link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="" />
      <Link
        href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:ital,wght@0,400;0,500;0,600;0,700;1,400&display=swap"
        rel="stylesheet" />
    </Head>

    <slot />
    <div @click="darkMode = !darkMode" class="cursor-pointer">
      <nuxt-icon :name="darkMode ? 'moon' : 'sun'"
        class="text32 text-yellow-100 dark:text-white fixed bottom-[3%] right-[3%]" />
    </div>
  </div>
</template>

<style scoped></style>
