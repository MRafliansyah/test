export const state = () => ({
  users: null
});

export const mutations = {
  addUser(state, newUser) {
    state.users=newUser;
  }
};

export const actions = {
  addUser({ commit }, newUser) {
    commit('addUser', newUser);
  }
};

