const state = () => ({
  loginStatus: false,
});

const getters = {};

const actions = {
  logout() {
    this.loginStatus = false;
  },
  login() {
    this.loginStatus = true;
  }
};

export const useAuthStore = defineStore("auth", {
  state,
  getters,
  actions,
});
