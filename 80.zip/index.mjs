// Import modul yang dibutuhkan di sini
import http from 'http';

// Fungsi untuk menangani permintaan HTTP
const handleRequest = (request, response) => {
  response.writeHead(200, { 'Content-Type': 'text/plain' });
  response.end('Hello, World!\n');
};

// Buat server HTTP
const server = http.createServer(handleRequest);

// Port yang akan digunakan oleh server
const port = 3000;

// Dengarkan pada port tertentu
server.listen(port, () => {
  console.log(`Server berjalan di http://localhost:${port}/`);
});
