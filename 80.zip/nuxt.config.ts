// https://nuxt.com/docs/api/configuration/nuxt-config
export default defineNuxtConfig({  
  modules: ["nuxt-icons", "@pinia/nuxt",],
  css: ["~/assets/css/tailwind.css"],
  imports: {
    dirs: ["stores"],
  },
  postcss: {
    plugins: {
      "tailwindcss/nesting": {},
      tailwindcss: {},
      autoprefixer: {},      
    },
  },
  pinia: {
    autoImports: [
      // automatically imports `defineStore`
      "defineStore", // import { defineStore } from 'pinia' // import { defineStore as definePiniaStore } from 'pinia'
    ],
  },
});
