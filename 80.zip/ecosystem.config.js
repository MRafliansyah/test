module.exports = {
    apps: [
      {
        name: 'HistoryOutlet',
        port: '3000',
        exec_mode: 'cluster',
        instances: 'max',
        script: './index.mjs'
      }
    ]
  }
  