<script setup>
import { ref, onMounted, watch } from 'vue';
import axios from 'axios';

const tickets = ref([]);
const lelang = ref([]);
const unfilteredLelang = ref([])
const isShowAll = ref(false)
watch(isShowAll, (newX) => {
  console.log(newX)
  if (newX == false) {
    lelang.value = unfilteredLelang.value.slice(0, 4)
  } else {
    lelang.value = unfilteredLelang.value
  }
})
// const fetchTickets = async () => {
//   try {
//     let config = {
//       method: 'get',
//       maxBodyLength: Infinity,
//       url: 'http://hobackend.pixelpi.id/api/v1/tikets/',
//       headers: { 
//       }
//     };
//     const response = await axios.request(config)
//     .then((response) => {    
//       tickets.value = response.data; // Assuming the fetched data is an array of tickets
//     })
//     .catch((error) => {
//       console.log(error);
//     });

//   } catch (error) {
//     console.error('Error fetching tickets:', error);
//   }
// };

const fetchTickets = async () => {
  try {
    let config = {
      method: 'get',
      maxBodyLength: Infinity,
      url: 'https://65558d7284b36e3a431de9a5.mockapi.io/tiket',
      headers: { 
      }
    };
    const response = await axios.request(config)
    .then((response) => {
      tickets.value = response.data.filter(e => {return e.verifikasi}) // Assuming the fetched data is an array of tickets
      fetchProduct()
    })
    .catch((error) => {
      console.log(error);
    });

  } catch (error) {
    console.error('Error fetching tickets:', error);
  }
};
onMounted(fetchTickets);

async function fetchProduct () {
  try {
    let config = {
      method: 'get',
      maxBodyLength: Infinity,
      url: 'https://6550a40f7d203ab6626e02b9.mockapi.io/lelang',
      headers: { 
      }
    };
    await axios.request(config).then((res) => {
      unfilteredLelang.value = res.data.filter(e => {return e.verifikasi}).sort((a, b) => {
        const dateA = new Date(a.tanggal);
        const dateB = new Date(b.tanggal);
        if (a.recommend !== b.recommend){
          return b.recommend-a.recommend
        }
        return dateA - dateB;
      });
      lelang.value = unfilteredLelang.value.slice(0, 4)
    })
    .catch((error) => {
      console.log(error);
    });

  } catch (error) {
    console.error('Error fetching product:', error);
  }
};

</script>


<template>
    <main class="px-60 2xl:px-48 xl:px-40 sm:px-4">
      <!-- Header and Picture -->
      <div class="relative header">
        <div>
          <h1 class="font-bold text-primary">
            Cari Barang Artis Kesayanganmu
          </h1>
          <h2>
            Menang langsung bawa pulang!
          </h2>
        </div>
        <img data-v-02281a80="" src="/img/logistic.svg" alt="Logistic" class="absolute top-0 right-0 bg-img sm:hidden" style="z-index: -1;">
      </div>

      <!-- Content -->
      <section class="mt-32 xl:mt-24 sm:mt-8 flex flex-col gap32">
        <!-- Search -->
        <label class="flex relative search">
          <input type="text" placeholder="Cari tiket atau lelang yang kamu pengen!"
            class="rounded-lg w-[500px] shadow-32 py-4 pr-6 xl:py-3 pl-14 xl:pl-10 text-[19px] 2xl:text-base xl:text-sm sm:text-xs leading-tight bg-white dark:bg-darkGrey-100 placeholder:text-inherit-50">
          <nuxt-icon name="search" class="absolute text24 top-1/2 -translate-y-1/2 left-4 xl:left-3" />
        </label>

        <!-- Newest Bid Item -->
        <div>
          <h3 class="font-bold text24">Lelang Paling Baru</h3>
          <p class="mt-2 xl:mt-1 text16">Lelang yang sedang terjadi baru-baru ini, cepetan bid secepat mungkin!!!</p>
        </div>
        <div class="grid grid-cols-5 ">
          <div class="col-span-4 grid grid-cols-4 lg:grid-cols-2 gap32">
            <div v-for="lelangs, index in lelang">
              <div>
                <CardProduct :product="lelangs" />
              </div>
              <!-- <div v-else-if="index < 4">
                <CardProduct :product="lelangs" />
              </div> -->
            </div>
          </div>
          
          <div v-if="!isShowAll">
            <button @click="isShowAll = true" class="font-bold text-inherit-50 hover:text-inherit text16 p12-16 min-w-fit">
              Lihat Semua
            </button>
          </div>
          <div v-else>
            <button @click="isShowAll = false" class="font-bold text-inherit-50 hover:text-inherit text16 p12-16 min-w-fit">
              Sembunyikan
            </button>
          </div>
        </div>

        <!-- Bid Item with Bin -->
        <div class="mt-8 xl:mt-6">
          <h3 class="font-bold text24">Buy It Now!</h3>
          <p class="mt-2 xl:mt-1 text16">Kamu bisa beli barang ini langsung tanpa harus bid.</p>
        </div>

        <!-- <div class="grid grid-cols-5 gap32">
          <CardProduct />
          <CardProduct />
          <CardProduct />
          <CardProduct />
          <CardProduct />
          <CardProduct />
          <CardProduct />
          <CardProduct />
          <CardProduct />
          <CardProduct />
        </div> -->
  <!-- <CardProduct :product="lelangs" /> -->

        <!-- <div  class="grid grid-cols-5 gap32">
          <div v-for="lelangs in lelang">
            <CardProduct :lelang="lelangs" />
          
          </div>
        </div> -->

        <div class="grid grid-cols- ">
          <div class="col-span-4 grid grid-cols-5 lg:grid-cols-2 gap32">
            <div v-for="lelangs in lelang">
              <div>
                <CardProduct :lelang="lelangs" />
              </div>
            </div>
          </div>
        </div>

        <!-- Concert Ticket -->
        <div class="mt-8 xl:mt-6">
          <h3 class="font-bold text24">Tiket Konser</h3>
          <p class="mt-2 xl:mt-1 text16">Kamu juga bisa beli tiket konser band lokal kesayanganmu lho.</p>
        </div>
        <!-- <div  class="grid grid-cols-5 gap32">
          <div v-for="tiket in tickets">
            <CardProduct :tiket="tiket" />
          </div>
        </div> -->

        <div class="grid grid-cols- ">
          <div class="col-span-4 grid grid-cols-5 lg:grid-cols-2 gap32">
            <div v-for="tiket in tickets">
              <div>
                <CardProduct :tiket="tiket" />
              </div>
            </div>
          </div>
        </div>

      </section>

    </main>
</template>

<style scoped>
.header {
  font-size: 56px;
  line-height: normal;
}

.bg-img {
  width: 36.6vw;
}
.search {
  width: 30.7vw;
}

@media (max-width: 1600px) {
  .header {
    font-size: 45px;
  }
}

@media (max-width: 1400px) {
  .header {
    font-size: 40px;
  }
}

@media (max-width: 639px) {
  .header {
    font-size: 22px;
  }

  .search {
    width: 80vw;
  }
}

</style>
