<script setup>
import { ref, onMounted } from 'vue';
import axios from 'axios';

let isOpen = ref(false);

const openMenu = () => {
  isOpen.value = !isOpen.value;
  console.log(isOpen.value);
};

const transaksi = ref({});
const bidding = ref({});

const route = useRoute();
const product = ref({});
const Bin1= ref(false);
const Bin2= ref(false);
const Bin3= ref(false);
const Bin4= ref(false);
const Bin5= ref(false);
const Bin6= ref(false);

const Bid1= ref(false);
const Bid2= ref(false);
const Bid3= ref(false);

// Bin
  const showBin1 = () => {
    Bin1.value = true; 
  }; 
  const showBin2 = () => {
    Bin1.value = false;
    Bin2.value = true;
  };
  const showBin3 = () => {
    Bin2.value = false;
    Bin3.value = true;
  };
  const showBin4 = () => {
    Bin3.value = false;
    Bin4.value = true;
  };
  const showBin5 = () => {
    Bin4.value = false;
    Bin5.value = true;
  };
  const showBin6 = () => {
    Bin5.value = false;
    Bin6.value = true;
  };

  const hideBin1 = () => {
    Bin1.value = false;
  };
  const hideBin2 = () => {
    Bin2.value = false;
    Bin1.value = true;
  };
  const hideBin3 = () => {
    Bin3.value = false;
    Bin2.value = true;
  };
  const hideBin4 = () => {
    Bin4.value = false;
    Bin3.value = true;
  };
  const hideBin5 = () => {
    Bin5.value = false;
    Bin4.value = true;
  };
  const hideBin6 = () => {
    Bin6.value = false;
  };
  const myObject = {
  berhasil() {
    this.$router.push('/');
  }
  };

// Bid
  const showBid1 = () => {
    Bid1.value = true; 
  };
  const showBid2 = () => {
    Bid1.value = false;
    Bid2.value = true;
  };
  const showBid3 = () => {
    Bid2.value = false;
    Bid3.value = true;
  };
  const hideBid1 = () => {
    Bid1.value = false;
  };
  const hideBid2 = () => {
    Bid2.value = false;
    Bid1.value = true;
  };
  const hideBid3 = () => {
    Bid3.value = false;
    Bid2.value = true;
  };
 
const fetchProducts = async () => {
  try {
    let config = {
      method: 'get',
      maxBodyLength: Infinity,
      url: 'https://6550a40f7d203ab6626e02b9.mockapi.io/lelang/'+route.params.id,
      headers: { 
      }
    };
    const response = await axios.request(config)
    .then((response) => {
      // console.log(response.data)   
      product.value = response.data
    })
    .catch((error) => {
      console.log(error);
    });

  } catch (error) {
    console.error('Error fetching products:', error);
  }
};

const fetchTransaksi = async () => {
  try {
    let config = {
      method: 'get',
      maxBodyLength: Infinity,
      url: 'https://6550a40f7d203ab6626e02b9.mockapi.io/lelangTransaksi/'+route.params.id,
      headers: {} // Anda bisa menambahkan headers jika diperlukan
    };
    const response = await axios.request(config);
    transaksi.value = response.data;
  } catch (error) {
    console.error('Error fetching transaksi:', error);
  }
};

const fetchBidding = async () => {
  try {
    let config = {
      method: 'get',
      maxBodyLength: Infinity,
      url: 'https://65581aa99c0b643cb2d6d96c.mockapi.io/bidding/'+route.params.id,
      headers: {} // Anda bisa menambahkan headers jika diperlukan
    };
    const response = await axios.request(config);
    bidding.value = response.data;
  } catch (error) {
    console.error('Error fetching bidding:', error);
  }
};
onMounted(fetchProducts);
onMounted(fetchTransaksi);
onMounted(fetchBidding);
</script>

<script>
export default {
  data() {
    return {
      isBidSuccessful: false,
      timeRemaining: null,
      countdownUnits: [],
    };
  },
  async mounted() {
    
    const route = useRoute();
    let config = {
      method: 'get',
      maxBodyLength: Infinity,
      url: 'https://6550a40f7d203ab6626e02b9.mockapi.io/lelang/'+route.params.id,
      headers: { 
      }
    };
    const response = await axios.request(config)
    .then((response) => {
      if(response.data.statusLelang !== "-"){
        this.isBidSuccessful = true
      }

      const formattedDate = this.createDateFromIndonesianDate(response.data.tanggal);
      const timeFromDatabase = response.data.jam
      const endTime = new Date(formattedDate).getTime();
      var calDateTime = `${formattedDate}T${timeFromDatabase.slice(0, 2)}:${timeFromDatabase.slice(2)}`;
      console.log(calDateTime)
      const dateObject = new Date(calDateTime).getTime();
      const now = new Date().getTime();
      const secondsDifference = Math.floor((dateObject - now) / 1000);
      if (secondsDifference <= 0) {
        this.timeRemaining = null; // Lelang telah ditutup
      } else {
        this.timeRemaining = this.convertSecondsToTime(secondsDifference);

        setInterval(() => {
          this.updateCountdown();
        }, 1000);
      }

    })
    .catch((error) => {
      console.log(error);
    });
  },
  methods: {
      createDateFromIndonesianDate(indonesianDateString) {
        const indonesianMonths = [
            'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
            'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
        ];
        
        const monthNumber = [1,2,3,4,5,6,7,8,9,10,11,12];

        const [day, month, year] = indonesianDateString.split(' ');
        var indexDate = indonesianMonths.indexOf(month)+1
        if (indexDate < 10){
          indexDate = "0"+indexDate.toString()
        } else {indexDate = indexDate.toString()}
        const date = year+"-"+indexDate+"-"+day
        return date
    },

    convertSecondsToTime(seconds) {
      // console.log(seconds)
      const days = Math.floor(seconds / (3600 * 24));
      const hours = Math.floor((seconds % (3600 * 24)) / 3600);
      const minutes = Math.floor((seconds % 3600) / 60);
      const remainingSeconds = seconds % 60;

      return {
        days,
        hours,
        minutes,
        seconds: remainingSeconds,
      };
    },
    updateCountdown() {
      if (this.timeRemaining) {
        if (this.timeRemaining.days > 0 || this.timeRemaining.hours > 0 || this.timeRemaining.minutes > 0 || this.timeRemaining.seconds > 0) {
          if (this.timeRemaining.seconds > 0) {
            this.timeRemaining.seconds--;
          } else {
            if (this.timeRemaining.minutes > 0) {
              this.timeRemaining.minutes--;
              this.timeRemaining.seconds = 59;
            } else {
              if (this.timeRemaining.hours > 0) {
                this.timeRemaining.hours--;
                this.timeRemaining.minutes = 59;
                this.timeRemaining.seconds = 59;
              } else {
                if (this.timeRemaining.days > 0) {
                  this.timeRemaining.days--;
                  this.timeRemaining.hours = 23;
                  this.timeRemaining.minutes = 59;
                  this.timeRemaining.seconds = 59;
                } else {
                  // Lelang telah ditutup
                  this.timeRemaining = null;
                  // Menandakan bahwa lelang berhasil
                  this.isBidSuccessful = true; 
                }
              }
            }
          }
          this.countdownUnits = [
            { label: 'Hari', value: this.padNumber(this.timeRemaining.days) },
            { label: 'Jam', value: this.padNumber(this.timeRemaining.hours) },
            { label: 'Menit', value: this.padNumber(this.timeRemaining.minutes) },
            { label: 'Detik', value: this.padNumber(this.timeRemaining.seconds) },
          ];
        }
      }
    },
    padNumber(num) {
      return num.toString().padStart(2, '0');
    },
  },
};
</script>

<template>
  <div class="px-60 2xl:px-48 xl:px-40 mt-44 2xl:mt-[140px] xl:mt-28">
    <!-- Breadcrumbs -->
    <!-- {{ bidding }} -->
    <!-- {{ product }} -->

    <div class="flex gap-4 font-medium text16">
      <NuxtLink to="/" class="text-dark-50 cursor-pointer">Beranda</NuxtLink>
      <p class="text-dark-100 cursor-default">/</p>
      <p class="text-yellow-100 cursor-pointer">Detail Lelang</p>
    </div>

    <!-- Main content -->
    <div class="mt-8 2xl:mt-6 flex gap-16 2xl:gap-[52px] xl:gap-11">
      <!-- Image section -->
      <section class="flex flex-col gap32 w-[30.2vw] shrink-0">
        <div class="">
          <img src="/img/sample_jacket.png" alt="Main image" class="p-4 border border-dark-20 border-solid rounded-lg w-full">
        </div>
        
        <!-- Mini image -->
        <div class="flex gap32 justify-between">
          <div class="p-2 bg-yellow-100 border border-solid border-dark-20 rounded-lg cursor-pointer">
            <img src="/img/sample_jacket_mini.png" alt="Mini image">
          </div>
          <div class="p-2 border border-solid border-dark-20 rounded-lg cursor-pointer">
            <img src="/img/sample_jacket_mini.png" alt="Mini image">
          </div>
          <div class="p-2 border border-solid border-dark-20 rounded-lg cursor-pointer">
            <img src="/img/sample_jacket_mini.png" alt="Mini image">
          </div>
          <div class="p-2 border border-solid border-dark-20 rounded-lg cursor-pointer">
            <img src="/img/sample_jacket_mini.png" alt="Mini image">
          </div>
        </div>
      </section>

      <!-- Detail Section -->
      <section class="flex flex-col gap32">

        <!-- Header -->
        <div class="flex gap32">
          <div class="flex flex-col gap16">
            <p class="font-medium text32">{{ product.kategori?product.kategori:"-" }}</p>
            <p class="font-semibold text-[64px] 2xl:text-[52px] xl:text[45px] leading-none">{{ product.name?product.name:"-" }}</p>
          </div>

          <!-- Side button -->
          <div class="flex flex-col py-6 px-4 gap-6 border border-solid border-dark-20 rounded-full self-start">
            <!-- Like -->
            <div class="flex flex-col gap-1 items-center cursor-pointer">
              <nuxt-icon name="favorite" class="text24 text-dark-100" />
              <p class="text-dark-50 text-[13px] 2xl:text-[10px] leading-none">Like</p>
            </div>
            <!-- Share -->
            <div class="flex flex-col gap-1 items-center cursor-pointer">
              <nuxt-icon name="share" class="text24 text-dark-100" />
              <p class="text-dark-50 text-[13px] 2xl:text-[10px] leading-none">Share</p>
            </div>
          </div>
        </div>

        <!-- Name, price and time -->
        <div class="flex">
          <!-- Left (Name and time) -->
          <div class="flex flex-col gap32">
            <!-- Name -->
            <div class="flex items-center gap16">
              <img src="/img/slank.png" alt="User img" class="w-16 2xl:w-[52px] xl:w-11">
              <div class="flex flex-col">
                <p class="font-bold text24">Slank</p>
                <div class="flex items-center">
                  <p class="mr-3 text16">Verified Owner</p>
                  <nuxt-icon name="check_circle" class="text20 text-yellow-100" />
                </div>
              </div>
            </div>

            <!-- Highest bid -->
            <div class="flex gap16 items-center">
              <img src="/img/user2.png" alt="Highest bid user" class="w-16 2xl:w-[52px] xl:w-11">
              <div class="flex flex-col gap-1 2xl:gap-[3px]">
                <p class="text-dark-50 text16">Bid tertinggi sementara:</p>
                <p class="font-bold text24">Agus Subagja</p>
                <p class="font-bold text24 text-green-100">Rp. 3.900.000</p>
              </div>
            </div>

            <!-- Time -->
            <div class="flex flex-col gap16">
              <div class="flex flex-col">
                <p class="font-bold text24">Waktu Lelang Tersisa</p>
                <p class="text16">{{ product.tanggal?product.tanggal:"-" }}</p>
              </div>
              <div v-if="isBidSuccessful">
                <!-- Tampilan jika lelang sudah berhasil BIN -->
                <div class="flex p12-16 w-[390px] rounded-lg border border-solid border-inherit-20">
                <p class="font-bold text24">Telah Ada Yang Buy It Now Lelang Ini</p>
              </div>
            </div>

              <div v-else-if="timeRemaining === null">
                <!-- Tampilan jika lelang telah ditutup -->
                <div class="flex p12-16 w-[390px] rounded-lg border border-solid border-inherit-20">
                <p class="font-bold text-red-100">LELANG TELAH DI TUTUP</p>
              </div>
              </div>

              <div v-else>
              <div class="flex gap16">
                <!-- Day -->
                <div v-if="countdownUnits && countdownUnits.length > 3" class="flex flex-col gap-2">
                  <div class="flex gap-2" v-if="countdownUnits[0].value >= 100">
                    <ProductTime>{{ Math.floor(countdownUnits[0].value / 100) }}</ProductTime>
                    <ProductTime>{{ Math.floor((countdownUnits[0].value % 100) / 10) }}</ProductTime>
                    <ProductTime>{{ countdownUnits[0].value % 10 }}</ProductTime>
                  </div>
                  <div class="flex gap-2" v-else>
                    <ProductTime>{{ countdownUnits[0].value.toString().padStart(2, '0')[0] }}</ProductTime>
                    <ProductTime>{{ countdownUnits[0].value.toString().padStart(2, '0')[1] }}</ProductTime>
                  </div>
                  <p class="text-center text16">{{ countdownUnits[0].label }}</p>
                </div>
                
            
                <!-- Hour -->
                <div v-if="countdownUnits && countdownUnits.length > 2" class="flex flex-col gap-2">
                  <div class="flex gap-2">
                    <ProductTime>{{ countdownUnits[1].value.toString().padStart(2, '0')[0] }}</ProductTime>
                    <ProductTime>{{ countdownUnits[1].value.toString().padStart(2, '0')[1] }}</ProductTime>
                  </div>
                  <p class="text-center text16">{{ countdownUnits[1].label }}</p>
                </div>
            
                <!-- Minute -->
                <div v-if="countdownUnits && countdownUnits.length > 1" class="flex flex-col gap-2">
                  <div class="flex gap-2">
                    <ProductTime>{{ countdownUnits[2].value.toString().padStart(2, '0')[0] }}</ProductTime>
                    <ProductTime>{{ countdownUnits[2].value.toString().padStart(2, '0')[1] }}</ProductTime>
                  </div>
                  <p class="text-center text16">{{ countdownUnits[2].label }}</p>
                </div>
            
                <!-- Second -->
                <div v-if="countdownUnits && countdownUnits.length > 0" class="flex flex-col gap-2">
                  <div class="flex gap-2">
                    <ProductTime>{{ countdownUnits[3].value.toString().padStart(2, '0')[0] }}</ProductTime>
                    <ProductTime>{{ countdownUnits[3].value.toString().padStart(2, '0')[1] }}</ProductTime>
                  </div>
                  <p class="text-center text16">{{ countdownUnits[3].label }}</p>
                </div>
              </div>
            </div>
          </div>
        </div>


          <!-- Right (price) -->
          <div class="flex flex-col gap16 w-full items-center">
            <!-- Buy it now -->
            <div class="flex flex-col gap8 w-full items-center">
              <p class="font-bold text24 text-red-100">Rp. {{ product.bin?product.bin.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.'):"-" }}</p>
              <BigButton class="bg-yellow-100 font-bold text24 w-full" @click="showBin1">
                Buy It Now!
              </BigButton >
            </div>

            <!-- Bid @click="showBid1 = true"-->
            <div class="flex flex-col gap8 w-full items-center">
              <p class="font-bold text24">Rp. {{ product.startBid?product.startBid.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.'):"-" }}</p>
              <BigButton class="font-bold text24 w-full border border-solid border-dark-20" @click="showBid1">
                Bid
              </BigButton>
            </div>
          </div>
        </div>

        <!-- Comission Percentage -->
        <ProductComission />

        <!-- Description Detail -->
        <!-- <ProductDescription /> -->
      
        <ProductDescription :description="product.description" />

        
        <!-- {{ product.description?product.description:"-" }} -->

        <!-- <ProductProsesDeposit /> -->
      
      </section>
    </div>

    <!-- Another item -->
    <div class="flex flex-col gap32 mt-16">
      <!-- Header -->
      <div class="flex flex-col gap-2 text-dark-100 cursor-default">
        <h3 class="font-bold text24">Cek Lelang yang lain</h3>
        <p class="text16">Mungkin ada lelang yang kamu suka di bawah ini</p>
      </div>

      <!-- Item card -->
      <div class="grid grid-cols-5 gap32">
        <CardProduct v-for="n in 10" :key="n" />
      </div>
    </div>
  </div>
 
<!-- ShowBin 1 -->
<div v-if="Bin1" class="Bin">
  <ModalsOverlay>
    <div class="dark:bg-darkGrey-100 bg-white flex flex-col justify-center gap-8 w-[486px] h-[535px] px-16 rounded-lg font-Plus_Jakarta_Sans">
      <div class="flex flex-col gap-2 items-start -ml-[24px]">
        <div class="self-stretch flex flex-col gap-3 items-start">
          <div class="text-2xl font-bold">
            Bin Disini!
          </div>
          <div class="text-lg w-[410px]">
            Anda dapat membeli langsung barang yang dipilih sesuai dengan harga yang ditentukan oleh penjual.
          </div>
        </div>
        <div class="flex flex-row gap-4 items-center">
          <img src="/img/user.png" class="w-16 shrink-0"/> 
          <div class="self-start flex flex-col justify-between gap-1 w-48 shrink-0 items-start">
            <div class="text-inherit-50">
              Bid tertinggi sementara:
            </div>
            <div class="text-lg font-bold">
              Agus Subagja
            </div>
            <div class="text-lg font-bold text-[#379956]">
              Rp. 3.900.000
            </div>
          </div>
        </div>
        <div class="flex flex-col justify-between gap-4 items-start">
          Harga Barang Buy It Now
          <div class="text-2xl w-[200px] font-bold text-[#379956]">
            Rp. {{ product.bin?product.bin.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.'):"-" }}
          </div>
          <div class="text-sm text-inherit-50">
            *Harga sudah termasuk pengiriman
          </div>
        </div>
        <div class="text-lg self-center w-full">
          Apakah yakin anda ingin membeli barang ini secara langsung?
        </div>
        <div class="flex gap-2 justify-center">
          <button class="font-bold w-[200px] h-[44px] sm:w-[110px] sm:h-[30px] text-[18px] sm:text-[12px] text-inherit-50 hover:text-white" style="font-family: 'Plus Jakarta Sans', sans-serif; transition: background-color 0.3s; display: flex; align-items: center; justify-content: center;" @click="hideBin1">
            kembali
          </button>
          <div>
            <button class="btn-confirm bg-[linear-gradient(98deg,_#ffd849_-8%,#ffc937_30%,#ffe88c_69%,#ffd546_125%)] bg-cover bg-50%_50% bg-blend-normal p-2 xl:p-4 font-bold rounded-lg text-sm xl:text-base dark:text-dark-100 w-[200px] h-[44px] sm:w-[110px] sm:h-[24px] text-[18px] sm:text-[12px]" style=" display: flex; align-items: center; justify-content: center;" @click="showBin2">
              Bin
            </button>
          </div>
        </div>
      </div>
    </div>
  </ModalsOverlay>
</div>

<!--ShowBin 2-->
<div v-if="Bin2" class="Bin">
  <ModalsOverlay>
    <div class="dark:bg-darkGrey-100 bg-white flex flex-col justify-center gap-8 w-[486px] h-[485px] px-16 rounded-lg font-Plus_Jakarta_Sans">
      <div class="flex flex-col gap-2 items-start -ml-[24px]">
        <div class="flex flex-row mr-16 gap-3 items-start">
          <div class="relative flex flex-col w-[410px] items-end">
            <div class="w-[280px] ml-12 h-1 bg-[linear-gradient(98deg,_#ffd849_-8%,#ffc937_30%,#ffe88c_69%,#ffd546_125%)] bg-cover bg-50%_50% bg-blend-normal bg-no-repeat absolute top-5 left-5 rounded-[41px]"></div>
            <div class="ml-14 w-10 h-10 absolute top-0 left-0 flex flex-col justify-center pl-4 items-start rounded-[76px] bg-[linear-gradient(98deg,_#ffd849_-8%,#ffc937_30%,#ffe88c_69%,#ffd546_125%)] bg-cover bg-50%_50% bg-blend-normal bg-no-repeat">
              <div class="text-center font-Plus_Jakarta_Sans font-bold text-[#222831]">
                1
              </div>
            </div>
            <div class="w-[94px] h-20 absolute top-0 left-32 flex flex-col gap-4 items-start">
              <div class="bg-[#d9d9d9] self-end flex flex-col justify-center pl-4 w-10 h-10 shrink-0 items-start rounded-[76px]">
                <div class="text-center font-Plus_Jakarta_Sans font-bold text-[#222831]">
                  2
                </div>
              </div> 
            </div>
            <div class="relative flex flex-col gap-4 items-start mr-14">
              <div class="bg-[#d9d9d9] self-end flex flex-col justify-center pl-4 w-10 h-10 shrink-0 items-start rounded-[76px]">
                <div class="text-center font-Plus_Jakarta_Sans font-bold text-[#222831]">
                  3
                </div>
              </div>
            </div>
          </div>
        </div> 
        <div class="text-center font-Plus_Jakarta_Sans font-bold w-[410px] -ml-9" style="text-align: right;">
          <div>Umum
            <span class="text-inherit-50 ml-[49px]">Pembayaran</span>
            <span class="text-inherit-50 ml-[42px]">Ringkasan</span>
          </div>
        </div>
        <div class="text-2xl font-Plus_Jakarta_Sans font-bold self-start mt-6">
            Informasi Umum
          </div>
          <div class="flex flex-col gap-4 items-start">
            <div class="flex flex-row justify-between w-3/5 items-start">
              <div class="font-Plus_Jakarta_Sans">
                Informasi Pribadi
              </div>
              <button class="text-right -mr-40 font-Plus_Jakarta_Sans text-[#2f80ed]">
                Edit
              </button>
            </div>
            <div class="border-solid border-[rgba(34,_40,_49,_0.2)] bg-white self-stretch flex flex-row justify-between items-center pl-4 pr-[170px] w-[408px] border rounded-lg">
              <div class="flex flex-col justify-between w-24 shrink-0 h-32 items-start my-4">
                <div class="font-Plus_Jakarta_Sans text-[rgba(34,_40,_49,_0.5)]">
                  Nama
                </div>
                <div class="font-Plus_Jakarta_Sans text-[rgba(34,_40,_49,_0.5)]">
                  Alamat
                </div>
                <div class="font-Plus_Jakarta_Sans text-[rgba(34,_40,_49,_0.5)]">
                  No. Telepon
                </div>
                <div class="font-Plus_Jakarta_Sans text-[rgba(34,_40,_49,_0.5)]">
                  Maps
                </div>
              </div>
              <div class="flex flex-col justify-between h-32 items-end ml-[115px]">
                <div class="text-right font-Plus_Jakarta_Sans font-semibold text-[#222831]">
                  {{ transaksi.nama?transaksi.nama:"-" }}
                </div>
                <div class="text-right font-Plus_Jakarta_Sans font-semibold text-[#222831]">
                  {{ transaksi.alamat?transaksi.alamat:"-" }}
                </div>
                <div class="text-right font-Plus_Jakarta_Sans font-semibold text-[#222831] w-40">
                  {{ transaksi.noTelepon?transaksi.noTelepon:"-" }}
                </div>
                <div class="text-right font-Plus_Jakarta_Sans underline font-semibold text-[#2f80ed]">
                  Pinpoint
                </div>
              </div>
            </div>
          </div>
        <div class="flex gap-2 justify-center mt-4">
          <button class="font-bold w-[200px] h-[44px] sm:w-[110px] sm:h-[30px] text-[18px] sm:text-[12px] text-inherit-50 hover:text-white" style="font-family: 'Plus Jakarta Sans', sans-serif;  display: flex; align-items: center; justify-content: center;" @click="hideBin2">
            kembali
          </button>
          <div>
            <button class="btn-confirm bg-[linear-gradient(98deg,_#ffd849_-8%,#ffc937_30%,#ffe88c_69%,#ffd546_125%)] bg-cover bg-50%_50% bg-blend-normal p-2 xl:p-4 font-bold rounded-lg text-sm xl:text-base dark:text-dark-100 w-[200px] h-[44px] sm:w-[110px] sm:h-[24px] text-[18px] sm:text-[12px]" style=" display: flex; align-items: center; justify-content: center;" @click="showBin3">
              Selanjutnya
            </button>
          </div>
        </div>
      </div>
    </div>
  </ModalsOverlay>
</div>

<!--ShowBin 3-->
<div v-if="Bin3" class="Bin">
  <ModalsOverlay>
    <div class="dark:bg-darkGrey-100 bg-white flex flex-col justify-center gap-8 w-[486px] h-[530px] px-16 rounded-lg font-Plus_Jakarta_Sans">
      <div class="flex flex-col gap-2 items-start -ml-[24px]">
        <div class="flex flex-row mr-16 gap-3 items-start">
          <div class="relative flex flex-col w-[410px] items-end">
            <div class="w-[280px] ml-12 h-1 bg-[linear-gradient(98deg,_#ffd849_-8%,#ffc937_30%,#ffe88c_69%,#ffd546_125%)] bg-cover bg-50%_50% bg-blend-normal bg-no-repeat absolute top-5 left-5 rounded-[41px]"></div>
            <div class="ml-14 w-10 h-10 absolute top-0 left-0 flex flex-col justify-center pl-[9px] items-start rounded-[76px] bg-[#2F80ED]">
              <div class="text-center font-Plus_Jakarta_Sans font-bold text-[#222831]">
                <img src="~/public/icons/checkmini.svg"/>
              </div>
            </div>
            <div class="w-[94px] h-20 absolute top-0 left-32 flex flex-col gap-4 items-start">
              <div class="bg-[linear-gradient(98deg,_#ffd849_-8%,#ffc937_30%,#ffe88c_69%,#ffd546_125%)] self-end flex flex-col justify-center pl-4 w-10 h-10 shrink-0 items-start rounded-[76px]">
                <div class="text-center font-Plus_Jakarta_Sans font-bold text-[#222831]">
                  2
                </div>
              </div> 
            </div>
            <div class="relative flex flex-col gap-4 items-start mr-14">
              <div class="bg-[#d9d9d9] self-end flex flex-col justify-center pl-4 w-10 h-10 shrink-0 items-start rounded-[76px]">
                <div class="text-center font-Plus_Jakarta_Sans font-bold text-[#222831]">
                  3
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div class="text-center font-Plus_Jakarta_Sans font-bold w-[410px] -ml-9" style="text-align: right;">
          <div>Umum
            <span class="ml-[49px]">Pembayaran</span>
            <span class="text-inherit-50 ml-[42px]">Ringkasan</span>
          </div>
        </div>
        <div class="overflow-hidden sm:w-full mt-6 w-[400px]">
            <h3 class="text-2xl sm:text-[12px] font-bold">Metode Pembayaran</h3>
        </div>
        <div class="font-Plus_Jakarta_Sans mt-3">
          Pilih Metode Pembayaran
        </div>
            
          <!-- Dompet-->
          <div class="sm:w-full w-[410px] font-Plus_Jakarta_Sans"> 
            <div class="border-solid dark:border-white/20 border-black-100 dark:bg-[#090909] flex flex-row gap-4 h-16 shrink-0 items-center px-4 border rounded-lg">

              <div class="nav">
                <button class="nav_burger" @click="openMenu" :class="{ 'active': isOpen }">
                  <div class="burger-icon flex flex-col w-8 h-8 items-center py-1">
                    <div v-if="!isOpen" class="w-[20px] h-[20px] border-[3px] dark:border-white border-black-100 rounded-full relative"></div>
                    <div v-if="isOpen" class="w-[20px] h-[20px] border-[3px] dark:border-white border-black-100 rounded-full relative">
                      <div class="dot"></div>
                    </div>
                  </div>
                </button>
              </div>

                <div class="border-solid dark:border-white/20 border-black-100 mr-1 w-px shrink-0 h-10 border-r border-l-0 border-y-0"/>
                <img src="~/public/icons/dompet.svg"/>
                <div class="flex flex-col items-start font-['Plus_Jakarta_Sans']">
                <div class="text-sm font-bold">Dompet</div>
                <div id="Rp" class="text-sm">Rp. -</div>
              </div>
            </div>
          </div>
        
           <!-- Kartu Kredit -->
           <div class="sm:w-full w-[410px] font-Plus_Jakarta_Sans"> 
            <div class="border-solid dark:border-white/20 border-black-100 dark:bg-[#090909] flex flex-row gap-4 h-14 shrink-0 items-center px-4 border rounded-lg">
                <button class="flex flex-col w-8 shrink-0 h-8 items-center py-1">
                <div class="w-[20px] h-[20px] border-[3px] dark:border-white border-black-100 rounded-full relative"></div>
                </button>
                <div class="border-solid dark:border-white/20 border-black-100 mr-1 w-px shrink-0 h-10 border-r border-l-0 border-y-0"/>
                <img src="~/public/icons/creadit.svg"/>
                <div class="flex flex-col items-start font-['Plus_Jakarta_Sans']">
                <div class="text-sm font-bold">Kartu Kredit</div>
              </div>
              <img src="~/public/icons/select.svg" class="ml-auto"/>
          </div>
        </div>
          
           <!-- Virtual Akun -->
           <div class=" sm:w-full w-[410px] font-Plus_Jakarta_Sans"> 
            <div class="border-solid dark:border-white/20 border-black-100 dark:bg-[#090909] flex flex-row gap-4 h-14 shrink-0 items-center px-4 border rounded-lg">
                <button class="flex flex-col w-8 shrink-0 h-8 items-center py-1">
                <div class="w-[20px] h-[20px] border-[3px] dark:border-white border-black-100 rounded-full relative"></div>
                </button>
                <div class="border-solid dark:border-white/20 border-black-100 mr-1 w-px shrink-0 h-10 border-r border-l-0 border-y-0"/>
                <img src="~/public/icons/va.svg"/>
                <div class="flex flex-col items-start font-['Plus_Jakarta_Sans']">
                <div class="text-sm font-bold">Virtual Akun</div>
              </div>
              <img src="~/public/icons/select.svg" class="ml-auto"/>
          </div>
        </div>
        <div class="flex gap-2 justify-center mt-4">
          <button class="font-bold w-[200px] h-[44px] sm:w-[110px] sm:h-[30px] text-[18px] sm:text-[12px] text-inherit-50 hover:text-white" style="font-family: 'Plus Jakarta Sans', sans-serif;  display: flex; align-items: center; justify-content: center;" @click="hideBin3">
            kembali
          </button>
          <div>
            <button class="btn-confirm bg-[linear-gradient(98deg,_#ffd849_-8%,#ffc937_30%,#ffe88c_69%,#ffd546_125%)] bg-cover bg-50%_50% bg-blend-normal p-2 xl:p-4 font-bold rounded-lg text-sm xl:text-base dark:text-dark-100 w-[200px] h-[44px] sm:w-[110px] sm:h-[24px] text-[18px] sm:text-[12px]" style=" display: flex; align-items: center; justify-content: center;" @click="showBin4">
              Selanjutnya
            </button>
          </div>
        </div>
      </div>
    </div>
  </ModalsOverlay>
</div>

<!--ShowBin 4-->
<div v-if="Bin4" class="Bin">
  <ModalsOverlay>
    <div class="dark:bg-darkGrey-100 bg-white flex flex-col justify-center gap-8 w-[486px] h-[690px] px-16 rounded-lg font-Plus_Jakarta_Sans">
      <div class="flex flex-col gap-2 items-start -ml-[24px]">
        <div class="flex flex-row mr-16 gap-3 items-start">
          <div class="relative flex flex-col w-[410px] items-end">
            <div class="w-[280px] ml-12 h-1 bg-[linear-gradient(98deg,_#ffd849_-8%,#ffc937_30%,#ffe88c_69%,#ffd546_125%)] bg-cover bg-50%_50% bg-blend-normal bg-no-repeat absolute top-5 left-5 rounded-[41px]"></div>
            <div class="ml-14 w-10 h-10 absolute top-0 left-0 flex flex-col justify-center pl-[9px] items-start rounded-[76px] bg-[#2F80ED]">
              <div class="text-center font-Plus_Jakarta_Sans font-bold text-[#222831]">
                <img src="~/public/icons/checkmini.svg"/>
              </div>
            </div>
            <div class="w-[94px] h-20 absolute top-0 left-32 flex flex-col gap-4 items-start">
              <div class="bg-[#2F80ED] self-end flex flex-col justify-center pl-[9px] w-10 h-10 shrink-0 items-start rounded-[76px]">
                <div class="text-center font-Plus_Jakarta_Sans font-bold text-[#222831]">
                  <img src="~/public/icons/checkmini.svg"/>
                </div>
              </div> 
            </div>
            <div class="relative flex flex-col gap-4 items-start mr-14">
              <div class="bg-[linear-gradient(98deg,_#ffd849_-8%,#ffc937_30%,#ffe88c_69%,#ffd546_125%)] self-end flex flex-col justify-center pl-4 w-10 h-10 shrink-0 items-start rounded-[76px]">
                <div class="text-center font-Plus_Jakarta_Sans font-bold text-[#222831]">
                  3
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div class="text-center font-Plus_Jakarta_Sans font-bold w-[410px] -ml-9" style="text-align: right;">
          <div>Umum
            <span class="ml-[49px]">Pembayaran</span>
            <span class="ml-[42px]">Ringkasan</span>
          </div>
        </div>
        <div class="text-2xl font-Plus_Jakarta_Sans font-bold self-start mt-6">
          Ringkasan
        </div>
        <div class="flex flex-col gap-4 items-start">
          <div class="flex flex-row justify-between w-3/5 items-start">
            <div class="font-Plus_Jakarta_Sans">
              Informasi Pribadi
            </div>
          </div>
        
          <div class="border-solid border-[rgba(34,40,49,0.2)] bg-white self-stretch flex flex-row justify-between items-center pl-4 pr-[170px] w-[408px] border rounded-lg font-Plus_Jakarta_Sans">
            <div class="flex flex-col justify-between w-24 shrink-0 h-32 items-start my-4">
              <div class="text-[rgba(34,40,49,0.5)]">
                Nama
              </div>
              <div class="text-[rgba(34,40,49,0.5)]">
                Alamat
              </div>
              <div class="text-[rgba(34,40,49,0.5)]">
                No. Telepon
              </div>
              <div class="text-[rgba(34,40,49,0.5)]">
                Maps
              </div>
            </div>
            
            <div class="flex flex-col justify-between h-32 items-end ml-[115px] font-Plus_Jakarta_Sans font-semibold">
              <div class="text-right text-[#222831]">
                {{ transaksi.nama?transaksi.nama:"-" }}
              </div>
              <div class="text-right text-[#222831]">
                {{ transaksi.alamat?transaksi.alamat:"-" }}
              </div>
              <div class="text-right text-[#222831] w-40">
                {{ transaksi.noTelepon?transaksi.noTelepon:"-" }}
              </div>
              <div class="text-right underline text-[#2f80ed]">
                Pinpoint
              </div>
            </div>
          </div>
        </div>
        <div class="font-Plus_Jakarta_Sans mt-4">
          Metode Pembayaran
        </div>

        <!-- Dompet-->
        <div class="sm:w-full w-[410px] font-Plus_Jakarta_Sans mt-2">
          <div class="border-solid dark:border-white/20 border-[rgba(34,40,49,0.2)] bg-white flex flex-row gap-4 h-16 shrink-0 items-center px-4 border rounded-lg">
            <img class="bg-dark-100" src="~/public/icons/dompet.svg" />
            <div class="flex flex-col items-start font-['Plus_Jakarta_Sans']">
              <div class="font-bold text-[#222831]">Dompet</div>
              <div id="Rp" class="text-[#222831]">Rp. -</div>
            </div>
          </div>
        </div>
        <div class="flex flex-col gap-4 w-[410px] items-start">
          <div class="font-['Plus_Jakarta_Sans'] text-white">Total Pembelian</div>
          <div class="flex flex-row gap-4 items-start">
            <div class="text-2xl font-['Plus_Jakarta_Sans'] font-bold text-[#379956] w-full">
              Total : <span class="ml-[140px]">Rp. 10.000.000</span>
            </div>
          </div>
        </div>
  
        <div class="flex gap-2 justify-center mt-4">
          <button class="font-bold w-[200px] h-[44px] sm:w-[110px] sm:h-[30px] text-[18px] sm:text-[12px] text-inherit-50 hover:text-white" style="font-family: 'Plus Jakarta Sans', sans-serif;  display: flex; align-items: center; justify-content: center;" @click="hideBin4">
            kembali
          </button>
          <div>
            <button class="btn-confirm bg-[linear-gradient(98deg,_#ffd849_-8%,#ffc937_30%,#ffe88c_69%,#ffd546_125%)] bg-cover bg-50%_50% bg-blend-normal p-2 xl:p-4 font-bold rounded-lg text-sm xl:text-base dark:text-dark-100 w-[200px] h-[44px] sm:w-[110px] sm:h-[24px] text-[18px] sm:text-[12px]" style=" display: flex; align-items: center; justify-content: center;" @click="showBin5">
              Selanjutnya
            </button>
          </div>
        </div>
      </div>
    </div>
  </ModalsOverlay>
</div>

 <!-- ShowBin 5-->
 <div v-if="Bin5" class="Bin">
  <ModalsOverlay>
    <div class="dark:bg-darkGrey-100 bg-white w-10px h-10px rounded-lg flex flex-col gap-32 ml-4" style="font-family: 'Plus Jakarta Sans', sans-serif; rounded-lg">
      <div class="h-[449px] w-[400px] sm:h-[365px] sm:w-[280px]">
        <h2 class="font-bold py-4 px-6 text-[16px] sm:text-[12px]">Konfirmasi</h2>
        <div class="flex items-center justify-center mt-[25px] sm:mt-[10px]">
          <img class="sm:w-[205px] w-[300px]" src="~/public/icons/undraw1.png" alt="Gambar" />
        </div>
        <p class="px-7 sm:mt-[15px] mt-[30px] text-[16px] sm:text-[12px]">
          <div class="font-['Plus_Jakarta_Sans'] w-full w-[370px]">
            Apakah anda yakin ingin membeli langsung barang ini seharga
            <span class="font-bold text-[#379956]">Rp. 10.000.000</span>?
          </div>
        </p>
        <div class="flex mt-[20px] sm:mt-[1rem] gap-2 justify-center">
          <div class="" style="font-family: 'Plus Jakarta Sans', sans-serif; transition: background-color 0.3s;">
            <button class="font-bold w-[168px] h-[44px] sm:w-[110px] sm:h-[30px] text-[16px] sm:text-[12px]" style=" display: flex; align-items: center; justify-content: center;" @click="hideBin5">
              Tidak
            </button>
          </div>
          <div>
            <button class="btn-confirm bg-primary p-2 xl:p-4 font-bold rounded-lg text-sm xl:text-base dark:text-dark-100 w-[168px] h-[44px] sm:w-[110px] sm:h-[24px] text-[16px] sm:text-[12px]" style=" display: flex; align-items: center; justify-content: center;" @click="showBin6">
              Ya
            </button>
          </div>
        </div>
      </div>
    </div>
  </ModalsOverlay>
</div>

<!-- showbin6 -->
<div v-if="Bin6" class="Bin">
  <ModalsOverlay>
    <div class="dark:bg-darkGrey-100 bg-white w-10px h-8px rounded-lg flex flex-col gap-32 ml-4" style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 16px;">
      <div class="h-[449px] w-[400px] sm:h-[365px] sm:w-[280px]">
        <h2 class="font-bold py-4 px-6 text-[16px] sm:text-[12px]">Konfirmasi</h2>
        <div class="flex items-center justify-center mt-[30px] sm:mt-[13px]">
          <img class="sm:w-[150px] w-[185px]" src="~/public/icons/undraw.svg" alt="Gambar" />
        </div>
        <p class="sm:mt-[1px] mt-[18px] px-6 text-[16px] sm:text-[12px]">
          Selamat, anda sudah membeli barang yang anda pilih.
        </p>
        <div class="flex mt-[26px] sm:mt-[1rem] gap-2 justify-center">
            <button class="btn-confirm bg-primary p-2 xl:p-4 font-bold rounded-lg text-sm xl:text-base dark:text-dark-100 w-[350px] h-[44px] sm:w-[230px] sm:h-[30px] text-[16px] sm:text-[12px]" style="font-family: 'Plus Jakarta Sans', sans-serif; transition: background-color 0.3s; display: flex; align-items: center; justify-content: center;" @click="myObject.berhasil">
              OK
            </button>
        </div>
      </div>
    </div>
  </ModalsOverlay>
</div>

<!-- Bid 1 -->
<div v-if="Bid1" class="Bid">
    <ModalsOverlay>
      <div class="dark:bg-darkGrey-100 bg-white flex flex-col justify-center gap-8 w-[500px] h-[540px] px-10 rounded-lg font-Plus_Jakarta_Sans">
        <div class="flex flex-col gap-3 items-start mt-[rem]">
          <div class="text-2xl font-bold">
            Bid Disini!
          </div>
          <div class="text-lg w-[410px]">
            Silahkan masukkan jumlah bid yang kamu inginkan sesuai dengan kelipatan yang ditentukan oleh pemilik barang.
          </div>
        </div>
        <div class="self-start flex flex-row gap-4 items-center -mt-4">
          <img src="/img/user.png" class="w-16 shrink-0"/> 
          <div class="self-start flex flex-col justify-between gap-1 w-48 shrink-0 items-start">
            <div class="text-inherit-50">
              Bid tertinggi sementara:
            </div>
            <div class="text-2xl font-bold">
              Agus Subagja
            </div>
            <div class="text-2xl font-bold text-[#379956]">
              Rp. 3.900.000
            </div>
          </div>
        </div>
        <div class="flex flex-col justify-between gap-4 items-start -mt-4">
          <div>Bid</div>
          <div id="BidInput" class="border-solid border-inherit-20 dark:bg-[#090909] self-stretch flex flex-row gap-4 h-12 shrink-0 items-center px-4 border rounded-lg">
            <img src="~/public/icons/money.svg" class="w-7 shrink-0"/> 
            <div class="text-lg text-inherit-50">
              Rp. {{ product.startBid?product.startBid.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.'):"-" }}
              <span class="text-white/50 hidden sm:inline ml-2 w-[240px] border-2">
                <input class="bg-transparent border-none outline-none sm:w-7" type="text" v-model="formattedPrice1" @input="formatPrice1" placeholder="00" />
              </span>
            </div>
          </div>
          <div class="font-bold">
            Kelipatan Rp. {{ product.startBid?product.startBid.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.'):"-" }}
          </div>
        </div>
        <div class="flex flex-row justify-between ml-8 items-center text-lg text-inherit-50 font-bold hover:text-white">
          <button class="bg-transparant self-start flex flex-col justify-center pl-8 w-1/2 h-12 cursor-pointer items-start rounded-lg -ml-8">
            <div class="text-lg font-bold flex ml-8" @click="hideBid1">
              Kembali
            </div>
          </button>
          <button class="btn-confirm bg-[linear-gradient(98deg,_#ffd849_-8%,#ffc937_30%,#ffe88c_69%,#ffd546_125%)] bg-cover bg-50%_50% bg-blend-normal text-dark-100 self-start flex flex-col justify-center pl-8 w-1/2 h-12 cursor-pointer items-start rounded-lg" @click="showBid2">
            <div class="text-lg font-bold flex ml-12">
              Bid
            </div>
          </button>
        </div>
      </div>
    </ModalsOverlay>
</div>
    
<!-- Bid 2-->
<div v-if="Bid2" class="Bid">
<ModalsOverlay>
  <div class="dark:bg-darkGrey-100 bg-white w-10px h-10px rounded-lg flex flex-col gap-32 ml-4" style="font-family: 'Plus Jakarta Sans', sans-serif; rounded-lg">
    <div class="h-[469px] w-[400px] sm:h-[365px] sm:w-[280px]">
      <h2 class="font-bold py-4 px-6 text-[16px] sm:text-[12px]">Konfirmasi</h2>
      <div class="flex items-center justify-center mt-[25px] sm:mt-[10px]">
        <img class="sm:w-[205px] w-[300px]" src="~/public/icons/undraw1.png" alt="Gambar" />
      </div>
      <p class="px-6 sm:mt-[15px] mt-[35px] text-[16px] sm:text-[12px]">
        <div class="font-['Plus_Jakarta_Sans'] w-full">
          Apakah anda yakin ingin melakukan bidding di harga
          <span class="font-bold">Rp {{ product.startBid?product.startBid.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.'):"-" }}</span>?
        </div>
      </p>
      <div class="flex mt-[37px] sm:mt-[1rem] gap-2 justify-center">
        <div>
          <button class="font-bold w-[168px] h-[44px] sm:w-[110px] sm:h-[30px] text-[16px] sm:text-[12px]" style="font-family: 'Plus Jakarta Sans', sans-serif; transition: background-color 0.3s; display: flex; align-items: center; justify-content: center;"  @click="hideBid2">
            Tidak
          </button>
        </div>
        <div>
          <button class="btn-confirm bg-primary p-2 xl:p-4 font-bold rounded-lg text-sm xl:text-base dark:text-dark-100 w-[168px] h-[44px] sm:w-[110px] sm:h-[24px] text-[16px] sm:text-[12px]" style="font-family:'Plus Jakarta Sans', sans-serif; transition: background-color 0.3s; display: flex; align-items: center; justify-content: center;" @click="showBid3">
            Ya
          </button>
        </div>
      </div>
    </div>
  </div>
</ModalsOverlay>
</div>

<!-- Bid 3-->
<div v-if="Bid3" class="Bid">
<ModalsOverlay>
  <div class="dark:bg-darkGrey-100 bg-white w-10px h-8px rounded-lg flex flex-col gap-32 ml-4" style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 16px;">
    <div class="h-[469px] w-[400px] sm:h-[365px] sm:w-[280px]">
      <h2 class="font-bold py-4 px-6 text-[16px] sm:text-[12px]">Konfirmasi</h2>
      <div class="flex items-center justify-center mt-[30px] sm:mt-[13px]">
        <img class="sm:w-[150px] w-[185px]" src="~/public/icons/undraw.svg" alt="Gambar" />
      </div>
      <p class="sm:mt-[1px] mt-[18px] px-6 text-[16px] sm:text-[12px]">
        Selamat, permintaan lelang Anda sudah dikirim ke pihak HistoryOutlet. Silahkan cek secara berkala pada bagian Penjualan.
      </p>
      <div class="flex mt-[26px] sm:mt-[1rem] gap-2 justify-center">
          <button class="btn-confirm bg-primary p-2 xl:p-4 font-bold rounded-lg text-sm xl:text-base dark:text-dark-100 w-[350px] h-[44px] sm:w-[230px] sm:h-[30px] text-[16px] sm:text-[12px]" style="font-family: 'Plus Jakarta Sans', sans-serif; transition: background-color 0.3s; display: flex; align-items: center; justify-content: center;" @click="berhasil">
            OK
          </button>
      </div>
    </div>
  </div>
</ModalsOverlay>
</div>

</template>

<style>
  .btn-confirm:hover {
    --dark: #222831;
    background: var(--dark);
    transition: background-color 0.3s;
    color: white;
  }

  .dot {
    width: 10px;
    height: 10px;
    background-color: rgb(245, 243, 243);
    border-radius: 50%;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    display: none;
  }
  
  .active .dot {
    display: block;
  }
</style>