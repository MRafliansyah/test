<template>
    <div class="flex justify-center">
      <div>
        <p class="py-6 text-center" style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 24px; font-weight: 500; line-height: normal;">FAQ</p>
  
        <!-- FAQ 1 -->
        <ul class="sm:w-[240px] md:w-[340px] lg:w-[440px] xl:w-[440px] max-w-screen-lg mx-auto">
          <li v-for="(item, index) in items1" :key="index" class="relative border border-gray-600 rounded-lg mb-4">
            <div @click="toggleRotation1">
              <button @click="toggleItem1(index)" class="flex items-center justify-between h-[86px] focus:outline-none ">
                <p class="text-left px-5" style="font-family: 'Plus Jakarta Sans', sans-serif; font-style: normal line-height: normal;">{{ item.question1 }}</p>
                <img :class="{ rotate: isOpen1.includes(index) }" :id="'animated-image1-' + index" @click="toggleRotation1(index)" class="ml-auto" src="~/public/icons/select.svg"  />
              </button>
            </div>
            <div v-if="isOpen1.includes(index)" class="py-2 bg-black rounded-lg overflow-hidden ">
              <div class="w-[92%] h-0.5 bg-white mx-auto"></div>
              <a href="#" class="block px-4 py-2 text-inherit-50 sm:w-full md:w-full 3xl:w-[440px] ">{{ item.answer1 }}</a>
            </div>
          </li>
        </ul>
  
        <!-- FAQ 2 -->
        <ul class="sm:w-[240px] md:w-[340px] lg:w-[440px] max-w-screen-lg mx-auto">
          <li v-for="(item, index) in items2" :key="index" class="relative border border-gray-600 rounded-lg mb-4">
            <div @click="toggleRotation2">
              <button @click="toggleItem2(index)" class="flex items-center justify-between h-[86px] focus:outline-none">
                <p class="text-left px-5" style="font-family: 'Plus Jakarta Sans', sans-serif; font-style: normal line-height: normal;">{{ item.question2 }}</p>
                <img :class="{ rotate: isOpen2.includes(index) }" :id="'animated-image2-' + index" @click="toggleRotation2(index)" src="~/public/icons/select.svg" />
              </button>
            </div>
            <div v-if="isOpen2.includes(index)" class="py-2 bg-black rounded-lg overflow-hidden ">
              <div class="w-[92%] h-0.5 bg-white mx-auto"></div>
              <a href="#" class="block px-4 py-2 text-inherit-50 sm:w-full md:w-full 3xl:w-[440px] ">{{ item.answer2 }}</a>
            </div>
          </li>
        </ul>
  
        <!-- FAQ 3 -->
        <ul class="sm:w-[240px] md:w-[340px] lg:w-[440px] max-w-screen-lg mx-auto">
          <li v-for="(item, index) in items3" :key="index" class="relative border border-gray-600 rounded-lg mb-4">
            <div @click="toggleRotation3">
              <button @click="toggleItem3(index)" class="flex items-center justify-between h-[86px] focus:outline-none">
                <p class="text-left px-5" style="font-family: 'Plus Jakarta Sans', sans-serif; font-style: normal line-height: normal;">{{ item.question3 }}</p>
                <img :class="{ rotate: isOpen3.includes(index) }" :id="'animated-image3-' + index" @click="toggleRotation3(index)" src="~/public/icons/select.svg" />
              </button>
            </div>
            <div v-if="isOpen3.includes(index)" class="py-2 bg-black rounded-lg overflow-hidden ">
              <div class="w-[92%] h-0.5 bg-white mx-auto"></div>
              <a href="#" class="block px-4 py-2 text-inherit-50 sm:w-full md:w-full 3xl:w-[440px] ">{{ item.answer3 }}</a>
            </div>
          </li>
        </ul>
      </div>
    </div>
</template>

 
 <script>
export default {
  data() {
    return {
      isOpen1: [],
      items1: [
        {
          question1: "Bagaimana membeli tiket konser di website?",
          answer1: "Untuk membeli tiket, buka aplikasi kami, cari konser yang Anda minati, pilih tanggal dan kursi yang Anda inginkan, lalu klik 'Beli Tiket'."
        },
      ],
      isOpen2: [],
      items2: [
        {
          question2: "Bagaimana cara mengikuti lelang?",
          answer2: "Cara membeli tiket konser di website adalah dengan membuka aplikasi kami, mencari konser yang Anda inginkan, memilih kursi, dan menyelesaikan pembelian."
        },
      ],
      isOpen3: [],
      items3: [
        {
          question3: "Bagaimana cara melihat hasil lelang?",
          answer3: "Untuk membeli tiket konser di website kunjungi situs kami, pilih konser yang Anda suka, tentukan tanggal dan kursi, dan klik tombol 'Beli Tiket'."
        },
      ],
    }
  },
  methods: {
    toggleItem1(index) {
      if (this.isOpen1.includes(index)) {
        this.isOpen1 = this.isOpen1.filter(item => item !== index);
      } else {
        this.isOpen1.push(index);
      }
    },
    toggleRotation1(index) {
    },
    toggleItem2(index) {
      if (this.isOpen2.includes(index)) {
        this.isOpen2 = this.isOpen2.filter(item => item !== index);
      } else {
        this.isOpen2.push(index);
      }
    },
    toggleRotation2(index) {
    },
    toggleItem3(index) {
      if (this.isOpen3.includes(index)) {
        this.isOpen3 = this.isOpen3.filter(item => item !== index);
      } else {
        this.isOpen3.push(index);
      }
    },
    toggleRotation3(index) {
    }
  }
}
  </script>

<style>
.rotate {
  transform: rotate(180deg);
}
</style>