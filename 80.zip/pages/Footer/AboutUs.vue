<template>
  <div class="flex flex-col items-center">
    <h1 class="text-xl font-['Plus_Jakarta_Sans'] font-medium mt-4">
      Tentang Kami
    </h1>
    <div class="flex flex-col items-center gap-4 w-full max-w-4xl text-lg font-['Plus_Jakarta_Sans'] font-medium mt-4">
      <img class="sm:w-[100px] md:w-[130px] lg:w-[150px] 2xl:w-[150px]" src="~/public/img/logoho1.png">
      <h2 class="text-center sm:w-[200px] sm:text-xs md:text-sm">
        HISTORI OUTLET adalah aplikasi untuk melelang barang-barang Dan pembelian tiket konser Dengan tujuan membangun aplikasi yang menggabungkan fitur lelang barang dan pembelian tiket konser,kami berusaha untuk memberikan pengalaman yang menarik dan bermanfaat bagi pengguna.
      </h2>
    </div>
  </div>
</template>

<script lang="ts" setup></script>
<style scoped></style>
