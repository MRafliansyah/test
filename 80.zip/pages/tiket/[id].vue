<script setup>
import { ref, onMounted } from 'vue';
import axios from 'axios';
const route = useRoute();
const ticket = ref({});
// const lelang = ref({});

const fetchTickets = async () => {
  try {
    let config = {
      method: 'get',
      maxBodyLength: Infinity,
      url: 'https://65558d7284b36e3a431de9a5.mockapi.io/tiket/'+route.params.id,
      headers: { 
      }
    };
    const response = await axios.request(config)
    
    .then((response) => {
      console.log(response.data)   
      ticket.value = response.data;
    })
    .catch((error) => {
      console.log(error);
    })
    // ticket.value = response.data;

  } catch (error) {
    console.error('Error fetching tickets:', error);
  }
};

onMounted(fetchTickets);
</script>


<!--TIKET-->
<script>
export default {
  data() {
    return {
      isBidSuccessful: false,
      timeRemaining: null,
      countdownUnits: [],
    };
  },
  async mounted() {
    
    const route = useRoute();
    let config = {
      method: 'get',
      maxBodyLength: Infinity,
      url: 'https://65558d7284b36e3a431de9a5.mockapi.io/tiket/'+route.params.id,
      headers: { 
      }
    };
    const response = await axios.request(config)
    .then((response) => {
      if(response.data.statusTiket !== "-"){
        this.isBidSuccessful = true
      } 

      const formattedDate = this.createDateFromIndonesianDate(response.data.tanggal);
      const timeFromDatabase = response.data.jam
      const endTime = new Date(formattedDate).getTime();
      var calDateTime = `${formattedDate}T${timeFromDatabase.slice(0, 2)}:${timeFromDatabase.slice(2)}`;
      console.log(calDateTime)
      const dateObject = new Date(calDateTime).getTime();
      const now = new Date().getTime();
      const secondsDifference = Math.floor((dateObject - now) / 1000);
      if (secondsDifference <= 0) {
        this.timeRemaining = null; 
      } else {
        this.timeRemaining = this.convertSecondsToTime(secondsDifference);

        setInterval(() => {
          this.updateCountdown();
        }, 1000);
      }

    })
    .catch((error) => {
      console.log(error);
    });
  },
  methods: {
      createDateFromIndonesianDate(indonesianDateString) {
        const indonesianMonths = [
            'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
            'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
        ];
        
        const monthNumber = [1,2,3,4,5,6,7,8,9,10,11,12];

        const [day, month, year] = indonesianDateString.split(' ');
        var indexDate = indonesianMonths.indexOf(month)+1
        if (indexDate < 10){
          indexDate = "0"+indexDate.toString()
        } else {indexDate = indexDate.toString()}
        const date = year+"-"+indexDate+"-"+day
        return date
    },

    convertSecondsToTime(seconds) {
      // console.log(seconds)
      const days = Math.floor(seconds / (3600 * 24));
      const hours = Math.floor((seconds % (3600 * 24)) / 3600);
      const minutes = Math.floor((seconds % 3600) / 60);
      const remainingSeconds = seconds % 60;

      return {
        days,
        hours,
        minutes,
        seconds: remainingSeconds,
      };
    },
    updateCountdown() {
      if (this.timeRemaining) {
        if (this.timeRemaining.days > 0 || this.timeRemaining.hours > 0 || this.timeRemaining.minutes > 0 || this.timeRemaining.seconds > 0) {
          if (this.timeRemaining.seconds > 0) {
            this.timeRemaining.seconds--;
          } else {
            if (this.timeRemaining.minutes > 0) {
              this.timeRemaining.minutes--;
              this.timeRemaining.seconds = 59;
            } else {
              if (this.timeRemaining.hours > 0) {
                this.timeRemaining.hours--;
                this.timeRemaining.minutes = 59;
                this.timeRemaining.seconds = 59;
              } else {
                if (this.timeRemaining.days > 0) {
                  this.timeRemaining.days--;
                  this.timeRemaining.hours = 23;
                  this.timeRemaining.minutes = 59;
                  this.timeRemaining.seconds = 59;
                } else {
                  // Lelang telah ditutup
                  this.timeRemaining = null;
                  // Menandakan bahwa lelang berhasil
                  this.isBidSuccessful = true; 
                }
              }
            }
          }
          this.countdownUnits = [
            { label: 'Hari', value: this.padNumber(this.timeRemaining.days) },
            { label: 'Jam', value: this.padNumber(this.timeRemaining.hours) },
            { label: 'Menit', value: this.padNumber(this.timeRemaining.minutes) },
            { label: 'Detik', value: this.padNumber(this.timeRemaining.seconds) },
          ];
        }
      }
    },
    padNumber(num) {
      return num.toString().padStart(2, '0');
    },
  },
};
</script>

<template>
  {{ ticket }}
  <div class="px-60 2xl:px-48 xl:px-40 mt-44 2xl:mt-[140px] xl:mt-28 sm:-mt-4">
    <!-- Breadcrumbs -->
    <div class="flex gap-4 font-medium text16 sm:-ml-[130px]">
      <NuxtLink to="/" class="text-dark-50 cursor-pointer">Beranda</NuxtLink>
      <p class="text-dark-100 cursor-default">/</p>
      <p class="text-yellow-100 cursor-pointer">Detail Tiket</p>
    </div>

    <!-- Main content -->
    <div class="mt-8 2xl:mt-6 flex gap-16 2xl:gap-[52px] xl:gap-11">
      <!-- Image section -->
      <section class="flex flex-col gap32 w-[30.2vw] shrink-0">
        <div class="sm:w-[350px] sm:-ml-[140px]">
          <img src="/img/sample_makki.png" alt="Main image" class="p-4 border border-dark-20 border-solid rounded-lg w-full">
        </div>
        
        <!-- Mini image -->
        <div class="flex gap32 justify-between">
          <div class="p-2 bg-yellow-100 border border-solid border-dark-20 rounded-lg cursor-pointer">
            <img src="/img/sample_makki.png" alt="Mini image">
          </div>
          <div class="p-2 border border-solid border-dark-20 rounded-lg cursor-pointer">
            <img src="/img/sample_makki.png" alt="Mini image">
          </div>
          <div class="p-2 border border-solid border-dark-20 rounded-lg cursor-pointer">
            <img src="/img/sample_makki.png" alt="Mini image">
          </div>
          <div class="p-2 border border-solid border-dark-20 rounded-lg cursor-pointer">
            <img src="/img/sample_makki.png" alt="Mini image">
          </div>
        </div>
      </section>

      <!-- Detail Section -->
      <section class="flex flex-col gap32 sm:-ml-[300px] sm:mt-[180px]">
        <!-- Header -->
        <div class="flex gap32">
          <div class="flex flex-col gap16">
            <p class="font-medium text32 sm:mt-[225px]">Music</p>
            <p class="font-semibold text-[64px] 2xl:text-[52px] xl:text[45px] sm:text-lg leading-none">{{ ticket?ticket.name:"-" }}</p>
          </div>

          <!-- Side button -->
          <div class="flex flex-col py-6 px-4 gap-6 border border-solid border-dark-50 rounded-full self-start sm:mt-[310px] sm:-ml-[40px]">
            <!-- Like -->
            <div class="flex flex-col gap-1 items-center cursor-pointer">
              <nuxt-icon name="favorite" class="text24" />
              <p class="text-[13px] 2xl:text-[10px] leading-none">Like</p>
            </div>
            <!-- Share -->
            <div class="flex flex-col gap-1 items-center cursor-pointer">
              <nuxt-icon name="share" class="text24 " />
              <p class="text-[13px] 2xl:text-[10px] leading-none">Share</p>
            </div>
          </div>
        </div>

        <!-- Name, price and time -->
        <div class="flex">
          <!-- Left (Name and time) -->
          <div class="flex flex-col gap32">
            

            <!-- Harga -->
            <div class="flex gap16 items-center sm:-mt-[150px]">
              <div class="flex flex-col gap-1 2xl:gap-[3px]">
                <p class="text24">Harga OTS : Rp {{ ticket.hargaOts?ticket.hargaOts.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.'):"-" }}</p>

                <p class="text24">Harga Online :<span class="text24 text-green-100">  Rp {{ ticket.hargaOnline?ticket.hargaOnline.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.'):"-" }}</span></p>
                
            <!-- Buy it now -->
                <div class="flex flex-col gap8 w-full items-center py-5">
                  <BigButton class="bg-yellow-100 font-bold text24 w-full text-black-100">
                    <NuxtLink to="/tiket/metodepembayaran">Beli Sekarang</NuxtLink>
                  </BigButton>
                </div>
                
              </div>
            </div>
            <!-- Time -->
            <div class="flex flex-col gap16">
              <div class="flex flex-col">
                <p class="font-bold text24">Waktu Tiket Tersisa</p>
                <p class="text16">{{ ticket?ticket.tanggal:"-" }}</p>
              </div>
              <div class="flex gap16">
                <!-- Day -->
                <!-- <div class="flex flex-col gap-2">
                  <div class="flex gap-2">
                    <ProductTime>0</ProductTime>
                    <ProductTime>1</ProductTime>
                  </div>
                  <p class="text-center text16">Hari</p>
                </div> -->

                <!-- Hour -->
                <!-- <div class="flex flex-col gap-2">
                  <div class="flex gap-2">
                    <ProductTime>0</ProductTime>
                    <ProductTime>1</ProductTime>
                  </div>
                  <p class="text-center text16">Jam</p>
                </div> -->

                <!-- Minute -->
                <!-- <div class="flex flex-col gap-2">
                  <div class="flex gap-2">
                    <ProductTime>0</ProductTime>
                    <ProductTime>1</ProductTime>
                  </div>
                  <p class="text-center text16">Menit</p>
                </div> -->

                <!-- Second -->
                <!-- <div class="flex flex-col gap-2">
                  <div class="flex gap-2">
                    <ProductTime>0</ProductTime>
                    <ProductTime>2</ProductTime>
                  </div>
                  <p class="text-center text16">Detik</p>
                </div> -->
              </div>
            </div>
          </div>
        </div>


        <!-- <div v-if="isBidSuccessful">
          <p>Tiket SOLD</p>
        </div> -->
        <div v-if="timeRemaining === null">
          <!-- Tampilan jika tiket telah ditutup -->
          <p>Pembelian Telah DiTutup.</p>
        </div>
        <div v-else>
        <div class="flex gap16">
          <!-- Day -->
          <div v-if="countdownUnits && countdownUnits.length > 3" class="flex flex-col gap-2">
            <div class="flex gap-2" v-if="countdownUnits[0].value >= 100">
              <ProductTime>{{ Math.floor(countdownUnits[0].value / 100) }}</ProductTime>
              <ProductTime>{{ Math.floor((countdownUnits[0].value % 100) / 10) }}</ProductTime>
              <ProductTime>{{ countdownUnits[0].value % 10 }}</ProductTime>
            </div>
            <div class="flex gap-2" v-else>
              <ProductTime>{{ countdownUnits[0].value.toString().padStart(2, '0')[0] }}</ProductTime>
              <ProductTime>{{ countdownUnits[0].value.toString().padStart(2, '0')[1] }}</ProductTime>
            </div>
            <p class="text-center text16">{{ countdownUnits[0].label }}</p>
          </div>
          
      
          <!-- Hour -->
          <div v-if="countdownUnits && countdownUnits.length > 2" class="flex flex-col gap-2">
            <div class="flex gap-2">
              <ProductTime>{{ countdownUnits[1].value.toString().padStart(2, '0')[0] }}</ProductTime>
              <ProductTime>{{ countdownUnits[1].value.toString().padStart(2, '0')[1] }}</ProductTime>
            </div>
            <p class="text-center text16">{{ countdownUnits[1].label }}</p>
          </div>
      
          <!-- Minute -->
          <div v-if="countdownUnits && countdownUnits.length > 1" class="flex flex-col gap-2">
            <div class="flex gap-2">
              <ProductTime>{{ countdownUnits[2].value.toString().padStart(2, '0')[0] }}</ProductTime>
              <ProductTime>{{ countdownUnits[2].value.toString().padStart(2, '0')[1] }}</ProductTime>
            </div>
            <p class="text-center text16">{{ countdownUnits[2].label }}</p>
          </div>
      
          <!-- Second -->
          <div v-if="countdownUnits && countdownUnits.length > 0" class="flex flex-col gap-2">
            <div class="flex gap-2">
              <ProductTime>{{ countdownUnits[3].value.toString().padStart(2, '0')[0] }}</ProductTime>
              <ProductTime>{{ countdownUnits[3].value.toString().padStart(2, '0')[1] }}</ProductTime>
            </div>
            <p class="text-center text16">{{ countdownUnits[3].label }}</p>
          </div>
        </div>
      </div>

        <!-- Description Detail -->
        <ProductDescriptionTiket :description="ticket.description" />

      </section>
    </div>

    <!-- Another item -->
    <div class="flex flex-col gap32 mt-16">
      <div class="flex flex-col gap-2 cursor-default">
        <h3 class="font-bold text24">Cek Lelang yang lain</h3>
        <p class="text16">Mungkin ada lelang yang kamu suka di bawah ini</p>
      </div>

      <!-- Item card -->
      <div class="grid grid-cols-5 gap32">
        <CardProduct v-for="n in 10" :key="n" /><!-- pake card lelang -->
      </div>
    </div>
  </div>
</template>

<style scoped>
  .bg-yellow-100 {
    background-color: #FFD700; 
  }
  .bg-yellow-100:hover {
    background-color: #222831;
    color: #FFF;
  }
</style>