<template>
<main class="px-60 2xl:px-48 xl:px-40 sm:px-4">
  <section class="mt-[32px] sm:mt-8 flex flex-col gap-32">
      <div class="flex flex-col gap-4 justify-center items-center">
        
  </div>
            
  <div class="flex flex-col gap-4 -mt-[6rem] justify-center items-center">

    <div class="flex justify-center items-center font-bold h-[140px] sm:h-[150px] sm:w-full w-[700px] font-Plus_Jakarta_Sans">
      <div class="self-start flex flex-col gap-4 w-4/5 mr-[150px]">
        <div class="relative flex flex-col ml-[111px] items-end">
          <div class="w-full w-full h-1 bg-[linear-gradient(98deg,_#ffd849_-8%,#ffc937_30%,#ffe88c_69%,#ffd546_125%)] bg-cover bg-50%_50% bg-blend-normal bg-no-repeat absolute top-5 left-5 rounded-[41px]"></div>
          <div class="w-10 h-10 bg-[linear-gradient(98deg,_#ffd849_-8%,#ffc937_30%,#ffe88c_69%,#ffd546_125%)] bg-cover bg-[50% 50%] bg-blend-normal bg-no-repeat absolute top-0 left-0 flex flex-col justify-center pl-4 items-start rounded-[76px] text-center font-bold text-[#222831]">1</div>
          <div class="bg-white bg-cover bg-50%_50% bg-blend-normal bg-no-repeat relative flex flex-col justify-center pl-4 w-10 h-10 shrink-0 items-start rounded-[76px] -mr-10 text-center font-bold text-[#222831]">
              2
          </div>
        </div>
        <div class="flex flex-row justify-between items-start">
          <div class="text-center ml-12">
            Metode Pembayaran
          </div>
          <div class="text-center -mr-[60px]">
            Ringkasan
          </div>
        </div>
      </div>
    </div>
    

    <!-- <div class="flex justify-center items-center font-bold h-[140px] sm:h-[150px] sm:w-full w-[700px] font-Plus_Jakarta_Sans border-2">

      <div class="self-start flex flex-col gap-4 w-4/5 mr-[150px]">
        <div class="relative flex flex-col ml-[111px] items-end">
          <div class="w-full w-full h-1 bg-[linear-gradient(98deg,_#ffd849_-8%,#ffc937_30%,#ffe88c_69%,#ffd546_125%)] bg-cover bg-50%_50% bg-blend-normal bg-no-repeat absolute top-5 left-5 rounded-[41px]"></div>
          <div class="w-10 h-10 bg-[#2f80ed] absolute top-0 left-0 flex flex-col justify-center items-center rounded-[76px] font-['Plus_Jakarta_Sans']">
            <img src="https://file.rendit.io/n/6H7qXwtGdFQNMZHum5g8.svg" alt="Check" id="Check" class="w-5"/>
          </div>
          <div class="bg-[linear-gradient(98deg,_#ffd849_-8%,#ffc937_30%,#ffe88c_69%,#ffd546_125%)] bg-cover bg-50%_50% bg-blend-normal bg-no-repeat relative flex flex-col justify-center pl-4 w-10 h-10 shrink-0 items-start rounded-[76px] -mr-10 text-center font-bold text-[#222831]">
              2
          </div>
        </div>
        <div class="flex flex-row justify-between items-start">
          <div class="text-center ml-12">
            Metode Pembayaran
          </div>
          <div class="text-center -mr-[60px]">
            Ringkasan
          </div>
        </div>
      </div>
      
    </div> -->
  
<div class="overflow-hidden sm:w-full w-[700px]">
  <div class="sm:mt-[20px]">
    <h3 class="text-[24px] sm:text-[16px] font-bold">Metode Pembayaran</h3>
  </div>
</div>
    

  <!-- Dompet-->
  <div class="sm:w-full w-[700px] font-Plus_Jakarta_Sans"> 
    <div class="border-solid dark:border-white/20 border-black-100 dark:bg-[#090909] flex flex-row gap-4 h-20 shrink-0 items-center px-4 border rounded-lg">
      <!-- <img src="~/public/icons/radiobtn.svg"/> -->
      <div class="nav">
        <button class="nav_burger" @click="openMenu" :class="{ 'active': isOpen }">
          <div class="burger-icon flex flex-col w-8 h-8 items-center py-1">
            <div v-if="!isOpen" class="w-[20px] h-[20px] border-[3px] dark:border-white border-black-100 rounded-full relative"></div>
            <div v-if="isOpen" class="w-[20px] h-[20px] border-[3px] dark:border-white border-black-100 rounded-full relative">
              <div class="dot"></div>
            </div>
          </div>
        </button>
      </div>
        <div class="border-solid dark:border-white/20 border-black-100 mr-1 w-px shrink-0 h-10 border-r border-l-0 border-y-0"/>
        <img src="~/public/icons/dompet.svg"/>
        <div class="flex flex-col items-start font-['Plus_Jakarta_Sans']">
        <div class="text-lg font-bold">Dompet</div>
        <div id="Rp" class="text-sm">Rp. -</div>
      </div>
    </div>
  </div>

   <!-- Kartu Kredit -->
   <div class="sm:w-full w-[700px] font-Plus_Jakarta_Sans"> 
    <div class="border-solid dark:border-white/20 border-black-100 dark:bg-[#090909] flex flex-row gap-4 h-16 shrink-0 items-center px-4 border rounded-lg">
        <button class="flex flex-col w-8 shrink-0 h-8 items-center py-1">
        <div class="w-[20px] h-[20px] border-[3px] dark:border-white border-black-100 rounded-full relative"></div>
        </button>
        <div class="border-solid dark:border-white/20 border-black-100 mr-1 w-px shrink-0 h-10 border-r border-l-0 border-y-0"/>
        <img src="~/public/icons/creadit.svg"/>
        <div class="flex flex-col items-start font-['Plus_Jakarta_Sans']">
        <div class="text-lg font-bold">Kartu Kredit</div>
      </div>
      <img src="~/public/icons/select.svg" class="ml-auto"/>
  </div>
</div>
  
   <!-- Virtual Akun -->
   <div class="sm:w-full w-[700px] font-Plus_Jakarta_Sans"> 
    <div class="border-solid dark:border-white/20 border-black-100 dark:bg-[#090909] flex flex-row gap-4 h-16 shrink-0 items-center px-4 border rounded-lg">
        <button class="flex flex-col w-8 shrink-0 h-8 items-center py-1">
        <div class="w-[20px] h-[20px] border-[3px] dark:border-white border-black-100 rounded-full relative"></div>
        </button>
        <div class="border-solid dark:border-white/20 border-black-100 mr-1 w-px shrink-0 h-10 border-r border-l-0 border-y-0"/>
        <img src="~/public/icons/va.svg"/>
        <div class="flex flex-col items-start font-['Plus_Jakarta_Sans']">
        <div class="text-lg font-bold">Virtual Akun</div>
      </div>
      <img src="~/public/icons/select.svg" class="ml-auto"/>
  </div>
</div>
  

   <!-- Button -->
      <div class="flex justify-center font-bold sm:w-full w-[700px] font-Plus_Jakarta_Sans">
        <div class="mt-5 flex gap-10 sm:gap-5">
          <button class="bg-transparent p-2 xl:p-4 rounded-lg text24 xl:text-base font-bold w-[329px] h-[60px] sm:w-[115px] sm:h-[40px]" style="display: flex; justify-content: center; align-items: center;">
            <NuxtLink to="/tiket/tiket">Kembali</NuxtLink>
          </button>
          
          <button class="bg-primary p-2 xl:p-4 rounded-lg text24 xl:text-base font-bold w-[329px] h-[60px] sm:w-[115px] sm:h-[40px] text-[#222831] text-center" style="display: flex; justify-content: center; align-items: center;">
            <NuxtLink to="/tiket/ringkasan">Selanjutnya</NuxtLink>
          </button>
          
        </div>
      </div>
  </div>
</section>
</main>

       
</template>

<script setup>
import { ref } from "vue";

let isOpen = ref(false);

const openMenu = () => {
  isOpen.value = !isOpen.value;
  console.log(isOpen.value);
};
</script>

<style>
  .bg-yellow-100 {
    background-color: #FFD700; 
  }
  .dot {
    width: 10px;
    height: 10px;
    background-color: rgb(246, 239, 239);
    border-radius: 50%;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    display: none;
  }
  
  .active .dot {
    display: block;
  }
</style>