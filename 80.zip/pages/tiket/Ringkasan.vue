<template>
<main class="px-60 2xl:px-48 xl:px-40 sm:px-4">
  <section class="mt-[32px] sm:mt-8 flex flex-col gap-32">
      <div class="flex flex-col gap-4 justify-center items-center">
        
  </div>
            
  <div class="flex flex-col gap-4 -mt-[6rem] justify-center items-center">

    <!-- <div class="flex justify-center items-center font-bold h-[140px] sm:h-[150px] sm:w-full w-[700px] font-Plus_Jakarta_Sans border-2">

      <div class="self-start flex flex-col gap-4 w-4/5 mr-[150px]">
        <div class="relative flex flex-col ml-[111px] items-end">
          <div class="w-full w-full h-1 bg-[linear-gradient(98deg,_#ffd849_-8%,#ffc937_30%,#ffe88c_69%,#ffd546_125%)] bg-cover bg-50%_50% bg-blend-normal bg-no-repeat absolute top-5 left-5 rounded-[41px]"></div>
          <div class="w-10 h-10 bg-[linear-gradient(98deg,_#ffd849_-8%,#ffc937_30%,#ffe88c_69%,#ffd546_125%)] bg-cover bg-[50% 50%] bg-blend-normal bg-no-repeat absolute top-0 left-0 flex flex-col justify-center pl-4 items-start rounded-[76px] text-center font-bold text-[#222831]">1</div>
          <div class="bg-white bg-cover bg-50%_50% bg-blend-normal bg-no-repeat relative flex flex-col justify-center pl-4 w-10 h-10 shrink-0 items-start rounded-[76px] -mr-10 text-center font-bold text-[#222831]">
              2
          </div>
        </div>
        <div class="flex flex-row justify-between items-start">
          <div class="text-center ml-12">
            Metode Pembayaran
          </div>
          <div class="text-center -mr-[60px]">
            Ringkasan
          </div>
        </div>
      </div>
      
    </div> -->
    

    <div class="flex justify-center items-center font-bold h-[140px] sm:h-[150px] sm:w-full w-[700px] font-Plus_Jakarta_Sans">

      <div class="self-start flex flex-col gap-4 w-4/5 mr-[150px]">
        <div class="relative flex flex-col ml-[111px] items-end">
          <div class="w-full w-full h-1 bg-[linear-gradient(98deg,_#ffd849_-8%,#ffc937_30%,#ffe88c_69%,#ffd546_125%)] bg-cover bg-50%_50% bg-blend-normal bg-no-repeat absolute top-5 left-5 rounded-[41px]"></div>
          <div class="w-10 h-10 bg-[#2f80ed] absolute top-0 left-0 flex flex-col justify-center items-center rounded-[76px] font-['Plus_Jakarta_Sans']">
            <img src="https://file.rendit.io/n/6H7qXwtGdFQNMZHum5g8.svg" alt="Check" id="Check" class="w-5"/>
          </div>
          <div class="bg-[linear-gradient(98deg,_#ffd849_-8%,#ffc937_30%,#ffe88c_69%,#ffd546_125%)] bg-cover bg-50%_50% bg-blend-normal bg-no-repeat relative flex flex-col justify-center pl-4 w-10 h-10 shrink-0 items-start rounded-[76px] -mr-10 text-center font-bold text-[#222831]">
              2
          </div>
        </div>
        <div class="flex flex-row justify-between items-start">
          <div class="text-center ml-12">
            Metode Pembayaran
          </div>
          <div class="text-center -mr-[60px]">
            Ringkasan
          </div>
        </div>
      </div>
      
    </div>
  
<div class="overflow-hidden sm:w-full w-[700px]">
  <div class="sm:mt-[20px]">
    <h3 class="text-[24px] sm:text-[16px] font-bold">Ringkasan</h3>
  </div>
</div>
    

  <!-- Metode Pembayaran -->
  <div class="sm:w-full w-[700px] font-Plus_Jakarta_Sans">
    <div class="inline-block text-start font-bold">
      Metode Pembayaran
    </div>
  </div>

  <div class="bg-white rounded-lg shadow-32 overflow-hidden h-20 sm:h-20 sm:w-full w-[700px] font-Plus_Jakarta_Sans"> 
      <div class="flex flex-row gap-5 h-20 items-center px-5 rounded-lg">
        <img class="bg-dark-100" src="~/public/icons/dompet.svg"/>
        <div class="flex flex-col items-start">
          <div class="text-lg font-['Plus_Jakarta_Sans'] font-bold text-[#222831]">
            Dompet
          </div>
          <div class="text-lg font-['Plus_Jakarta_Sans'] text-[#222831]">
            Rp. 0
          </div>
        </div>
      </div>
    </div>
 
   <!-- Jumlah Deposit -->
   <div class="sm:w-full w-[700px] font-Plus_Jakarta_Sans">
    <div class="inline-block text-start font-bold">
      Jumlah Deposit
    </div>
    </div>
    <div class="bg-white rounded-lg shadow-32 overflow-hidden h-20 sm:h-20 sm:w-full w-[700px] font-Plus_Jakarta_Sans"> 
        <div class="flex flex-row gap-5 h-20 items-center px-5 rounded-lg">
          <img class="bg-dark-100" src="~/public/icons/dompet.svg"/>
          <div class="flex flex-col items-start font-bold ">
            <div class="text-lg font-['Plus_Jakarta_Sans'] text-[#222831] text-green-100">
              Rp. 0
            </div>
          </div>
        </div>
      </div>

   <!-- Ringkasan pembayaran -->
   <div class="sm:w-full w-[700px] font-Plus_Jakarta_Sans">
    <div class="inline-block text-start font-bold">
      Ringkasan Pembayaran
    </div>
  </div>
  
  <div class="bg-white rounded-lg shadow-32 overflow-hidden h-30 sm:h-30 sm:w-full w-[700px] font-Plus_Jakarta_Sans"> 
    <div class="flex flex-row justify-between items-center pl-4 pr-[337px]">
      <div class="flex flex-col justify-between w-26 shrink-0 h-26 items-start my-4 font-['Plus_Jakarta_Sans'] text-[rgba(34,_40,_49,_0.5)]">
        <div>Subtotal</div>
        <div>Pengiriman</div>
        <div>Total Dibayar</div>
      </div>
      <div class="flex flex-col justify-between h-26 text-right font-['Plus_Jakarta_Sans'] font-semibold text-[#222831]">
        <div>Rp. 0</div>
        <div>Rp. 0</div>
        <div class="text-[#379956]">Rp. 0</div>
      </div>  
    </div>
  </div>
  

   <!-- Button -->
      <div class="flex justify-center font-bold sm:w-full w-[700px] font-Plus_Jakarta_Sans">
        <div class="mt-5 flex gap-10 sm:gap-5">
          <button class="bg-transparent p-2 xl:p-4 rounded-lg text24 xl:text-base font-bold w-[329px] h-[60px] sm:w-[115px] sm:h-[40px]" style="display: flex; justify-content: center; align-items: center;">
            <NuxtLink class="" to="/tiket/metodepembayaran">Kembali</NuxtLink>
          </button>
          
          <button class="bg-primary p-2 xl:p-4 rounded-lg text24 xl:text-base font-bold w-[329px] h-[60px] sm:w-[115px] sm:h-[40px] text-[#222831] text-center" style="display: flex; justify-content: center; align-items: center;">
            <NuxtLink to="/tiket/PembayaranBerhasil">Bayar</NuxtLink>
          </button>
          
        </div>
      </div>
  </div>
</section>
</main>
  
</template>

<style>
</style>

<!-- <script setup>
import { ref, onMounted } from 'vue';
import axios from 'axios';
const route = useRoute();
const ticket = ref({});

const fetchTickets = async () => {
  try {
    let config = {
      method: 'get',
      maxBodyLength: Infinity,
      url: 'https://65558d7284b36e3a431de9a5.mockapi.io/tiket/'+route.params.id,
      headers: { 
      }
    };
    const response = await axios.request(config)
    .then((response) => {
      console.log(response.data)   
      ticket.value = response.data;
    })
    .catch((error) => {
      console.log(error);
    });

  } catch (error) {
    console.error('Error fetching tickets:', error);
  }
};

onMounted(fetchTickets);
</script> -->