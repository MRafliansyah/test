<template>
    
      

      
      <div class="max-w-md mx-auto bg-darkGrey-100 rounded-xl shadow-md overflow-hidden md:max-w-[420px] h-[600px]">
        <div class="md:flex">
            <div class="text-center text-3xl font-['Plus_Jakarta_Sans'] font-bold text-white mx-auto py-10">
                PEMBAYARAN BERHASIL
            <div class="mt-14 md:overflow-hidden bg-[#379956] flex flex-col md:justify-center w-[150px] h-[150px] mx-auto rounded-[100px]">
              <img class="h-[70px] mt-[34px]" src="~/public/icons/vector.svg"/>
            </div>
        </div>
      </div>
    

    <div class="text-2xl font-['Plus_Jakarta_Sans'] font-bold text-white px-6 mt-4">
        Detail Transaksi
    </div>
      <div class="font-['Plus_Jakarta_Sans'] text-white px-6 mt-4">  
            <div class="text-[20px] mb-1">
                 Nominal Pembayaran
            </div>
            <div class="text-xl mb-1">
                 Tanggal
            </div>
            <div class="text-xl">
                  Waktu
            </div>
          </div> 
          <div class="text-xl font-['Plus_Jakarta_Sans'] text-white text-end -mt-[84px] px-6">
                <div>Rp 2.000.000</div>
                <div>20 Desember 2023</div>
                <div>09.00</div>
          </div>
                <div class="mt-10 flex gap-10 justify-center mt-6">
                  <button class="bg-gold-100 text24 w-[410px] text-black-100 font-bold h-[62px] rounded-lg">
                      <NuxtLink to="/">Beranda</NuxtLink>
                  </button>
                </div>
            </div>    
</template>

<script>
</script>