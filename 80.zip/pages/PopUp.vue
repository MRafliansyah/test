<!-- <template>
  <div class="nav">
    <button class="nav_burger" @click="openMenu" :class="{ 'active': isOpen }">
      <div class="burger-icon flex flex-col w-8 h-8 items-center py-1">
        <div v-if="!isOpen" class="w-[20px] h-[20px] border-[3px] dark:border-white border-black-100 rounded-full relative"></div>
        <div v-if="isOpen" class="w-[20px] h-[20px] border-[3px] dark:border-white border-black-100 rounded-full relative">
          <div class="dot"></div>
        </div>
      </div>
    </button>
  </div>
</template>

<script setup>
import { ref } from "vue";

let isOpen = ref(false);

const openMenu = () => {
  isOpen.value = !isOpen.value;
  console.log(isOpen.value);
};
</script>

<style>
.dot {
  width: 10px;
  height: 10px;
  background-color: rgb(246, 239, 239);
  border-radius: 50%;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  display: none;
}

.active .dot {
  display: block;
}
</style> -->


<template>

  <div>
    <button @click="changeTab(1)" :class="{ active: activeTab === 1 }">Tab 1</button>
    <button @click="changeTab(2)" :class="{ active: activeTab === 2 }">Tab 2</button>

    <div v-if="activeTab === 1">Content for Tab 1</div>
  
    <div v-if="activeTab === 2">Content for Tab 2</div>
  </div>



  <div class="Bid">
    <ModalsOverlay>
      <div class="dark:bg-darkGrey-100 bg-white w-10px h-8px rounded-lg flex flex-col gap-32 ml-4" style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 16px;">
        <div class="h-[449px] w-[400px] sm:h-[337px] sm:w-[280px]">
          <h2 class="font-bold py-4 px-6 text-2xl sm:text-lg">Selamat Bergabung!</h2>
          <div class="flex items-center justify-center mt-[30px] sm:mt-[13px]">
            <img class="sm:w-[150px] w-[185px]" src="~/public/icons/undraw.svg" alt="Gambar" />
          </div>
          <p class="sm:mt-[1px] mt-[18px] px-6 text-[16px] sm:text-[12px]">
            Selamat, anda sudah membuat akun baru. Happy bidding :)
          </p>
          <div class="flex mt-[26px] sm:mt-[1rem] gap-2 justify-center">
              <button class="btn-confirm bg-primary p-2 xl:p-4 font-bold rounded-lg text-sm xl:text-base dark:text-dark-100 w-[350px] h-[44px] sm:w-[230px] sm:h-[30px] text-[16px] sm:text-[12px]" style="font-family: 'Plus Jakarta Sans', sans-serif; transition: background-color 0.3s; display: flex; align-items: center; justify-content: center;">
                OK
              </button>
          </div>
        </div>
      </div>
    </ModalsOverlay>
    </div>


</template>

<script setup>
import { ref } from 'vue';

const activeTab = ref(1);

const changeTab = (tabNumber) => {
  activeTab.value = tabNumber;
};
</script>

<style>
.active {
  font-weight: bold;
 
  color: blue;
}
</style>


