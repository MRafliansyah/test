<template>
  <div class="w-full h-max flex justify-between fixed-content-width">
    <div><Sidebar/></div>
    
   <!-- <div class="flex flex-row justify-between w-full items-center py-9 px-6">
      <div class="self-start flex flex-col items-start">
        <div class="text-3xl font-Plus_Jakarta_Sans font-semibold">
          Mitra
        </div>
        <div class="font-Plus_Jakarta_Sans text-inherit-50">
          Tempat dimana anda dapat melakukan verifikasi mitra yang mendaftar.
        </div>
      </div> -->
  
      <!-- Search -->
      <!-- <div class="flex flex-row items-center gap-8 -mt-[59rem] -ml-10">
        <div class="border-solid border-white/20 bg-[#242424] flex flex-row gap-4 w-[413px] shrink-0 h-12 items-center px-4 border rounded-lg">
          <img src="~/public/icons/search.svg" class="w-6 h-6" alt="Search Icon" />
          <input
            type="text"
            id="Cari"
            class="font-Plus_Jakarta_Sans text-white/50 bg-transparent border-none outline-none"
            placeholder="Cari"
          />
        </div> -->
  
        <!-- Notifikasi -->
        <!-- <div class="border-solid border-white/20 bg-[#242424] flex flex-col justify-center w-12 shrink-0 h-12 items-center border rounded-lg">
          <img src="~/public/icons/notifications.svg"/>
        </div>
      </div>
    </div> -->
    
    <div class="flex flex-row justify-between w-full items-center ml-5 mt-7">
      <div class="self-start flex flex-col items-start">
        <div class="text-3xl font-Plus_Jakarta_Sans font-semibold">
          Mitra
        </div>
        <div class="font-Plus_Jakarta_Sans text-inherit-50">
          Tempat dimana anda dapat melakukan verifikasi mitra yang mendaftar.
        </div>
      </div>
  
      <!-- Search -->
      <div class="flex flex-row items-center gap-4 -mt-[985px] -mr-[287px]">
        <div class="border-solid border-white/20 bg-[#242424] flex flex-row gap-4 w-[413px] shrink-0 h-12 items-center px-4 border rounded-lg">
          <img src="~/public/icons/search.svg" class="w-6 h-6" alt="Search Icon" />
          <input
            type="text"
            id="Cari"
            class="font-Plus_Jakarta_Sans text-white/50 bg-transparent border-none outline-none"
            placeholder="Cari"
          />
        </div>
  
        <!-- Notifikasi -->
        <div class="border-solid border-white/20 bg-[#242424] flex flex-col justify-center w-12 shrink-0 h-12 items-center border rounded-lg">
          <img src="~/public/icons/notifications.svg"/>
        </div>
      </div>  
    </div>

  </div>
  
  <!-- Kotak-->
<div class="flex -mt-[60rem] ml-[18rem]">
  <div class="w-984 h-496 rounded-lg" style="display: flex; width: 1207px; height: 596px; padding: 24px; flex-direction: column; align-items: flex-start; gap: 24px; flex-shrink: 0; background: var(--Dark-Grey-100, #242424);">
    <h2 style="color: var(--White-100, #FFF); font-family: 'Plus Jakarta Sans'; font-size: 24px; font-style: normal; font-weight: 600; line-height: normal;">Semua Permintaan Mitra Baru</h2>

    <div class="flex flex-row justify-end gap-6 items-center">
      <div class="flex flex-row gap-2 w-16 shrink-0 items-start">
        <div class="font-Plus_Jakarta_Sans text-white">Filter</div>
        <img src="~/public/icons/filteralt.svg"/>
      </div>
      <div class="border-solid border-white/20 bg-[#242424] self-start flex flex-row justify-center gap-24 w-56 h-8 items-center border rounded-lg">
        <div class="font-Plus_Jakarta_Sans text-white/50">
          <input
            type="text"
            id="Cari"
            class="font-Plus_Jakarta_Sans text-white/50 bg-transparent border-none outline-none"
            placeholder="Cari Nama"/>
        </div>
        <img class="w-20px h-20px -ml-24" src="~/public/icons/search.svg"/>
      </div>
    </div>
  </div>
</div>
</template>

<script setup></script>

<style scoped>
.fixed-content-width {
  width: 1209px;
}
</style>
