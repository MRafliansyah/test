<!-- <template>
  <div class="max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
    <div class="flex flex-col md:flex-row gap-4 items-center">
      <img src="~/public/img/user3.png" id="Ellipse" class="self-start w-40 md:w-1/4 lg:w-1/4 xl:w-1/4" />
      <div class="flex flex-col gap-2 w-full md:w-3/4 lg:w-3/4 xl:w-3/4 md:justify-center"> 
        <div class="text-4xl font-['Plus_Jakarta_Sans'] font-semibold">
          Asep Saepudin
        </div>
        <div class="text-2xl font-['Plus_Jakarta_Sans'] font-semibold text-inherit-50">
          User
        </div>
      </div>
    </div>

    <div class="mt-4 flex justify-start">
      <button class="bg-primary text-black-100 border rounded-lg w-40 h-10 mr-2">Hapus Foto</button>
      <button class="bg-primary text-black-100 border rounded-lg w-40 h-10">Ganti Foto</button>
    </div>

    <div class="flex flex-col gap-6 mt-4">
      <div class="relative h-11 w-1/2 md:w-full">
        <input class="peer h-full w-full border-b border-white/50 bg-transparent pt-3 pb-1.5 font-sans text-basefont-normal outline outline-0 transition-all disabled:border-0 "
          placeholder=" " />
        <label class="after:content[' '] pointer-events-none absolute left-0 -top-1.5 flex select-none after:absolute peer-placeholder-shown:text-lg peer-placeholder-shown:leading-[4.25] peer-focus:text-[16px] peer-focus:leading-tight text-inherit-50 ">
          Ubah Nama Pengguna
        </label>
      </div>

      <div class="relative h-11 w-1/2 md:w-full"> 
        <input class="peer h-full w-full border-b border-white/50 bg-transparent pt-3 pb-1.5 font-sans text-basefont-normal outline outline-0 transition-all disabled:border-0 "
          placeholder=" " />
        <label class="after:content[' '] pointer-events-none absolute left-0 -top-1.5 flex select-none after:absolute peer-placeholder-shown:text-lg peer-placeholder-shown:leading-[4.25] peer-focus:text-[16px] peer-focus:leading-tight text-inherit-50 ">
          Ubah email
        </label>
      </div>

      <div class="relative h-11 w-1/2 md:w-full"> 
        <input class="peer h-full w-full border-b border-white/50 bg-transparent pt-3 pb-1.5 font-sans text-basefont-normal outline outline-0 transition-all disabled:border-0 "
          placeholder=" " />
        <label class="after:content[' '] pointer-events-none absolute left-0 -top-1.5 flex select-none after:absolute peer-placeholder-shown:text-lg peer-placeholder-shown:leading-[4.25] peer-focus:text-[16px] peer-focus:leading-tight text-inherit-50 ">
          Informasi Akun
        </label>
      </div>
    </div>

    <div class="mt-7 flex justify-end">
      <button class="bg-primary text-black-100 border rounded-lg w-40 h-10">Simpan</button>
    </div>
  </div>
</template> -->


<template>
  <div class="max-w-screen-xl mx-auto px-4 sm:px-6 lg:px-8 py-">
    <div class="flex flex-col md:flex-row gap-4 items-center"> <!-- Tambahkan kelas items-center -->
      <img src="~/public/img/user3.png" id="Ellipse" class="self-start w-40 md:w-1/4 lg:w-1/4 xl:w-1/4 mx-auto" /> <!-- Hapus kelas text-center -->
      <div class="flex flex-col gap-2 w-full md:w-3/4 lg:w-3/4 xl:w-3/4 text-center md:text-start"> <!-- Tambahkan kelas text-start pada tampilan md -->
        <div class="text-4xl font-['Plus_Jakarta_Sans'] font-semibold">
          Asep Saepudin
        </div>
        <div class="text-2xl font-['Plus_Jakarta_Sans'] font-semibold text-inherit-50">
          User
        </div>
      </div>
    </div>
    
    <div class="mt-4 flex justify-center"> <!-- Menggunakan kelas justify-center untuk tombol -->
      <button class="bg- text-white-100 border rounded-lg w-40 h-10 mr-2">Hapus Foto</button>
      <button class="bg-primary text-black-100 border rounded-lg w-40 h-10">Ganti Foto</button>
    </div>
  
    <div class="flex flex-col gap-6 mt-4">
      <div class="relative h-11 w-1/2 md:w-full mx-auto">
        <input class="peer h-full w-full border-b border-white/50 bg-transparent pt-3 pb-1.5 font-sans text-basefont-normal outline outline-0 transition-all disabled:border-0 "
          placeholder=" " />
        <label class="after:content[' '] pointer-events-none absolute left-0 -top-1.5 flex select-none after:absolute peer-placeholder-shown:text-lg peer-placeholder-shown:leading-[4.25] peer-focus:text-[16px] peer-focus:leading-tight text-inherit-50 ">
          Ubah Nama Pengguna
        </label>
      </div>
      
      <div class="relative h-11 w-1/2 md:w-full mx-auto">
        <input class="peer h-full w-full border-b border-white/50 bg-transparent pt-3 pb-1.5 font-sans text-basefont-normal outline outline-0 transition-all disabled:border-0 "
          placeholder=" " />
        <label class="after:content[' '] pointer-events-none absolute left-0 -top-1.5 flex select-none after:absolute peer-placeholder-shown:text-lg peer-placeholder-shown:leading-[4.25] peer-focus:text-[16px] peer-focus:leading-tight text-inherit-50 ">
          Ubah Email
        </label>
      </div>
      
      <div class="relative h-11 w-1/2 md:w-full mx-auto">
        <input class="peer h-full w-full border-b border-white/50 bg-transparent pt-3 pb-1.5 font-sans text-basefont-normal outline outline-0 transition-all disabled:border-0 "
          placeholder=" " />
        <label class="after:content[' '] pointer-events-none absolute left-0 -top-1.5 flex select-none after:absolute peer-placeholder-shown:text-lg peer-placeholder-shown:leading-[4.25] peer-focus:text-[16px] peer-focus:leading-tight text-inherit-50 ">
          Informasi Akun
        </label>
      </div>
      <div class="mt-7 md:flex md:justify-end">
        <button class="bg-primary text-black-100 border rounded-lg w-40 h-10 ml-[64%] lg:ml-[53%]">Simpan</button>
      </div>
    </div>
  </div>
</template>
