<template>
<main class="px-60 2xl:px-48 xl:px-40 sm:px-4">
  <section class="xl:mt-24 sm:mt-8 flex flex-col gap-32 justify-center items-center">
  
    <div class="flex-col sm:w-full 2xl:w-[718px] w-full">
      <div class="flex gap-4 font-medium text-16 sm:text-xs">
        <a href="/" class="text-inherit-50 cursor-pointer">Beranda</a>
        <p class="text-inherit-50 cursor-default">/</p>
        <p class="text-yellow-100 cursor-pointer">Buat Tiket Konser</p>
      </div>
      <div class="mt-[32px]">
        <h3 style="font-family: 'Plus Jakarta Sans'; font-weight: bold; font-size: 25px">Buat Tiket Konser Baru</h3>
        <p class="mt-1 font-normal font-size: 16px sm:text-sm">Isi semua form yang tersedia di bawah.</p>
      </div>
    </div>
    
  <!-- Informasi Umum konser -->
  <div class="flex shadow-32 dark:bg-[#242424] flex-col p-8 rounded-lg sm:w-full 2xl:w-[718px] w-full -mt-[100px]">
    <div class="flex flex-col justify-center gap-8">
      <div class="text-lg sm:text-xl md:text-2xl lg:text-3xl 2xl:text-3xl font-bold self-start mb-4">
        Informasi Umum Konser
      </div>
      <div class="flex flex-row gap-2 items-start -mt-10">
        <div class="text-lg sm:text-sm mt-4">Nama Konser</div>
        <div class="bg-[rgba(205,_71,_92,_0.2)] flex flex-col sm:w-16 w-20 shrink-0 sm:h-4 items-center sm:py-0 py-1 mt-5">
          <div class="text-xs text-[#cd475c]">Wajib Diisi!</div>
        </div>
      </div>
      <div class="border-solid dark:border-white/20 dark:bg-[#090909] self-stretch flex flex-col justify-center pl-4 h-12 shrink-0 items-start border rounded-lg -mt-4">
        <input type="text" placeholder="Contoh:Konser UNGU Senayan City Jakarta" class="text-lg sm:text-sm bg-transparent border-none outline-none w-full text-inherit-50"/>
      </div>
      <div class="text-xs text-inherit-50 -mt-4">*Nama produk akan ditampilkan pada thumbnail dan judul besar lelang, pastikan nama lelang berisi elemen nama barang dan nama pemilik barang.</div>
    </div>
  </div>
  
  <!-- Detail Konser -->
  <div class="flex shadow-32 dark:bg-[#242424] font-['Plus_Jakarta_Sans'] flex-col p-8 rounded-lg -mt-[100px] sm:w-full 2xl:w-[718px] w-full">
    <div class="text-2xl font-bold self-start ">Detail Konser</div>
    <div class="flex flex-col justify-between gap-4 items-start">
      <div class="flex flex-row gap-2 w-full sm:w-auto items-start mt-6">
        <div class="text-lg sm:text-sm mt-2">Foto Ilustrasi Konser</div>
          <div class="bg-[rgba(205,_71,_92,_0.2)] flex flex-col sm:w-16 w-20 shrink-0 sm:h-4 items-center sm:py-0 py-1 mt-3">
          <div class="text-xs text-[#cd475c]">Wajib Diisi!</div>
        </div>
      </div>
      <!--foto-->
      <div class="self-stretch flex flex-row justify-between items-start">
     <!-- File Input 1 -->
      <label for="file-input-1" class="border-dashed border-white/20 bg-[#090909] flex flex-col justify-center items-center gap-2 sm:gap-4 md:gap-6 lg:gap-8 sm:w-[80px] sm:h-[87px] w-[172px] h-[196px] border-2 rounded-lg" style="position: relative;">
        <input type="file" style="display: none" />
        <div class="text-center sm:text-xs text-md font-semibold text-white">
          <div class="sm:text-[10px]" style="display: flex; flex-direction: column; justify-content: center; align-items: center; height: 100%;">
            <img class="mt-12 sm:mt-5 sm:w-6" src="~/public/icons/addphoto.svg" alt="Add Photo" />
            <div class="mt-4 sm:mt-1">Photo/</div>
            <div style="display: flex; align-items: center; justify-content: center; height: 100%;">Video</div>
          </div>
        </div>
        <div class="border-tr" style="height: 100%; width: 100%; display: flex; align-items: center; justify-content: center;">
        </div>
      </label>
      
      <!-- File Input 2 -->
      <label for="file-input-2" class="border-dashed border-white/20 bg-[#090909] flex flex-col justify-center items-center gap-2 sm:gap-4 md:gap-6 lg:gap-8 sm:w-[80px] sm:h-[87px] w-[172px] h-[196px] border-2 rounded-lg" style="position: relative;">
          <input type="file" id="file-input-2" style="display: none" />
          <div class="text-center sm:text-xs text-md font-semibold text-white">
            <div class="sm:text-[10px]" style="display: flex; flex-direction: column; justify-content: center; align-items: center; height: 100%;">
              <img class="mt-12 sm:mt-5 sm:w-6" src="~/public/icons/addphoto.svg" alt="Add Photo"/>
              <div class="mt-4 sm:mt-1">Photo/</div>
              <div style="display: flex; align-items: center; justify-content: center; height: 100%;">Video</div>
            </div>
          </div>
          <div class="border-tr" style="height: 100%; width: 100%; display: flex; align-items: center; justify-content: center;">
            <img class="rounded-lg" style="width: auto; max-width: 100%; max-height: 100%;" />
          </div>
        </label>  

       <!-- File Input 3 -->
       <label for="file-input-3" class="border-dashed border-white/20 bg-[#090909] flex flex-col justify-center items-center gap-2 sm:gap-4 md:gap-6 lg:gap-8 sm:w-[80px] sm:h-[87px] w-[172px] h-[196px] border-2 rounded-lg" style="position: relative;">
        <input type="file" id="file-input-3" style="display: none" />
        <div class="text-center sm:text-xs text-md font-semibold text-white">
          <div class="sm:text-[10px]" style="display: flex; flex-direction: column; justify-content: center; align-items: center; height: 100%;">
            <img class="mt-12 sm:mt-5 sm:w-6" src="~/public/icons/addphoto.svg" alt="Add Photo"/>
            <div class="mt-4 sm:mt-1">Photo/</div>
            <div style="display: flex; align-items: center; justify-content: center; height: 100%;">Video</div>
          </div>
        </div>
        <div class="border-tr" style="height: 100%; width: 100%; display: flex; align-items: center; justify-content: center;">
         
          
        </div>
      </label> 
  
      <!-- File Input 4 -->
      <label for="file-input-4" class="border-dashed border-white/20 bg-[#090909] flex flex-col justify-center items-center gap-2 sm:gap-4 md:gap-6 lg:gap-8 sm:w-[80px] sm:h-[87px] w-[172px] h-[196px] border-2 rounded-lg" style="position: relative;">
        <input type="file" id="file-input-4" style="display: none" />
        <div class="text-center sm:text-xs text-md font-semibold text-white">
          <div class="sm:text-[10px]" style="display: flex; flex-direction: column; justify-content: center; align-items: center; height: 100%;">
            <img class="mt-12 sm:mt-5 sm:w-6" src="~/public/icons/addphoto.svg" alt="Add Photo"/>
            <div class="mt-4 sm:mt-1">Photo/</div>
            <div style="display: flex; align-items: center; justify-content: center; height: 100%;">Video</div>
          </div>
        </div>
        <div class="border-tr" style="height: 100%; width: 100%; display: flex; align-items: center; justify-content: center;">
          
          <img class="rounded-lg" style="width: auto; max-width: 100%; max-height: 100%;"/>
        </div>
      </label> 
      </div>
  
      <div class="text-xs text-inherit-50 w-full">
        *Pastikan Anda mengunggah foto pemilik lelang pada bagian Photo Thumbnail agar terlihat pada halaman awal. Anda dapat mengunggah foto atau video untuk menarik perhatian.
      </div>
      <div class="text-xs text-inherit-50">
        *Anda dapat menekan tombol di atas atau menarik gambar/video ke kolom di atas.
      </div>
    </div>
  
    <div class="flex flex-col justify-between gap-4 items-start">
      <div class="flex flex-row gap-2 w-full sm:w-auto items-start">
        <div class="text-lg sm:text-sm mt-4">Cerita Barang</div>
          <div class="bg-[rgba(205,_71,_92,_0.2)] flex flex-col sm:w-16 w-20 shrink-0 sm:h-4 items-center sm:py-0 py-1 mt-5">
            <div class="text-xs text-[#cd475c]">Wajib Diisi!</div>
          </div>
        </div>
      
        <div class="border-solid border-white/20 bg-[#090909] self-stretch flex flex-col h-[335px] shrink-0 items-start pl-4 py-4 border rounded-lg">
          <input type="text" placeholder="Contoh: Saya mendapatkan barang ini dengan kerja keras." class="text-lg sm:text-sm bg-transparent border-none outline-none w-full" style="max-width: 100%; word-wrap: break-word;" />  
        </div>
        
        <div class="text-xs text-inherit-50">
        *Pastikan cerita yang dimasukkan adalah cerita yang memuat tentang barang yang akan di lelang.
      </div>
    </div>
  </div>
  
  <!-- Harga Tiket Konser -->
  <div class="flex shadow-32 dark:bg-[#242424] flex-col p-8 rounded-lg sm:w-full 2xl:w-[718px] w-full -mt-[100px] font-['Plus_Jakarta_Sans']">
    <div class="text-2xl font-bold">Harga Tiket Konser</div>
    <div class="self-stretch flex flex-col justify-between gap-4 mt-3">
      
    
      <div class="flex items-center">
        <div class="text-lg sm:text-sm">Harga online</div>
        <div class="bg-[rgba(205,71,92,0.2)] flex flex-col sm:w-16 w-20 shrink-0 sm:h-4 items-center sm:py-0 py-1 mt-1 ml-2">
          <div class="text-xs text-[#cd475c]">Wajib Diisi!</div>
        </div>
      </div>
      
      <div class="border-solid border-white/20 bg-[#090909] flex flex-col justify-center pl-4 h-12 items-start border rounded-lg">
        <div class="text-lg text-white">Rp |
          <span class="text-white/50 hidden sm:inline ml-2 w-[240px]">
            <input class="bg-transparent border-none outline-none sm:w-7" type="text" placeholder="00"  />
          </span>
        
          <span class="text-white/50 sm:hidden ml-2">
            <input class="bg-transparent border-none outline-none w-[580px]" type="text" placeholder="Masukkan Harga" />
          </span>
        </div>
      </div>

      <div class="text-xs text-inherit-50">
        *Harga online adalah harga yang dijual di platform online yang hanya bisa dibeli di website resmi HistoryOutlet atau aplikasi mobile resmi.
      </div>
  
      <div class="flex items-center">
        <div class="text-lg sm:text-sm">Harga OTS</div>
        <div class="bg-[rgba(205,71,92,0.2)] flex flex-col sm:w-16 w-20 shrink-0 sm:h-4 items-center sm:py-0 py-1 mt-1 ml-2">
          <div class="text-xs text-[#cd475c]">Wajib Diisi!</div>
        </div>
      </div>
      
    <div class="border-solid border-white/20 bg-[#090909] flex flex-col justify-center pl-4 h-12 items-start border rounded-lg">
      <div class="text-lg text-white">Rp |
        <span class="text-inherit-50 hidden sm:inline ml-2 w-[240px]">
          <input class="bg-transparent border-none outline-none sm:w-7" type="text" placeholder="00" />
        </span>
      
        <span class="text-inherit-50 sm:hidden ml-2">
          <input class="bg-transparent border-none outline-none w-[580px]" type="text" placeholder="Masukkan Harga" />
        </span>
      </div>
    </div>
      <div class="text-xs text-inherit-50">
        *Harga OTS adalah harga On The Spot yang dijual di stand secara offline. Tiket OTS tidak bisa dibeli di platform online seperti website dan mobile.
      </div>
    </div>
  </div>
  
  <!-- Masa Akhir Lelang -->
  <div class="flex shadow-32 dark:bg-[#242424] flex-col p-8 rounded-lg sm:w-full 2xl:w-[718px] w-full -mt-[100px] font-['Plus_Jakarta_Sans']">
    <div class="text-2xl font-bold">Masa Akhir Pembelian  Tiket</div>
    <div class="self-stretch flex flex-col justify-between gap-4 mt-3">
      <div class="flex flex-row gap-8 items-start">
        <div class="text-xs w-1/2">
          <div class="flex flex-row gap-2">
            <div class="text-lg sm:text-sm">Tanggal</div>
            <div class="bg-[rgba(205,_71,_92,_0.2)] flex flex-col sm:w-16 w-20 shrink-0 sm:h-4 items-center sm:py-0 py-1 mt-1">
              <div class="text-xs text-[#cd475c]">Wajib Diisi!</div>
            </div>
          </div>
        </div>
        <div class="flex flex-row gap-2 w-1/2">
          <div class="text-lg sm:text-sm ml-2">Waktu</div>
          <div class="bg-[rgba(205,_71,_92,_0.2)] flex flex-col sm:w-16 w-20 shrink-0 sm:h-4 items-center sm:py-0 py-1 mt-1">
            <div class="text-xs text-[#cd475c]">Wajib Diisi!</div>
          </div>  
        </div>
      </div>
  
      <div class="flex flex-row gap-8 items-start text-lg sm:text-sm text-inherit-50">
  
        <div class="border-solid border-white/20 bg-[#090909] flex flex-col justify-center pl-4 w-1/2 h-12 items-start border rounded-lg">
          <!-- <input type="text" placeholder="Datepicker" class="text-lg sm:text-sm bg-transparent border-none outline-none w-full" /> -->
          <vue-date-picker v-model="date" :enableTimePicker="false"/>
        </div>
  
        <div class="border-solid border-white/20 bg-[#090909] flex flex-col justify-center pl-4 w-1/2 h-12 items-start border rounded-lg">
          <!-- <input type="text" placeholder="Timepicker" class="text-lg sm:text-sm bg-transparent border-none outline-none w-full" /> -->
          <vue-date-picker v-model="time" time-picker/>
        </div>
  
      </div>
      <div class="flex flex-row gap-8 items-start">
        <div class="text-xs text-inherit-50 w-1/2">
          *Waktu hitung mundur akan dihitung berdasarkan tanggal dan waktu yang ditentukan.
        </div>
        <div class="text-xs text-inherit-50 w-1/2">
          *Waktu hitung mundur akan dihitung berdasarkan tanggal dan waktu yang ditentukan.
        </div>
      </div>
    </div>
  </div>
  
  <!-- CSR -->
  <div class="flex shadow-32 dark:bg-[#242424] flex-col p-8 rounded-lg sm:w-full 2xl:w-[718px] -mt-[100px] w-full ">
  <div class=" flex flex-col justify-center gap-8">
    <div class="flex flex-row justify-between items-start">
      <div class="text-2xl font-['Plus_Jakarta_Sans'] font-bold">
        CSR (<span class="contents">Corporate Social Responsibility</span>
        <span class="contents">)</span>
      </div>
      <img src="~/public/icons/info.svg" @click="showBtk3" />
    </div>
    <div class="flex flex-col justify-between gap-4 items-start">
      <div class="flex flex-col gap-4 items-start py-4 -mt-6">
        <div class="flex flex-row gap-2 items-start">
          <div class="text-lg sm:text-sm">Pilih CSR Yang Diinginkan</div>
          <div class="bg-[rgba(205,_71,_92,_0.2)] flex flex-col sm:w-16 w-20 shrink-0 sm:h-4 items-center sm:py-0 py-1 mt-1">
          <div class="text-xs text-[#cd475c]">Wajib Diisi!</div>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <!--Pilih csr-->
  <div class="flex flex-col relative">
  <div @click="toggleRotation('animated-image2')" style="position: relative;">
    <div class="border-2 dark:border-white/20 rounded-lg dark:bg-[#090909] bg-white absolute w-full">
      <div class="px-4">
        <div @click="toggleCSRSearch" style="position: relative;">
          <button class="block h-12 w-48 focus:outline-none focus:border-white flex items-center" style="overflow: hidden; white-space: nowrap;">
            <div class="text-inherit-50 sm:text-sm text-lg font-['Plus_Jakarta_Sans']">{{ selectedCSR || "Pilih CSR" }}</div>
          </button>
        </div>
      </div>
      <div class="px-3">
        <div class="absolute top-0 right-0 mt-[1rem] mr-[1rem]">
          <img @click="toggleRotation('animated-image2')" src="~/public/icons/select.svg" id="animated-image2">
        </div>
      </div>
      <div v-if="isOpenCSR">
        <ul>
          <li v-for="(item, index) in csrOptions" :key="index" class="block px-4 py-2 hover:text-white hover:bg-dark-100" @click="selectCSR(item)">{{ item }}</li>
        </ul>
      </div>
    </div>
  </div>
  </div>
  <div class="text-xs font-['Plus_Jakarta_Sans'] text-inherit-50 mt-[70px]">
    *Pilih CSR yang anda inginkan sesuai dengan keinginan anda melakukan charity.
  </div>
  </div>
        
  <!-- Buttons -->
  <div class="flex-col p-8 sm:w-full 2xl:w-[718px] w-full -mt-[100px]">
      <div class="flex  gap-4 justify-end items-end -mr-8 -mt-8">
        <button class="bg-transparent inherif-50 p-2 xl:p-4 text-sm xl:text-base" style="width: 123px; height: 44px; display: flex; align-items: center; justify-content: center;">
          Batal
        </button>
        
        <button class="btn-confirm bg-primary p-2 xl:p-4 font-bold rounded-lg text-sm xl:text-base dark:text-dark-100" style="width: 170px; height: 44px; text-align: center; display: flex; align-items: center; justify-content: center;" @click="showBtk1">
          Buat Tiket Konser
        </button>
      </div>
  </div>     

  <!-- Konfirmasi 1-->
  <div v-if="Btk1" class="notification">
      <ModalsOverlay>
        <div class="w-10px h-10px rounded-lg flex flex-col gap-32 ml-4 text-white" style="background-color: var(--Dark-Grey-100, #242424); font-family: 'Plus Jakarta Sans', sans-serif; rounded-lg">
          <div class="h-[509px] w-[400px] sm:h-[365px] sm:w-[280px]">
            <h2 class="font-bold py-4 px-6 text-[16px] sm:text-[12px]">Konfirmasi</h2>
            <div class="flex items-center justify-center mt-[25px] sm:mt-[10px]">
              <img class="sm:w-[205px] w-[300px]" src="~/public/icons/undraw1.png" alt="Gambar" />
            </div>
            <p class="px-6 sm:mt-[15px] mt-[20px] text-[16px] sm:text-[12px]">
              Apakah Anda yakin ingin membuat lelang baru? Lelang akan dikirim kepada admin HistoryOutlet untuk ditindak lanjuti. Cek secara berkala pada bagian Penjualan atau hubungi HO jika ada kendala. 
            </p>
            <div class="flex mt-[26px] sm:mt-[1rem] gap-2 justify-center">
              <div>
                <button class="font-bold w-[168px] h-[44px] sm:w-[110px] sm:h-[30px] text-[16px] sm:text-[12px]" style="font-family: 'Plus Jakarta Sans', sans-serif; transition: background-color 0.3s; display: flex; align-items: center; justify-content: center;" @click="hideBtk1">
                  Tidak
                </button>
              </div>
              <div>
                <button class="btn-confirm bg-primary p-2 xl:p-4 font-bold rounded-lg text-sm xl:text-base dark:text-dark-100 w-[168px] h-[44px] sm:w-[110px] sm:h-[24px] text-[16px] sm:text-[12px]" style="font-family:'Plus Jakarta Sans', sans-serif; transition: background-color 0.3s; display: flex; align-items: center; justify-content: center;" @click="showBtk2">
                  Ya
                </button>
              </div>
            </div>
          </div>
        </div>
      </ModalsOverlay>
  </div>
    

  <!-- Konfirmasi   2  -->
  <div v-if="Btk2" class="notification">
    <ModalsOverlay>
      <div class="w-10px h-8px rounded-lg flex flex-col gap-32 ml-4" style="background-color: var(--Dark-Grey-100, #242424); font-family: 'Plus Jakarta Sans', sans-serif; font-size: 16px;">
        <div class="h-[469px] w-[400px] sm:h-[365px] sm:w-[280px]">
          <h2 class="font-bold py-4 px-6 text-[16px] sm:text-[12px]">Konfirmasi</h2>
          <div class="flex items-center justify-center mt-[30px] sm:mt-[13px]">
            <img class="sm:w-[150px] w-[185px]" src="~/public/icons/undraw.svg" alt="Gambar" />
          </div>
          <p class="sm:mt-[1px] mt-[18px] px-6 text-[16px] sm:text-[12px]">
            Selamat, permintaan lelang Anda sudah dikirim ke pihak HistoryOutlet. Silahkan cek secara berkala pada bagian Penjualan.
          </p>
          <div class="flex mt-[26px] sm:mt-[1rem] gap-2 justify-center">
              <button class="btn-confirm bg-primary p-2 xl:p-4 font-bold rounded-lg text-sm xl:text-base dark:text-dark-100 w-[350px] h-[44px] sm:w-[230px] sm:h-[30px] text-[16px] sm:text-[12px]" style="font-family: 'Plus Jakarta Sans', sans-serif; transition: background-color 0.3s; display: flex; align-items: center; justify-content: center;" @click="hideBtk2">
                OK
              </button>
          </div>
        </div>
      </div>
    </ModalsOverlay>
  </div>

  <!-- Informasi-->
  <div v-if="Btk3" class="notification">
    <ModalsOverlay>
      <div class="flex flex-col justify-between w-[400px] h-[434px] sm:w-[280px] sm:h-[330px] p-6 rounded-lg" style="background-color: var(--Dark-Grey-100, #242424);">
        <div class="text-[16px] sm:text-[12px] font-bold text-white self-start">Informasi</div>
        <div class="text-white font-['Plus_Jakarta_Sans'] self-center w-full text-[16px] sm:text-[12px]">
          Persenan yang ditampilkan adalah komposisi hasil pembagian hasil lelang.
          Hasil lelang akan dibagikan kepada instansi yang dipilih berdasarkan
          persetujuan dari pemilik barang dan penyedia layanan, berikut adalah CSR
          yang dipilih oleh pihak terkait.
        </div>
        <div class="flex flex-col gap-4 items-start">
          <div class="text-[18px] sm:text-[16px] font-bold text-white">CSR Donasi Air Bersih</div>
          <div class="self-stretch flex flex-row gap-2 items-start">
            <div class="font-bold text-white text-[16px] sm:text-[12px]">30%</div>
            <div class="text-white/50 w-5/6 text-[16px] sm:text-[12px]">
              Hasil 30% dari komisi penjualan akan diarahkan kepada bala bantuan Air
              Bersih.
            </div>
          </div>
        </div>
        <div class="flex mt-[26px] sm:mt-[1rem] gap-2 justify-center">
          <button class="btn-confirm bg-primary p-2 xl:p-4 font-bold rounded-lg text-sm xl:text-base dark:text-dark-100 w-[350px] h-[44px] sm:w-[230px] sm:h-[30px] text-[16px] sm:text-[12px]" style="font-family: 'Plus Jakarta Sans', sans-serif; transition: background-color 0.3s; display: flex; align-items: center; justify-content: center;" @click="hideBtk3">
            OK
          </button>
      </div>
      </div>
    </ModalsOverlay>
  </div>
  </section>
  </main>
</template>

<style scoped>
::placeholder {
  color: rgba(255, 255, 255, 0.5);
}
.btn-confirm:hover {
  --dark: #222831;
  background: var(--dark);
  transition: background-color 0.3s;
  color: white;
}
</style>

<!-- <script>
export default {
  data() {
    return {
      selectedCSR: null,
      isOpenCSR: false,
      csrOptions: ["Beasiswa", "Air Bersih", "Rumah Masa Depan", "Sehat Masa Depan", "Trauma Healing", "Stunting"],
      showConfirmation: false,
      showConfirmation2: false,
      showConfirmation3: false,
      formattedPrice1: "",
      formattedPrice2: "",
      selectedImage1: null,
      selectedImage2: null,
      selectedImage3: null,
      selectedImage4: null,
      isVideo1: false,
      isVideo2: false,
      isVideo3: false,
      isVideo4: false,
    };
  },
  methods: {
    toggleRotation(iconId) {
      const image = document.getElementById(iconId);
      const currentRotation = image.style.transform || 'rotate(0deg)';
      const isRotated = currentRotation === 'rotate(180deg)';

      if (isRotated) {
        image.style.transform = 'rotate(0deg)';
      } else {
        image.style.transform = 'rotate(180deg)';
      }
    },
    toggleCSRSearch() {
      this.isOpenCSR = !this.isOpenCSR;
    },
    selectCSR(item) {
      this.selectedCSR = item;
      this.isOpenCSR = false;
    },
    hideConfirmation() {
      this.showConfirmation = false;
    },
    confirmAction() {
      // Lakukan tindakan yang Anda butuhkan saat tombol "Ya" pertama diklik
      this.showConfirmation2 = true;
      this.showConfirmation = false;
    },
    hideConfirmation3() {
      this.showConfirmation3 = false;
    },
    formatPrice1() {
      const firstDigit = this.formattedPrice1.replace(/\D/g, '').charAt(0);
      const price = this.formattedPrice1.replace(/\D/g, '');
      this.formattedPrice1 = `${firstDigit}${price.slice(1).replace(/\B(?=(\d{3})+(?!\d))/g, '.')}`;
    },
    formatPrice2() {
      const firstDigit = this.formattedPrice2.replace(/\D/g, '').charAt(0);
      const price = this.formattedPrice2.replace(/\D/g, '');
      this.formattedPrice2 = `${firstDigit}${price.slice(1).replace(/\B(?=(\d{3})+(?!\d))/g, '.')}`;
    },
    handleFileChange(inputIndex) {
      const inputId = `file-input-${inputIndex}`;
      const fileInput = document.getElementById(inputId);
      const file = fileInput.files[0];
      if (file) {
        if (file.type.startsWith("image/")) {
          this['isVideo' + inputIndex] = false;
        } else if (file.type.startsWith("video/")) {
          this['isVideo' + inputIndex] = true;
        }
        this['selectedImage' + inputIndex] = URL.createObjectURL(file);
      }
    }
  }
};
 

</script> -->


<script setup>
import { ref } from 'vue';

    const selectedCSR = ref(null);
    const isOpenCSR = ref(false);
    const csrOptions = [
      "Beasiswa", "Air Bersih", "Rumah Masa Depan", "Sehat Masa Depan", "Trauma Healing", "Stunting"
    ];
    const time = {
  hours: ref(new Date().getHours()),
  minutes: ref(new Date().getMinutes())
};

const date = ref({});

    
    function toggleRotation(iconId) {
      const image = document.getElementById(iconId);
      const currentRotation = image.style.transform || 'rotate(0deg)';
      const isRotated = currentRotation === 'rotate(180deg)';

      if (isRotated) {
        image.style.transform = 'rotate(0deg)';
      } else {
        image.style.transform = 'rotate(180deg)';
      }
    }

    function toggleCSRSearch() {
      isOpenCSR.value = !isOpenCSR.value;
    }

    function selectCSR(item) {
      selectedCSR.value = item;
      isOpenCSR.value = false;
    }
    

    // Btk Buat Tiket Konser
    const Btk1= ref(false);
    const Btk2= ref(false);
    const Btk3= ref(false);

    const showBtk1 = () => {
      Btk1.value = true; 
    };
    const showBtk2 = () => {
      Btk1.value = false;
      Btk2.value = true;
    };
    const showBtk3 = () => {
      Btk1.value = false;
      Btk3.value = true;
    };

    const hideBtk1 = () => {
      Btk1.value = false;
    };
    const hideBtk2 = () => {
      Btk2.value = false;
    };
    const hideBtk3 = () => {
      Btk3.value = false;
    };

</script>


