<script setup>
import { ref, onMounted } from 'vue';
import axios from 'axios';

const route = useRoute();
// Hho Hubungi History Outlet
  const Hho1= ref(false);
  const Hho2= ref(false);

  const showHho1 = () => {
    Hho1.value = true; 
  };
  const showHho2 = () => {
    Hho1.value = false;
    Hho2.value = true;
  };

  const hideHho1 = () => {
    Hho1.value = false;
  };
  const hideHho2 = () => {
    Hho2.value = false;
  };
   
const LelangT = ref(null); 

const fetchLelangTs = async () => {
  try {
    const response = await axios.get('https://6550a40f7d203ab6626e02b9.mockapi.io/lelangTransaksi/'+route.params.id);
    LelangT.value = response.data;
  } catch (error) {
    console.error('Error fetching LelangT:', error);
  }
};

onMounted(fetchLelangTs);
</script>

<template>
    <main class="px-60 2xl:px-48 xl:px-40 sm:px-4">
    <section class="mt-[32px] sm:mt-8 flex flex-col gap-32">
        <div class="flex flex-col gap-4 justify-center items-center">
          <div class="overflow-hidden sm:w-full w-[700px]">
            <div class="flex gap-4 font-medium text-[16px] sm:text-[12px]">
              <a href="/" class="text-inherit-50 cursor-pointer">Beranda</a>
              <p class="text-inherit-50 cursor-default">/</p>
              <p class="text-yellow-100 cursor-pointer">Detail Transaksi Lelang</p>
              </div>
              <div class="mt-[30px] sm:mt-[20px]">
              <h3 class="text-[24px] sm:text-[16px] font-bold">Detail Transaksi Lelang</h3>
              <p class="mt-1 font-normal text-[16px] sm:text-[12px]">Isi semua detail transaksi lelang yang sedang berjalan atau sudah selesai</p>
            </div>
        </div>
      </div>
      <!-- {{ LelangT }} -->

      <!-- {{LelangT ? LelangT.invoice : "_"}} -->
    
    <div class="flex flex-col gap-4 -mt-[6rem] justify-center items-center">

    <!-- Invoice Lelang -->
    <div class="dark:bg-darkGrey-100 rounded-lg shadow-32 overflow-hidden h-[150px] sm:h-[150px] sm:w-full w-[700px] font-Plus_Jakarta_Sans">
        <div class="font-semibold ml-8 my-4 text-xl">Invoice Lelang</div>
        <div class="flex flex-row justify-between items-start w-full">
            <div class="flex flex-col justify-between w-24 shrink-0 items-start text-inherit-50 ml-8 text-base">
                <div>Invoice</div>
                <div class="my-4">TanggalMenang</div>
            </div>
            <div class="flex flex-col justify-between text-right font-semibold mr-8">
                <div>{{LelangT ? LelangT.invoice : "_"}}</div>
                <div class="my-4">{{LelangT ? LelangT.tanggalMenang : "_"}}</div>
            </div>
        </div>
    </div>

    <!-- Informasi Umum -->
    <div class="dark:bg-darkGrey-100 rounded-lg shadow-32 overflow-hidden h-[220px] sm:h-[225px] sm:w-full w-[700px] font-Plus_Jakarta_Sans">
        <div class="flex flex-row justify-between items-start">
            <div class="items-start ml-8 my-4 text-xl font-semibold">
                <div>Informasi Umum</div>
            </div>
            <div class="justify-between mr-8 my-4 text-right text-sm text-blue-100">
                <div>Edit</div>
            </div>
        </div>
        <div class="flex flex-row justify-between items-start w-full">
            <div class="flex flex-col justify-between w-24 shrink-0 items-start text-inherit-50 ml-8 text-base">
                <div>Nama</div>
                <div class="my-4">Alamat</div>
                <div>No.Telepon</div>
                <div class="my-4">Maps</div>
            </div>
            <div class="flex flex-col justify-between mr-8 text-right">
                <div class="font-semibold">{{LelangT ? LelangT.nama : "_"}}</div>
                <div class="font-semibold my-4">{{LelangT ? LelangT.alamat : "_"}}</div>
                <div class="font-semibold">{{LelangT ? LelangT.noTelepon : "_"}}</div>
                <div class="my-4 text-blue-100">Pinpoint</div>
            </div>
        </div>
    </div>

     <!-- Informasi Pengiriman -->
     <div class="dark:bg-darkGrey-100 rounded-lg shadow-32 overflow-hidden h-[190px] sm:h-[190px] sm:w-full w-[700px] font-Plus_Jakarta_Sans">
        <div class="font-semibold ml-8 my-4 text-xl">Informasi Pengiriman</div>
        <div class="flex flex-row justify-between items-start w-full">
            <div class="flex flex-col justify-between w-24 shrink-0 items-start text-inherit-50 ml-8 text-base">
                <div>Kurir</div>
                <div class="my-4">Nomer Resi</div>
                <div>Status</div>
            </div>
            <div class="flex flex-col justify-between mr-8 text-right">
                <div class="font-semibold">                <div class="font-semibold">{{LelangT ? LelangT.kurir : "_"}}</div>
              </div>
                <div class="font-semibold">{{LelangT ? LelangT.nomorResi : "_"}}</div>
                <div class="font-semibold my-4"></div>
                <div class="font-semibold text-orange-100">Belum dikirim</div>
            </div>
        </div>
    </div>

     <!-- Rincian pembayaran -->
     <div class="dark:bg-darkGrey-100 rounded-lg shadow-32 overflow-hidden h-[145px] sm:h-[160px] sm:w-full w-[700px] font-Plus_Jakarta_Sans">
        <div class="font-semibold ml-8 my-4 text-xl">Rincian Pembayaran</div>
        <div class="flex flex-row justify-between items-start w-full">
            <div class="flex flex-col justify-between w-25 shrink-0 items-start text-inherit-50 ml-8 text-base">
                <div>Metode pembayaran</div>
                <div class="my-4">Total Dibayar</div>
            </div>
            <div class="flex flex-col justify-between text-right font-semibold mr-8">
                <div>{{LelangT ? LelangT.metodePembayaran : "_"}}</div>
                <div class="my-4 text-green-100">Rp {{LelangT ? LelangT.totalDibayar : "_"}} </div>
            </div>
        </div>
    </div>

         <!-- Button -->
         <div class="flex justify-end font-bold h-[140px] sm:h-[150px] sm:w-full w-[700px] font-Plus_Jakarta_Sans">
            <button class="bg-primary ml-5 rounded-lg w-[208px] h-[44px]">
            <div class="text-[#222831] mx-4" @click="showHho1">
            <span>Hubungi HistoryOutlet</span>
            </div>
            </button>
        </div>
    </div>
</section>
</main>
          
     <!-- Konfirmasi 1-->
    <div v-if="Hho1" class="notification">
      <ModalsOverlay>
        <div class="w-10px h-10px rounded-lg flex flex-col gap-32 ml-4 shadow-32 dark:bg-darkGrey-100 bg-white" style="font-family: 'Plus Jakarta Sans', sans-serif;">
                
          <div class="h-[469px] w-[400px] sm:h-[365px] sm:w-[280px]">
            <h2 class="font-bold py-4 px-6 text-[16px] sm:text-[12px]">Konfirmasi</h2>
            <div class="flex items-center justify-center mt-[28px]">
              <img class="sm:w-[205px] w-[300px]" src="~/public/icons/undraw1.png" alt="Gambar" />
            </div>
            <p class="px-6 sm:mt-[15px] mt-[10px] text-[16px] sm:text-[12px]"> 
              Apakah anda yakin ingin menjadi partner untuk melakukan lelang? Tim HistoryOutlet akan menghubungi pihak terkait untuk melanjutkan registrasi.
            </p>
            <div class="flex mt-[16px] sm:mt-[1rem] gap-2 justify-center">
              <div>
                <button class="font-bold w-[168px] h-[44px] sm:w-[110px] sm:h-[30px] text-[16px] sm:text-[12px]" style="font-family: 'Plus Jakarta Sans', sans-serif; transition: background-color 0.3s; display: flex; align-items: center; justify-content: center;"  @click="hideHho1">
                  Tidak
                </button>
              </div>
              <div>
                <button class="btn-confirm bg-primary p-2 xl:p-4 font-bold rounded-lg text-sm xl:text-base dark:text-dark-100 w-[168px] h-[44px] sm:w-[110px] sm:h-[24px] text-[16px] sm:text-[12px]" style="font-family:'Plus Jakarta Sans', sans-serif; transition: background-color 0.3s; display: flex; align-items: center; justify-content: center;" @click="showHho2">
                  Ya
                </button>
              </div>
            </div>
          </div>
        </div>
      </ModalsOverlay>
    </div>
    
    <!-- Konfirmasi   2  -->
    <div v-if="Hho2" class="notification">
      <ModalsOverlay>
        <div class="w-10px h-8px rounded-lg flex flex-col gap-32 ml-4 dark:bg-darkGrey-100 bg-white shadow-32" style=" font-family: 'Plus Jakarta Sans', sans-serif; font-size: 16px;">
          <div class="h-[469px] w-[400px] sm:h-[365px] sm:w-[280px]">
            <h2 class="font-bold py-4 px-6 text-[16px] sm:text-[12px]">Konfirmasi</h2>
  
            <div class="flex items-center justify-center mt-[28px] sm:mt-[15px]">
              <img class="sm:w-[150px] w-[185px]" src="~/public/icons/undraw.svg" alt="Gambar" />
            </div>
  
            <p class="sm:mt-[3px] mt-[1px] px-6 text-[16px] sm:text-[12px]">
                Selamat, permintaan anda untuk membuat lelang sudah dikirim. Silahkan tunggu panggilan dari tim kami untuk melanjutkan registrasi.
            </p>
            <div class="flex mt-[24px] sm:mt-[14px] gap-2 justify-center">
              <div>
                <button class="btn-confirm bg-primary p-2 xl:p-4 font-bold rounded-lg text-sm xl:text-base dark:text-dark-100 w-[350px] h-[44px] sm:w-[234px] sm:h-[30px] text-[16px] sm:text-[12px]" style="font-family: 'Plus Jakarta Sans', sans-serif; transition: background-color 0.3s; display: flex; align-items: center; justify-content: center;" @click="hideHho2" >
                  OK
                </button>
              </div>
            </div>
          </div>
        </div>
      </ModalsOverlay>
    </div>
   
    </template>
    
    
<style scoped></style>
    
