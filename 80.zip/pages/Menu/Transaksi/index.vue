<!-- <script setup>
// import { ref } from 'vue';

const activeTab = ref(1);

const changeTab = (tabNumber) => {
  activeTab.value = tabNumber;
};


import { ref, onMounted } from 'vue';
import axios from 'axios';


const LelangT = ref({});
const fetchLelangTs = async () => {
  try {
    let config = {
      method: 'get',
      maxBodyLength: Infinity,
      url: 'https://6550a40f7d203ab6626e02b9.mockapi.io/lelangTransaksi/'+route.params.id,
      headers: { 
      }
    };
    const response = await axios.request(config)
    .then((response) => {
      // console.log(response.data)   
      lelangt.value = response.data
    })
    .catch((error) => {
      console.log(error);
    });

  } catch (error) {
    console.error('Error fetching lelangts:', error);
  }
};

onMounted(fetchLelangTs);
</script> -->

<script setup>
// import { ref, onMounted } from 'vue';
// import axios from 'axios';

const activeTab = ref(1);

const changeTab = (tabNumber) => {
  activeTab.value = tabNumber;
};

// const LelangT = ref(null); // Initialize with null

// const fetchLelangTs = async () => {
//   try {
//     const response = await axios.get('https://6550a40f7d203ab6626e02b9.mockapi.io/lelangTransaksi/');
//     LelangT.value = response.data;
//   } catch (error) {
//     console.error('Error fetching LelangT:', error);
//   }
// };

// onMounted(fetchLelangTs);
</script>

<template>
  <!-- {{ LelangT }} -->
  <main class="px-60 2xl:px-48 xl:px-40 sm:px-4">
  <!-- Content -->
  <section class="mt-[32px] sm:mt-8 flex flex-col gap-32">
      <div class="flex flex-col gap-4 justify-center items-center">
        <div class="overflow-hidden sm:w-full w-[700px]">
          <div class="flex gap-4 font-medium text-[16px] sm:text-[12px]">
            <a href="/" class="text-inherit-50 cursor-pointer">Beranda</a>
            <p class="text-inherit-50 cursor-default">/</p>
            <p class="text-yellow-100 cursor-pointer">Transaksi</p>
            </div>
            <div class="mt-[30px] sm:mt-[20px]">
            <h3 class="text-[24px] sm:text-[16px] font-bold">Lihat Semua Transaksi</h3>
            <p class="mt-1 font-normal text-[16px] sm:text-[12px]">Isi semua transaksi yang sedang berjalan atau sudah selesai</p>
          </div>

          <div class="flex flex-row items-start mt-7 gap-4">
            <Button @click="changeTab(1)" :class="{ active: activeTab === 1 }" class="bg-gradient bg-cover bg-center bg-blend-normal bg-no-repeat flex flex-col justify-center w-[84px] shrink-0 h-[44px] items-center rounded-lg  text-inherit-50">
              <div class="font-Plus_Jakarta_Sans font-bold hover:text-white">
                Lelang
              </div>
            </Button>
          
            <Button @click="changeTab(2)" :class="{ active: activeTab === 2 }" class="flex flex-col justify-center h-[44px] items-center rounded-lg py-2 px-6 text-inherit-50">
              <div class="font-Plus_Jakarta_Sans font-bold hover:text-white">
                Tiket 
              </div>
            </Button>
          </div>
      </div> 
    </div>
      
    <div v-if="activeTab === 1">
    <div class="flex flex-col gap-4 -mt-[6rem] justify-center items-center">
      <CardTransaksilelang/>
      <!-- <CardTransaksi/>
      <CardTransaksi/>
      <CardTransaksi/>
      <CardTransaksi/> -->
    </div>
  </div>

  <div v-if="activeTab === 2">
    <div class="flex flex-col gap-4 -mt-[6rem] justify-center items-center">
      <CardTransaksitiket/>
      INI TRANSAKSI TIKET
    </div>
  </div>



  </section>
</main>
</template>

<style scoped>
@media (max-width: 1600px) {
  .header {
    font-size: 45px;
  }
}

@media (max-width: 1400px) {
  .header {
    font-size: 40px;
  }
}

.active {
  border-radius: 8px;
  background: var(--Gold-100, linear-gradient(98deg, #FFD849 0%, #FFC937 26.68%, #FFE88C 54.39%, #FFD546 94.58%));
  color: #222831;
}
</style>