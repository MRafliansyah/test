<script lang="ts" setup></script>

<template>
<main class="px-60 2xl:px-48 xl:px-40 sm:px-4">
  <!-- Content -->
  <section class="mt-[32px] sm:mt-8 flex flex-col gap-32">
      <div class="flex flex-col gap-4 justify-center items-center">
        <div class="overflow-hidden sm:w-full w-[700px]">
          <div class="flex gap-4 font-medium text-[16px] sm:text-[12px]">
            <a href="/" class="text-inherit-50 cursor-pointer">Beranda</a>
            <p class="text-inherit-50 cursor-default">/</p>
            <p class="text-yellow-100 cursor-pointer">Penjualan Saya</p>
            </div>
            <div class="mt-[30px] sm:mt-[20px]">
            <h3 class="text-[24px] sm:text-[16px] font-bold">Lihat Semua Penjualan Saya</h3>
            <p class="mt-1 font-normal text-[16px] sm:text-[12px]">Isi semua penjualan saya yang sedang berjalan atau sudah selesai</p>
          </div>
      </div>
    </div>
            
    <div class="flex flex-col gap-4 -mt-[6rem] justify-center items-center">
      <CardPenjualanSaya />
      <CardPenjualanSaya />
      <CardPenjualanSaya />
    </div>
  </section>
</main>
</template>

<style scoped>
@media (max-width: 1600px) {
  .header {
    font-size: 45px;
  }
}

@media (max-width: 1400px) {
  .header {
    font-size: 40px;
  }
}

</style>