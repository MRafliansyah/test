<template>
    <main class="px-60 2xl:px-48 xl:px-40 sm:px-4">
        <!-- Content -->
        <section class="mt-[32px] sm:mt-8 flex flex-col gap-32">
            <div class="flex flex-col gap-4 justify-center items-center">
              <div class="overflow-hidden sm:w-full w-[700px]">
                <div class="flex gap-4 font-medium text-[16px] sm:text-[12px]">
                  <a href="/" class="text-inherit-50 cursor-pointer">Beranda</a>
                  <p class="text-inherit-50 cursor-default">/</p>
                  <p class="text-yellow-100 cursor-pointer">Permintaan Konfirmasi</p>
                  </div>
                  <div class="mt-[30px] sm:mt-[20px]">
                  <h3 class="text-[24px] sm:text-[16px] font-bold">Lihat Semua Permintaan Konfirmasi</h3>
                  <p class="mt-1 font-normal text-[16px] sm:text-[12px]">Isi semua Konfirmasi saya yang sedang berjalan atau sudah selesai</p>
                </div>
            </div>
          </div>

        <!--Lelang-->  
          <div class="flex flex-col gap-4 -mt-[6rem] justify-center items-center"> 
            <div class="dark:bg-darkGrey-100 rounded-lg shadow-32 overflow-hidden h-[120px] sm:h-[71px] sm:w-full w-[700px]">
                <div class="flex">
                  <!-- Thumbnail -->
                  <div class="flex flex-col py-[28px] px-[32px] sm:py-[12px] sm:px-[12px]">
                    <div class="sm:w-[46px] w-[66px]">
                      <img src="~/public/img/sample_makki.png" alt="Gambar Makki" />
                    </div>
                  </div>
              
                  <!-- Content -->
                  <div class="flex flex-col py-[32px] sm:py-[11px] sm:ml-[-1px] -ml-3">
                    <div class="flex items-center gap-2">
                      <p class="text-[16px] sm:text-[12px] leading-tight">Lelang</p>
                      <img src="~/public/icons/elipse1.svg" alt="Icon" />

                      <!--Sudah dikonfirmasi-->
                      <div class="bg-green-100 flex flex-col w-[120px] h-auto text-center">
                        <div class="text-[12px] sm:text-[12px] font-['Plus_Jakarta_Sans']  whitespace-nowrap">
                          Sudah Dikonfirmasi
                        </div>
                      </div>

                    <!-- Belum dikonfirmasi-->
                    <div class="bg-red-100 flex flex-col w-[120px] h-auto text-center">
                        <div class="text-[12px] sm:text-[12px] font-['Plus_Jakarta_Sans']  whitespace-nowrap">
                          Belum Dikonfirmasi
                        </div>
                      </div>
                    </div>
              
                    <!-- Detail -->
                    <div class="flex flex-col mt-1 xl:flex-row xl:items-center">
                      <div class="flex-1">
                        <p class="text-[20px] sm:text-[14px] leading-tight font-bold">Bass Putih Makki Omar Parikesit</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
          </div>

         <!--Tiket -->  
         <div class="flex flex-col gap-4 -mt-[6rem] justify-center items-center"> 
            <div class="dark:bg-darkGrey-100 rounded-lg shadow-32 overflow-hidden h-[120px] sm:h-[71px] sm:w-full w-[700px]">
                <div class="flex">
                  <!-- Thumbnail -->
                  <div class="flex flex-col py-[28px] px-[32px] sm:py-[12px] sm:px-[12px]">
                    <div class="sm:w-[46px] w-[66px]">
                      <img src="~/public/img/sample_makki.png" alt="Gambar Makki" />
                    </div>
                  </div>
              
                  <!-- Content -->
                  <div class="flex flex-col py-[32px] sm:py-[11px] sm:ml-[-1px] -ml-3">
                    <div class="flex items-center gap-2">
                      <p class="text-[16px] sm:text-[12px] leading-tight">Tiket</p>
                      <img src="~/public/icons/elipse1.svg" alt="Icon" />

                      <!--Sudah dikonfirmasi-->
                      <div class="bg-green-100 flex flex-col w-[120px] h-auto text-center">
                        <div class="text-[12px] sm:text-[12px] font-['Plus_Jakarta_Sans']  whitespace-nowrap">
                          Sudah Dikonfirmasi
                        </div>
                      </div>

                    <!-- Belum dikonfirmasi-->
                    <div class="bg-red-100 flex flex-col w-[120px] h-auto text-center">
                        <div class="text-[12px] sm:text-[12px] font-['Plus_Jakarta_Sans']  whitespace-nowrap">
                          Belum Dikonfirmasi
                        </div>
                      </div>
                    </div>
              
                    <!-- Detail -->
                    <div class="flex flex-col mt-1 xl:flex-row xl:items-center">
                      <div class="flex-1">
                        <p class="text-[20px] sm:text-[14px] leading-tight font-bold">Tiket konser Ungu</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
          </div>
        </section>
      </main>
</template>