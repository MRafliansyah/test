<template>
  <div class="w-full h-max flex justify-between">
    <div><Sidebar/></div>
    
   <div class="flex flex-row justify-between w-full items-center py-9 px-6 -mt-5">
      <div class="self-start flex flex-col items-start">
        <div class="text-3xl font-Plus_Jakarta_Sans font-semibold">
          Pengaturan
        </div>
        <div class="font-Plus_Jakarta_Sans text-inherit-50">
          Tempat dimana anda dapat mengubah/menambah informasi Admin.
        </div>

<!-- akun -->
  <div class="flex flex-col gap-12 h-56 items-start hover:pr-16 py-10 px-[5rem]">            
  <button class="bg-transparent hover:gold-20 text-white font-semibold py-2 px-4 mt-15 hover:border-transparent rounded flex items-center hover:pr-16" style="color: var(--White-50, rgba(255, 255, 255, 0.50)); font-family: 'Plus Jakarta Sans'; font-size: 19px; font-style: normal; font-weight: 400; line-height: normal;">
    <img src="~/public/icons/account.svg"/>
   <div class="text-lg font-['Plus_Jakarta_Sans'] text-inherit-50 ml-4">
    Akun
  </div>
  </button>

<!-- Keamanan -->
  <button class="bg-transparent hover:gold-20 text-white font-semibold py-2 px-4 hover:border-transparent rounded flex items-center hover:pr-15 -mt-4" style="color: var(--White-50, rgba(255, 255, 255, 0.50)); font-family: 'Plus Jakarta Sans'; font-size: 19px; font-style: normal; font-weight: 400; line-height: normal;">
  <img src="~/public/icons/lock.svg"/>
   <div class="text-lg font-['Plus_Jakarta_Sans'] text-inherit-50 ml-4">
    Keamanan
  </div>
  </button>


  <!-- Logout -->
        <button class="bg-transparent hover:gold-20 text-white font-semibold py-2 px-4 -mt-4 hover:border-transparent rounded flex items-center hover:pr-11" style="color: var(--White-50, rgba(255, 255, 255, 0.50)); font-family: 'Plus Jakarta Sans'; font-size: 19px; font-style: normal; font-weight: 400; line-height: normal;">
          <img src="~/public/icons/logout.svg"/>
        <div class="text-lg font-['Plus_Jakarta_Sans'] text-inherit-50 ml-4">
          Logout
        </div>
        </button>  
      </div>
      </div>
        
  
      <!-- Search -->
      <div class="flex flex-row items-center gap-4 -mt-[60rem] -ml-10">
        <div class="border-solid border-white/20 bg-[#242424] flex flex-row gap-4 w-[413px] shrink-0 h-12 items-center px-4 border rounded-lg">
          <img src="~/public/icons/search.svg" class="w-6 h-6" alt="Search Icon" />
          <input
            type="text"
            id="Cari"
            class="font-Plus_Jakarta_Sans text-white/50 bg-transparent border-none outline-none"
            placeholder="Cari"
          />
        </div>
  
        <!-- Notifikasi -->
        <div class="border-solid border-white/20 bg-[#242424] flex flex-col justify-center w-12 shrink-0 h-12 items-center border rounded-lg">
          <img src="~/public/icons/notifications.svg"/>
        </div>
      </div>
    </div>
  </div>

  <!-- pengaturan -->
  <div class="flex flex-col gap-8 px-[38rem] -mt-[60rem]">
    <div class="self-start flex flex-row gap-8 w-1/2 items-center">
      <div class="bg-[src...] bg-cover bg-50%_50% bg-blend-normal bg-no-repeat self-start flex flex-col justify-end w-24 shrink-0 h-24 items-end">
        <div class="shadow-[0px_0px_16px_0px_rgba(34,_40,_49,_0.24)] overflow-hidden bg-[linear-gradient(98deg,_#ffd849_-8%,#ffc937_30%,#ffe88c_69%,#ffd546_125%)] bg-cover bg-50%_50% bg-blend-normal bg-no-repeat flex flex-col w-8 h-8 shrink-0 items-center py-1 rounded-[41px]">
          <img src="~/public/icons/modeedit.svg"/>
        </div>
      </div>
      <div class="flex flex-col w-2/3 items-start">
        <div class="text-2xl font-['Plus_Jakarta_Sans'] font-semibold">
          AsepSaepudin
        </div>
        <div class="text-1xl font-['Plus_Jakarta_Sans']">
          Administrator
        </div>
      </div>
    </div>
    <div class="flex flex-col justify-between gap-4 items-start w-[500px]">
      <div class="font-['Plus_Jakarta_Sans'] -mt-2">Nama Lengkap</div>
      <div class="border-solid border-white-20 bg-[#090909] self-stretch flex flex-row gap-4 h-12 shrink-0 items-center px-4 border rounded-lg -mt-2">
        <img src="~/public/icons/account.svg"/>
        <div class="text-lg font-['Plus_Jakarta_Sans']">
          Asep Saepudin
        </div>
      </div>
      <div class="text-xs font-['Plus_Jakarta_Sans'] text-inherit-50 -mt-2">
        *Nama asli user/admin
      </div>
    </div>
    <div class="flex flex-col justify-between gap-4 items-start w-[500px]">
      <div class="font-['Plus_Jakarta_Sans'] -mt-2">Username</div>
      <div class="border-solid border-white/20 bg-[#090909] self-stretch flex flex-row gap-4 h-12 shrink-0 items-center px-4 border rounded-lg -mt-2">
        <img src="~/public/icons/account.svg"/>
        <div class="text-lg font-['Plus_Jakarta_Sans'] text-white">
          asepsaepudin123
        </div>
      </div>
      <div class="text-xs font-['Plus_Jakarta_Sans'] text-inherit-50 -mt-2">
        *Username yang digunakan pada saat login
      </div>
    </div>
    <div class="flex flex-col justify-between gap-4 items-start w-[500px]">
      <div class="font-['Plus_Jakarta_Sans'] -mt-2">Otoritas</div>
      <div
        id="UsernameInput2"
        class="border-solid border-white/20 bg-[#090909] self-stretch flex flex-row gap-4 h-12 shrink-0 items-center px-4 border rounded-lg -mt-2">
        <img src="~/public/icons/account.svg"/>
        <div
          id="AsepSaepudin3"
          class="text-lg font-['Plus_Jakarta_Sans'] text-white">
          Administrator
        </div>
      </div>
      <div class="text-xs font-['Plus_Jakarta_Sans'] text-inherit-50 -mt-2">
        *Otoritas yang dipegang pada user ini
      </div>
    </div>
  </div>
</template>

<script setup></script>

<style scoped></style>


