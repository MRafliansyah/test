<script lang="ts" setup></script>

<template>
  <main class="px-60 2xl:px-48 xl:px-40 sm:px-4 mt-[10.5vh]">

    <!-- Header -->
    <div class="mb-16 xl:mb-11">
      <h1 class="text-primary font-bold">Favorit</h1>
      <h1>Kumpulan barang paling disukai</h1>
    </div>

    <!-- Not Logged in -->
    <section class="flex flex-col gap-4 xl:gap-3 w-full items-center phone-img mx-auto">
      <img src="/img/person_phone.svg" alt="Person with phone" class="phone-img">
      <div class="flex flex-col gap-2 xl:gap-1 cursor-default">
        <p class="font-bold text24 text-center">Favorit belum tersedia</p>
        <p class="text-center text16">Fitur Favorit hanya bisa digunakan untuk user yang sudah login. Silahkan login atau buat
          akun baru dibawah!</p>
      </div>
      <div class="flex gap-4 w-full">
        <button class="rounded-lg py-3 xl:py-2 px-4 xl:px-3 grow font-bold text-inherit-50 hover:text-inherit text16">Daftar</button>
        <button class="rounded-lg bg-primary p12-16 grow font-bold text16 text-dark-100">Login</button>
      </div>
    </section>
  </main>
</template>

<style scoped>
h1 {
  font-size: 56px;
  line-height: 71px;
  cursor: default;
}

.phone-img {
  width: 34vw;
}
@media (max-width: 1600px) {
  h1 {
    font-size: 45px;
    line-height: 56px;
  }
}
@media (max-width: 1400px) {
  h1 {
    font-size: 40px;
    line-height: 51px;
  }
}
</style>
