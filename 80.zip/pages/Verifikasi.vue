<template>
  <div class="w-full h-max flex justify-between fixed-content-width">
  <div><Sidebar/></div>
    
  <div class="flex flex-row justify-between w-full items-center py-9 px-5">
    <div class="self-start flex flex-col items-start">
        <div class="text-3xl font-Plus_Jakarta_Sans font-semibold">
          Verifikasi
        </div>
      <div class="font-Plus_Jakarta_Sans text-inherit-50">
    Tempat dimana anda dapat melakukan verifikasi data yang masuk.
</div>
      
 <!-- button -->
<div class="flex flex-row items-start mt-7 -ml-1 gap-4">
  <Button @click="changeTab(1)" :class="{ active: activeTab === 1 }" class="bg-gradient bg-cover bg-center bg-blend-normal bg-no-repeat flex flex-col justify-center w-[84px] shrink-0 h-[44px] items-center rounded-lg  text-inherit-50">
    <div class="font-Plus_Jakarta_Sans font-bold hover:text-white">
      Lelang
    </div>
  </Button>

  <!-- <Button @click="changeTab(1)" :class="{ active: activeTab === 1 }">Lelang</Button> -->
  <!-- <Button @click="changeTab(2)" :class="{ active: activeTab === 2 }">Tiket Konser</Button> -->

  <Button @click="changeTab(2)" :class="{ active: activeTab === 2 }" class="flex flex-col justify-center h-[44px] items-center rounded-lg py-2 px-6 text-inherit-50">
    <div class="font-Plus_Jakarta_Sans font-bold hover:text-white">
      Tiket Konser
    </div>
  </Button>
</div>
</div>
  
  <!-- Search -->
  <div class="flex flex-row items-center gap-4 -mt-[941px] -mr-[310px]">
    <div class="border-solid border-white/20 bg-[#242424] flex flex-row gap-4 w-[413px] shrink-0 h-12 items-center px-4 border rounded-lg">
      <img src="~/public/icons/search.svg" class="w-6 h-6" alt="Search Icon" />
      <input
        type="text"
        id="Cari"
        class="font-Plus_Jakarta_Sans text-white/50 bg-transparent border-none outline-none"
        placeholder="Cari"
      />
    </div>

    <!-- Notifikasi -->
    <div class="border-solid border-white/20 bg-[#242424] flex flex-col justify-center w-12 shrink-0 h-12 items-center border rounded-lg">
      <img src="~/public/icons/notifications.svg"/>
    </div>
  </div>
</div>
</div>

<!-- Lelang-->
<div v-if="activeTab === 1">
<div class="flex -mt-[55rem] ml-[18rem]">
  <div class="w-984 h-496 rounded-lg" style="display: flex; width: 1207px; height: 596px; padding: 24px; flex-direction: column; align-items: flex-start; gap: 24px; flex-shrink: 0; background: var(--Dark-Grey-100, #242424);">
    <h2 style="color: var(--White-100, #FFF); font-family: 'Plus Jakarta Sans'; font-size: 24px; font-style: normal; font-weight: 600; line-height: normal;">Semua Permintaan Lelang</h2>
    <div class="flex flex-row justify-end gap-2 items-start">
      <div class="flex flex-row gap-2 w-16 shrink-0 items-start">
        <div class="font-Plus_Jakarta_Sans text-white">Filter</div>
        <img src="~/public/icons/filteralt.svg"/>
      </div>
      
        <!-- Kategori -->
        <div class="relative w-[146px]">
          <div class="flex flex-col justify-center mr-2 gap-8 items-center px-3 py-2 rounded-lg" style="position: relative; z-index: 1; border: 1px solid rgba(255, 255, 255, 0.2);">
            <button @click="toggleKategoriSearch" class="block flex items-center h-[14px] w-48 focus:outline-none focus:border-none active:outline-none active:border-none">
              <div class="font-Plus_Jakarta_Sans text-white text-start flex items-center">
                <div class="flex text-center ml-[25px] ">
                  <span style="min-width: 100px;">{{ selectedKategori || "Kategori" }}</span>
                  <img src="~/public/icons/select.svg" class="ml-3" alt="Select Icon" />
                </div>
              </div>
            </button>
            <div v-if="isKategoriOpen" class="py-2 w-[137px] h-[210px] -mt-7 rounded-lg overflow-hidden" style="z-index: 2; solid rgba(255, 255, 255, 0.2);">
              <ul>
                <li v-for="(item, index) in KategoriOptions" :key="index" class="block px-4 py-2 hover:bg-black hover:bg-black-100 rounded-lg" @click="selectKategori(item)">{{ item }}</li>
              </ul>
            </div>
          </div>
        </div>
    
        <!-- CSR -->
        <div class="relative w-[146px]">
          <div class="flex flex-col justify-center mr-2 gap-8 items-center px-3 py-2 rounded-lg" style="position: relative; z-index: 1; border: 1px solid rgba(255, 255, 255, 0.2);">
            <button @click="togglecsrSearch" class="block flex items-center h-[14px] w-48 focus:outline-none focus:border-none active:outline-none active:border-none">
              <div class="font-Plus_Jakarta_Sans text-white text-start flex items-center">
                <div class="flex text-center ml-[25px] ">
                  <span style="min-width: 100px;">{{ selectedcsr || "CSR" }}</span>
                  <img src="~/public/icons/select.svg" class="ml-3" alt="Select Icon" />
                </div>
              </div>
            </button>
            <div v-if="isCSROpen" class="py-2 w-[137px] h-[210px] -mt-7 rounded-lg overflow-hidden" style="z-index: 2; solid rgba(255, 255, 255, 0.2);">
              <ul>
                <li v-for="(item, index) in csrOptions" :key="index" class="block px-4 py-2 hover:bg-black hover:bg-black-100 rounded-lg" @click="selectcsr(item)">{{ item }}</li>
              </ul>
            </div>
          </div>
        </div>
      
     <!-- Search -->
      <div class="border-solid border-white/20 bg-[#242424] flex flex-row justify-center gap-12 h-8 items-center px-3 py-2 border rounded-lg">
        <div class="font-Plus_Jakarta_Sans text-white/50">
          <input
            type="text"
            id="Cari"
            class="font-Plus_Jakarta_Sans text-white/50 bg-transparent border-none outline-none"
            placeholder="Cari Lelang/Tiket"/>
        </div>
        <img class="w-20px h-20px" src="~/public/icons/search.svg"/>
      </div>

      
    </div>
  </div>
</div>
</div>

<!-- Tiket konser-->
<div v-if="activeTab === 2">
  <div class="flex -mt-[55rem] ml-[18rem]">
    <div class="w-984 h-496 rounded-lg" style="display: flex; width: 1207px; height: 596px; padding: 24px; flex-direction: column; align-items: flex-start; gap: 24px; flex-shrink: 0; background: var(--Dark-Grey-100, #242424);">
      <h2 style="color: var(--White-100, #FFF); font-family: 'Plus Jakarta Sans'; font-size: 24px; font-style: normal; font-weight: 600; line-height: normal;">Semua Permintaan Tiket Konser</h2>
      <div class="flex flex-row justify-end gap-2 items-start">
        <div class="flex flex-row gap-2 w-16 shrink-0 items-start">
          <div class="font-Plus_Jakarta_Sans text-white">Filter</div>
          <img src="~/public/icons/filteralt.svg"/>
        </div>
        
          <!-- Kategori -->
          <div class="relative w-[146px]">
            <div class="flex flex-col justify-center mr-2 gap-8 items-center px-3 py-2 rounded-lg" style="position: relative; z-index: 1; border: 1px solid rgba(255, 255, 255, 0.2);">
              <button @click="toggleKategoriSearch" class="block flex items-center h-[14px] w-48 focus:outline-none focus:border-none active:outline-none active:border-none">
                <div class="font-Plus_Jakarta_Sans text-white text-start flex items-center">
                  <div class="flex text-center ml-[25px] ">
                    <span style="min-width: 100px;">{{ selectedKategori || "Kategori" }}</span>
                    <img src="~/public/icons/select.svg" class="ml-3" alt="Select Icon" />
                  </div>
                </div>
              </button>
              <div v-if="isKategoriOpen" class="py-2 w-[137px] h-[210px] -mt-7 rounded-lg overflow-hidden" style="z-index: 2; solid rgba(255, 255, 255, 0.2);">
                <ul>
                  <li v-for="(item, index) in KategoriOptions" :key="index" class="block px-4 py-2 hover:bg-black hover:bg-black-100 rounded-lg" @click="selectKategori(item)">{{ item }}</li>
                </ul>
              </div>
            </div>
          </div>
      
          <!-- CSR -->
          <div class="relative w-[146px]">
            <div class="flex flex-col justify-center mr-2 gap-8 items-center px-3 py-2 rounded-lg" style="position: relative; z-index: 1; border: 1px solid rgba(255, 255, 255, 0.2);">
              <button @click="togglecsrSearch" class="block flex items-center h-[14px] w-48 focus:outline-none focus:border-none active:outline-none active:border-none">
                <div class="font-Plus_Jakarta_Sans text-white text-start flex items-center">
                  <div class="flex text-center ml-[25px] ">
                    <span style="min-width: 100px;">{{ selectedcsr || "CSR" }}</span>
                    <img src="~/public/icons/select.svg" class="ml-3" alt="Select Icon" />
                  </div>
                </div>
              </button>
              <div v-if="isCSROpen" class="py-2 w-[137px] h-[210px] -mt-7 rounded-lg overflow-hidden" style="z-index: 2; solid rgba(255, 255, 255, 0.2);">
                <ul>
                  <li v-for="(item, index) in csrOptions" :key="index" class="block px-4 py-2 hover:bg-black hover:bg-black-100 rounded-lg" @click="selectcsr(item)">{{ item }}</li>
                </ul>
              </div>
            </div>
          </div>
        
       <!-- Search -->
        <div class="border-solid border-white/20 bg-[#242424] flex flex-row justify-center gap-12 h-8 items-center px-3 py-2 border rounded-lg">
          <div class="font-Plus_Jakarta_Sans text-white/50">
            <input
              type="text"
              id="Cari"
              class="font-Plus_Jakarta_Sans text-white/50 bg-transparent border-none outline-none"
              placeholder="Cari Lelang/Tiket"/>
          </div>
          <img class="w-20px h-20px" src="~/public/icons/search.svg"/>
        </div>
        
      </div>
    </div>
  </div>
</div>
 

</template>

<script setup></script>

<style scoped>
.fixed-content-width {
  width: 1209px;
}

.active {
  border-radius: 8px;
  background: var(--Gold-100, linear-gradient(98deg, #FFD849 0%, #FFC937 26.68%, #FFE88C 54.39%, #FFD546 94.58%));
  color: #222831;
}

</style>


<script>
export default {
  data() {
    return {
      isKategoriOpen: false,
      selectedKategori: "",
      KategoriOptions: ["Kategori", "Barang Artis", "Pusaka", "Teknologi", "Fashion", "Tiket"],
      isCSROpen: false,
      selectedcsr: "",
      csrOptions: ["CSR", "Kesehatan", "Lingkungan", "Budaya" , "Ekonomi"],
      activeTab: 1
    };
  },
  methods: {
    toggleKategoriSearch() {
      this.isKategoriOpen = !this.isKategoriOpen;
    },
    togglecsrSearch() {
      this.isCSROpen = !this.isCSROpen;
    },
    selectKategori(item) {
      this.selectedKategori = item;
    },
    selectcsr(item) {
      this.selectedcsr = item;
    },
    changeTab(tabNumber) {
      this.activeTab = tabNumber; // Fungsi untuk mengubah tab yang aktif saat tombol di klik
    },
  }
};
</script>


