<template>
<div class="w-full h-max flex justify-between fixed-content-width">
<div><Sidebar/></div>
  
 <div class="flex flex-row justify-between w-full items-center ml-5 mr-3 mt-7">
    <div class="self-start flex flex-col items-start">
      <div class="text-3xl font-Plus_Jakarta_Sans font-semibold">
        Dashboard
      </div>
      <div class="font-Plus_Jakarta_Sans text-inherit-50">
        Tempat dimana anda dapat melihat data secara realtime.
      </div>
    </div>

    <!-- Search -->
    <div class="flex flex-row items-center gap-4 -mt-[985px] -mr-[289px]">
      <div class="border-solid border-white/20 bg-[#242424] flex flex-row gap-4 w-[413px] shrink-0 h-12 items-center px-4 border rounded-lg">
        <img src="~/public/icons/search.svg" class="w-6 h-6" alt="Search Icon" />
        <input
          type="text"
          id="Cari"
          class="font-Plus_Jakarta_Sans text-white/50 bg-transparent border-none outline-none"
          placeholder="Cari"
        />
      </div>

      <!-- Notifikasi -->
      <div class="border-solid border-white/20 bg-[#242424] flex flex-col justify-center w-12 shrink-0 h-12 items-center border rounded-lg">
        <img src="~/public/icons/notifications.svg"/>
      </div>
    </div>  
  </div>

</div>

<!-- Content -->
<div id="LelangMasuk" class="flex flex-row -mt-[61rem] ml-[18rem] gap-4 fixed-content-width">
<div class="shadow-md overflow-hidden bg-[#cd475c] flex flex-row justify-between gap-24 h-[85px] w-[288px] items-center p-6 rounded-lg">
  <div class="flex flex-col items-start">
    <div class="text-3xl font-Plus_Jakarta_Sans font-semibold text-white">
      102
    </div>
    <div class="font-Plus_Jakarta_Sans text-white/50">
      Lelang Masuk
    </div>
  </div>
  <img class="self-start w-10" src="~/public/icons/description.svg"/>
</div>

<div id="PesananTiket" class="shadow-md overflow-hidden bg-[#379956] flex flex-row justify-between gap-24 h-[85px] w-[288px] items-center p-6 rounded-lg">
  <div class="flex flex-col items-start ">
    <div class="text-3xl font-Plus_Jakarta_Sans font-semibold text-white">
      38
    </div>
    <div class="font-Plus_Jakarta_Sans text-white/50">
      Pesanan Tiket
    </div>
  </div>
  <img class="self-start w-10" src="~/public/icons/receipt.svg"/>
</div>

<div id="MitraResmiTerdaftar" class="shadow-md overflow-hidden bg-[#2f80ed] flex flex-row justify-between gap-24 h-[85px] w-[288px] items-center p-6 rounded-lg">
  <div class="flex flex-col w-40 items-start">
    <div class="text-3xl font-Plus_Jakarta_Sans font-semibold text-white">
      89
    </div>
    <div class="font-Plus_Jakarta_Sans text-white/50" style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
      Mitra Resmi Terdaftar
    </div>    
  </div>
  <img class="self-start w-10 -ml-[81px]" src="~/public/icons/check.svg"/>
</div>

<div id="CSRTerkumpul" class="shadow-md overflow-hidden bg-[#222831] flex flex-row justify-center gap- h-[85px] w-[288px] items-center p-6 rounded-lg">
  <div class="flex flex-col w-[239px] items-start">
    <div class="text-2xl font-Plus_Jakarta_Sans font-semibold text-white">
      Rp. 22.094.873
    </div>
    <div class="font-Plus_Jakarta_Sans text-white/50">
      CSR Terkumpul
    </div>
  </div>
  <img class="self-start w-10" src="~/public/icons/volunter.svg"/>
</div>
</div>

<div class="flex mt-[20px]">
  <!-- Pesanan Diterima-->
  <div id="PesananDiterima" class="w-984 h-496 rounded-lg ml-[18rem]" style="display: flex; width: 754px; height: 396px; padding: 24px; flex-direction: column; gap: 24px; flex-shrink: 0; background: var(--Dark-Grey-100, #242424);">
  <div style="color: white;">Pesanan Diterima
  </div>
  </div>

  <!-- Kategori -->
  <div id="Kategori" class="w-984 h-496 rounded-lg ml-5 mp-4" style="display: flex; width: 426px; height: 396px; padding: 24px; flex-direction: column; align-items: flex-start; gap: 24px; flex-shrink: 0; background: var(--Dark-Grey-100, #242424); color: white;">Kategori
  </div>
  </div>

  <div class="flex mt-[20px]">
    <!-- Akses cepat Lelang /Tiket -->
    <div id="AksesLelangTiket" class="w-984 h-496 rounded-lg ml-[18rem]" style="display: flex; width: 654px; height: 396px; padding: 24px; flex-direction: column; gap: 24px; flex-shrink: 0; background: var(--Dark-Grey-100, #242424);">
    <div style="color: white;">Akses cepat Lelang /Tiket
    </div>
    </div>
  
    <!-- Akses Cepat Permintaan Mitra  -->
    <div id="AksesPermintaanMitra" class="w-984 h-496 rounded-lg ml-5 mp-4" style="display: flex; width: 526px; height: 396px; padding: 24px; flex-direction: column; align-items: flex-start; gap: 24px; flex-shrink: 0; background: var(--Dark-Grey-100, #242424); color: white;">Akses Cepat Permintaan Mitra 
    </div>
    </div>

</template>

<script></script>

<style scoped>
.fixed-content-width {
  width: 1209px;
}
</style>