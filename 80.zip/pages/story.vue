<script lang="ts" setup></script>

<template>
  <main class="px-60 2xl:px-48 xl:px-40 sm:px-4">
    <!-- Header and Picture -->
    <div class="relative header">
      <div>
        <h1 class="font-bold text-primary">
          Cerita Dari Artis Kesayangan
        </h1>
        <h2>
          Lihat ceritanya sekarang!
        </h2>
      </div>
      <img src="/img/story.svg" alt="Story" class="absolute top-0 right-0 bg-img sm:hidden" style="z-index: -1;">
    </div>

    <!-- Content -->
    <section class="mt-32 xl:mt-24 sm:mt-8 flex flex-col gap32">
      <!-- Search -->
      <label class="flex relative search">
        <input type="text" placeholder="Cari cerita yang kamu inginkan"
          class="rounded-lg w-full shadow-32 py-4 pr-6 xl:py-3 pl-14 xl:pl-10 text-[19px] 2xl:text-base xl:text-sm sm:text-xs leading-tight bg-white dark:bg-darkGrey-100 placeholder:text-inherit-50">
        <nuxt-icon name="search" class="absolute text24 top-1/2 -translate-y-1/2 left-4 xl:left-3" />
      </label>

      <!-- Newest story -->
      <div>
        <h3 class="font-bold text24">Semua Cerita</h3>
        <p class="mt-2 xl:mt-1 text16">Semua cerita ada di sini</p>
      </div>
      <div class="flex flex-gap32">
        <CardStory />
        <CardStory />
        <CardStory />
      </div>
        

      <!-- <div class="flex gap32">
        <CardStory />
        <CardStory />
        <CardStory />
      </div> -->

      <!-- <div>
        <h3 class="font-bold text-24">Semua Cerita</h3>
        <p class="mt-2 xl:mt-1 text-16">Semua cerita ada di sini</p>
    </div>
    <div class="flex flex-col lg:flex-row lg:flex-wrap gap-32 lg:justify-end">
        <CardStory class="w-full lg:w-3/3 lg:order-first" />
        <CardStory class="w-full lg:w-3/3" />
        <CardStory class="w-full lg:w-3/3" />
    </div> -->


    </section>
  </main>
</template>

<style scoped>
.header {
  font-size: 56px;
  line-height: normal;
}

.bg-img {
  width: 25vw;
}

.search {
  width: 30.7vw;
}

@media (max-width: 1600px) {
  .header {
    font-size: 45px;
  }
}

@media (max-width: 1400px) {
  .header {
    font-size: 40px;
  }
}

@media (max-width: 639px) {
  .header {
    font-size: 22px;
  }

  .search {
    width: 80vw;
  }
}
</style>

<style>
  @media (max-width: 767px) {
    .flex-gap32 {

      flex-direction: column;
    }
  }
</style>
