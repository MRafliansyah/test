<!-- <script lang="ts" setup>
const authStore = useAuthStore();
const showPilihan = ref(false);
var pilihantiket = "BuatLelangBaru"
var pilihantiket = "BuatTiketKonserBaru"
</script> -->

<template>
  <div class="bg-beige p-4 xl:p-3 flex flex-col gap-8 xl:gap-5 shadow-32 rounded-lg mt-4 min-w-fit cursor-default" style="z-index: 1;" >
    <div class="flex flex-col gap-4 xl:gap-3">
      <p class="font-bold text-xl xl:text-base text-dark-100">Profil</p>
      <p class="py-3 xl:py-2 px-4 xl:px-3 xl:text-xs text-dark-100"><NuxtLink to="/Menu/EditAkun">Ubah Informasi Profil</NuxtLink></p>
      <p class="py-3 xl:py-2 px-4 xl:px-3 xl:text-xs text-dark-100">Ubah Password</p>
    </div>

    <div class="spacer"></div>

    <!-- Lelang -->
    <div class="flex flex-col gap-4 xl:gap-3">
      <p class="font-bold text-xl xl:text-base text-dark-100">Lelang/Tiket</p>
      <p class="py-3 xl:py-2 px-4 xl:px-3 xl:text-xs text-dark-100" @click="showDf1">daftar Menjadi Partner HO</p>

    <!-- Informasi 1 -->
    <div v-if="Df1" class="notification">
            <ModalsOverlay>
              <div class="dark:bg-darkGrey-100 bg-white flex flex-col justify-between gap-8 w-[400px] h-[529px] items-start p-6 rounded-lg font-Plus_Jakarta_Sans dark:text-white text-black">
                <div class="text-xl font-bold">
                  Informasi
                </div>

                <div class="flex items-center justify-center ml-14">
                  <img class="sm:w-[150px] w-[185px]" src="~/public/icons/undraw.svg" alt="Gambar" />
                </div>

                <div class="w-full -mt-6">
                  Untuk membuat lelang baru, Anda harus terdaftar sebagai Artis atau Instansi yang melakukan lelang/penjualan tiket.
                  <br />
                  <br />
                  Silahkan tekan daftar di bawah untuk melanjutkan pembuatan lelang!
                </div>

                <div class="flex flex-row justify-between ml-4 w-full items-start">
                  <button class="bg-transparant self-start flex flex-col justify-center pl-8 w-[150px] h-10 cursor-pointer items-start rounded-lg -ml-4">
                    <div class="text-lg font-bold flex" @click="hideDf1">
                      Kembali
                    </div>
                  </button>

                  <button class="btn-confirm bg-[linear-gradient(98deg,_#ffd849_-8%,#ffc937_30%,#ffe88c_69%,#ffd546_125%)] bg-cover bg-50%_50% bg-blend-normal text-dark-100 self-start flex flex-col justify-center w-[150px] h-10 cursor-pointer items-center rounded-lg mr-4" @click="showDf2">
                    <div class="text-lg font-bold">
                      Daftar
                    </div>
                  </button>
                </div>
              </div>
            </ModalsOverlay>
    </div>
      
    <!-- Daftar 2 -->
    <div v-if="Df2" class="notification">
    <ModalsOverlay>
          <div class="dark:bg-darkGrey-100 bg-white flex flex-col justify-center gap-2 w-[506px] h-[700px] items-start p-[40px] rounded-lg font-Plus_Jakarta_Sans">
            <div class="flex flex-row ml-1 gap-4 w-1/5 items-start">
              <img src="https://file.rendit.io/n/SPIXnjmnmvgGaQDykDp2.svg" alt="KeyboardArrowLeft" class="w-6" />
              <div class="text-lg dark:text-white text-black" @click="hideDf2">Kembali</div>
            </div>
            <div class="flex flex-col justify-between gap-4 w-full items-start">
              <div class="flex flex-col w-full">
                <div class="text-center text-2xl font-bold dark:text-white text-black">
                  Daftar Lelang Disini!
                </div>
                <div class="text-center text-1xl w-full dark:text-white text-black">
                  Isi form dibawah ini untuk mendaftar sebagai mitra lelang/penjual tiket konser.
                </div>
              </div>
              <div class="flex flex-col justify-between gap-4 w-full items-start">
                <div class="flex flex-row gap-4 w-3/4 items-start">
                  <div id="Ellipse" class="bg-[url(https://file.rendit.io/n/LyM4XHAWZmDoPUiVFl5X.png)] bg-cover bg-50%_50% bg-blend-normal bg-no-repeat flex flex-row justify-end w-20 h-20 items-start">
                    <div class="shadow-[0px_0px_16px_0px_rgba(34,_40,_49,_0.24)] bg-[linear-gradient(98deg,_#ffd849_-8%,#ffc937_30%,#ffe88c_69%,#ffd546_125%)] bg-cover bg-50%_50% bg-blend-normal bg-no-repeat flex flex-row mt-16 w-8 h-8 items-start pt-1 px-1 rounded-[41px]">
                      <img src="https://file.rendit.io/n/NR4Kyz5qYy9dsbYZzzz8.svg" alt="ModeEdit" id="ModeEdit" class="w-6" />
                    </div>
                  </div>
                  
                </div>
                <div class="dark:text-white text-black mt-2">
                  Nama Artis/Agensi
                </div>

                <div class=" -mt-2 border-solid border-white/20 bg-[#090909] flex flex-row gap-4 w-full h-12 items-start pt-3 px-4 border rounded-lg">
                  <img src="~/public/icons/account.svg"/>
                  <input type="text" placeholder="Nama Artis/Agensi" class="text-lg sm:text-sm bg-transparent border-none outline-none w-full" />
                </div>
                
                <div class="text-xs text-inherit-50 -mt-2">
                  *Nama akan digunakan sebagai nama profile pelaku lelang/penjual tiket.
                </div>
                <div class="dark:text-white text-black">
                  Email Artis/Agensi
                </div>
                <div id="EmailInput" class="-mt-2 border-solid border-white/20 bg-[#090909] flex flex-row gap-4 w-full h-12 items-start pt-3 px-4 border rounded-lg">
                  <img src="~/public/icons/email.svg"/>

                  <input type="text" placeholder="Email Artis/Agensi" class="text-lg sm:text-sm bg-transparent border-none outline-none w-full" />

                </div>
                <div class="text-xs text-inherit-50 -mt-2">
                  *Pastikan email yang didaftarkan adalah email aktif!
                </div>
                <div class="dark:text-white text-black">
                  Nomor Telepon Artis/Agensi
                </div>
                <div id="TeleponInput" class="-mt-2 border-solid border-white/20 bg-[#090909] flex flex-row gap-4 w-full h-12 items-start pt-3 px-4 border rounded-lg">
                  <div class="flex flex-row gap-2 w-10 items-start">
                    <div class="text-lg text-white">
                      +62
                    </div>
                  </div>
                  
                  <input type="text" placeholder="No. Tlp" class="text-lg sm:text-sm bg-transparent border-none outline-none w-full" />
                </div>
                <div class="text-xs text-white/50 -mt-2">
                  *Pastikan nomor yang didaftarkan adalah nomor aktif!
                </div>
              </div>
            </div>

          <div class="flex gap-2 justify-center -mt-">
          
              <button class="btn-confirm bg-primary p-2 xl:p-4 font-bold rounded-lg text-sm xl:text-base dark:text-dark-100 w-[426px] h-[44px] text-[16px]" style="font-family:'Plus Jakarta Sans', sans-serif; transition: background-color 0.3s; display: flex; align-items: center; justify-content: center;" @click="showDf3">
                Daftar
              </button>
          </div>
          </div>
    </ModalsOverlay>
    </div>

    <!-- Konfirmasi 3 -->
    <div v-if="Df3" class="notification">
    <ModalsOverlay>
      <div class="dark:bg-darkGrey-100 bg-white flex flex-col justify-between gap-8 w-[400px] h-[480px] items-start p-6 rounded-lg font-Plus_Jakarta_Sans dark:text-white text-black">
        <div class="text-xl font-bold">
          Konfirmasi
        </div>

        <div class="flex items-center justify-center ml-5">
          <img class="sm:w-[205px] w-[300px]" src="~/public/icons/undraw1.png" alt="Gambar" />
        </div>

        <div class="w-full -mt-6">
          Apakah anda yakin ingin menjadi partner untuk melakukan lelang? Tim HistoryOutlet akan menghubungi pihak terkait untuk melanjutkan registrasi.
        </div>

        <div class="flex flex-row justify-between ml-4 w-full items-start">
          <button class="bg-transparant self-start flex flex-col justify-center w-[150px] h-10 cursor-pointer items-center rounded-lg mr-4">
            <div class="text-lg font-bold" @click="hideDf3">
            Tidak
            </div>
          </button>
          <button class="btn-confirm bg-[linear-gradient(98deg,_#ffd849_-8%,#ffc937_30%,#ffe88c_69%,#ffd546_125%)] bg-cover bg-50%_50% bg-blend-normal text-dark-100 self-start flex flex-col justify-center w-[150px] h-10 cursor-pointer items-center rounded-lg mr-4" @click="showDf4">
            <div class="text-lg font-bold">
              Ya
            </div>
          </button>
        </div>
      </div>
    </ModalsOverlay>
    </div>

    <!-- Konfirmasi 4 -->
    <div v-if="Df4" class="notification">
    <ModalsOverlay>
      <div class="dark:bg-darkGrey-100 bg-white flex flex-col justify-between gap-8 w-[400px] h-[480px] items-start p-6 rounded-lg font-Plus_Jakarta_Sans dark:text-white text-black">
        <div class="text-xl font-bold">
          Konfirmasi
        </div>

        <div class="flex items-center justify-center ml-12">
          <img class="sm:w-[150px] w-[185px]" src="~/public/icons/undraw.svg" alt="Gambar" />
        </div>

        <div class="w-full -mt-6">
          Apakah anda yakin ingin menjadi partner untuk melakukan lelang? Tim HistoryOutlet akan menghubungi pihak terkait untuk melanjutkan registrasi.
        </div>

        <div class="flex flex-row justify-between ml-4 w-full items-start">

          <button class="bg-transparant self-start flex flex-col justify-center w-[150px] h-10 cursor-pointer items-center rounded-lg mr-4">
            <div class="text-lg font-bold" @click="hideDf4">
            Tidak
            </div>
          </button>

          <button class="btn-confirm bg-[linear-gradient(98deg,_#ffd849_-8%,#ffc937_30%,#ffe88c_69%,#ffd546_125%)] bg-cover bg-50%_50% bg-blend-normal text-dark-100 self-start flex flex-col justify-center w-[150px] h-10 cursor-pointer items-center rounded-lg mr-4" @click="hideDf4">
            <div class="text-lg font-bold">
              Ya
            </div>
          </button>
        </div>
      </div>
    </ModalsOverlay>
    </div>

      <!-- <PopUpDaftarmitra :bid="bids"/> -->
      <p  @click="showTiketlelang = true" class="py-3 xl:py-2 px-4 xl:px-3 xl:text-xs text-dark-100">Buat Lelang/Tiket
        Konser Baru</p>

  <!-- Konfirmasi-->    
  <div v-if="showTiketlelang" class="notification">
    <ModalsOverlay>
      <div class="bg-[#242424] flex flex-col gap-3 w-[676px] h-[604px] items-start p-16 rounded-lg font-['Plus_Jakarta_Sans']">
        <div class="flex flex-row gap-4 items-start mb-6 ml-1">
          <img src="~/public/icons/keyboardarrowleft.svg" />
          <div @click="hideTiketlelang" class="text-lg text-white">Kembali</div>
        </div>
        <div class="text-center text-3xl font-bold text-white">
          Pilih Lelang/Tiket Konser
        </div>
        <div class="text-center text-2xl text-white self-center mb-5 w-full">
          Pilih salah satu layanan dibawah ini untuk melanjutkan penjualan barang Lelang atau Tiket Konser
        </div>
        <div class="text-white mb-1">
          Pilih Tipe Penjualan
        </div>
        <div class="flex flex-col relative">
          <div @click="toggleRotation('animated-image2')" style="position: relative;">
            <div class="border-2 border-white/20 rounded-lg bg-black-100 absolute w-[550px]">
              <div class="px-4">
                <div @click="togglepilihSearch" style="position: relative;">
                  <button class="block h-[56px] w-48 focus:outline-none focus:border-white flex items-center" style="overflow: hidden; white-space: nowrap;">
                    <div class="text-white-50 sm:text-sm text-lg">{{ selectedOption || "Pilih Tipe" }}</div>
                  </button>
                </div>
              </div>
              <div class="px-3">
                <div class="absolute top-0 right-0 mt-[1rem] mr-[1rem]">
                  <img @click="toggleRotation('animated-image2')" src="~/public/icons/select.svg" id="animated-image2">
                </div>
              </div>
              <div v-if="isOpenpilih">
                <ul>
                  <li v-for="(item, index) in pilihOptions" :key="index" class="block px-4 py-2 text-white hover-bg-dark-100" @click="selectpilih(item)">{{ item }}</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="text-xs text-white/50 self-center mb-5 w-full mt-16">
          *Pastikan anda memilih ‘Lelang’ untuk melakukan pelelangan barang, dan memilih ‘Tiket Konser’ untuk menjual Tiket Konser!
        </div>
        <NuxtLink :to="generateLink(selectedOption)">
          <button @click="hideTiketlelang" class="btn-confirm bg-[linear-gradient(98deg,_#ffd849_-8%,#ffc937_30%,#ffe88c_69%,#ffd546_125%)] bg-cover bg-50%_50% bg-blend-normal p-2 xl-p-4 font-bold rounded-lg dark-text-dark-100" style="font-family: 'Plus Jakarta Sans', sans-serif; font-size: 24px; width: 548px; height: 58px; transition: background-color 0.3s; display: flex; align-items; center; justify-content: center;">Buat Baru</button>
        </NuxtLink>
      </div>
    </ModalsOverlay>
  </div>  
        
     <!-- penjualan saya -->
      <p class="py-3 xl:py-2 px-4 xl:px-3 xl:text-xs text-dark-100">
        <NuxtLink to="/Menu/PenjualanSaya">Lihat Penjualan Saya</NuxtLink>
      </p>
    </div>

    <div class="spacer"></div>

    <div class="flex flex-col gap-4 xl:gap-3">
      <p class="font-bold text-xl xl:text-base text-dark-100">Transaksi</p>
      <p class="py-3 xl:py-2 px-4 xl:px-3 xl:text-xs text-dark-100">
        <NuxtLink to="/Menu/Transaksi">Lihat Transaksi</NuxtLink>
      </p>
    </div>

    <div class="spacer"></div>

    <!-- Saldo -->
    <div class="flex flex-col gap-4 xl:gap-3">
      <p class="font-bold text-xl xl:text-base text-dark-100">Saldo</p>
      <div class="flex py-3 xl:py-2 px-4 xl:px-3 gap-4 xl:gap-3 min-w-max justify-between">
        <div class="flex gap-4 xl:gap-3">
          <nuxt-icon name="e_wallet" class="text-xl xl:text-base text-dark-100" />
          <p class="text-dark-100 xl:text-xs">Saldo Utama</p>
        </div>
        <p class="text-dark-100 font-bold ml-4 xl:text-xs">Rp {{ userData.saldo.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.')}}</p>
      </div>
      <div class="flex py-3 xl:py-2 px-4 xl:px-3 gap-4 xl:gap-3 justify-between">
        <div class="flex gap-4 xl:gap-3">
          <nuxt-icon name="verified" class="text-xl xl:text-base text-dark-100" />
          <p class="text-dark-100 xl:text-xs">Reward</p>
        </div>
        <p class="text-dark-100 font-bold xl:text-xs">8.898</p>
      </div>
    </div>

    <div class="spacer"></div>

    <!-- Setting -->
    <div class="flex flex-col gap-4 xl:gap-3">
      <p class="font-bold text-xl xl:text-base text-dark-100">Pengaturan</p>
      <div class="flex gap-4 xl:gap-3 py-3 xl:py-2 px-4 xl:px-3 cursor-pointer items-center">
        <nuxt-icon name="logout" class="text-xl xl:text-base text-red-100" />
        <p @click="authStore.logout" class="text-red-100 xl:text-xs">Logout</p>
      </div>
    </div>
  </div>



</template>

<style>
.spacer { 
  border: 1px solid rgba(34, 40, 49, 0.2);
}
  .btn-confirm:hover {
    --dark: #222831;
    background: var(--dark);
    transition: background-color 0.3s;
    color: white;
  }

  .notification {
    position: fixed;
  }
</style>

<!-- <script lang="ts">
export default {
  data() {
    return {
      selectedOption: null,
      isOpenpilih: false,
      pilihOptions: ["Lelang", "Tiket Konser"],
      showTiketlelang: false,

      // bids: {
      //   Daftar1: false,
      //   Daftar2: false,
      //   Daftar3: false,
      //   Daftar4: false,
      //   Daftar5: false,
      // }, 
      // Daftar1: false,
      // Daftar2: false,
      // Daftar3: false
    };
  },
  
  methods: {
    selectpilih(item) {
      this.selectedOption = item;
      this.isOpenpilih = false;
    },
    generateLink(selectedOption) {
      if (selectedOption === "Lelang") {
        return "/menu/buatlelangbaru";
      } else if (selectedOption === "Tiket Konser") {
        return "/menu/buattiketkonserbaru";
      } else {
        return selectedOption === "Buat Lelang Baru"
          ? "/menu/buatlelangbaru"
          : "";
      }
    },
    toggleRotation(iconId) {
      const image = document.getElementById(iconId);
      const currentRotation = image.style.transform || 'rotate(0deg)';
      const isRotated = currentRotation === 'rotate(180deg)';

      if (isRotated) {
        image.style.transform = 'rotate(0deg)';
      } else {
        image.style.transform = 'rotate(180deg)';
      }
    },
    togglepilihSearch() {
      this.isOpenpilih = !this.isOpenpilih;
    },
    hideTiketlelang() {
      this.showTiketlelang = false;
    },
    confirmAction() {
      this.showTiketlelang = false;
    },

    showDaftar1() {
      this.bids.Daftar1 = true;
    },
    showDaftar2() {
      this.Daftar2 = true;
    }, 
    showDaftar3() {
      this.Daftar2 = true;
    }, 
    hideDaftar1() {
      this.Daftar1 = false;
    }, 
    hideDaftar1() {
      this.Daftar1 = false;
    }, 
  },
};

  </script> -->

  <script setup>
  import { ref } from 'vue';
  import { getData, setData } from 'nuxt-storage/local-storage';

  const userData = ref(JSON.parse(getData('userData')));
  console.log(userData)

  watchEffect(() => {
    const storedUserData = JSON.parse(getData('userData'));
    if (storedUserData) {
      userData.value = storedUserData;
      console.log(userData)
    }
  });
  
  const selectedOption = ref(null);
  const isOpenpilih = ref(false);
  const pilihOptions = ["Lelang", "Tiket Konser"];
  const showTiketlelang = ref(false);
  
 // Df daftar parther HO
    const Df1= ref(false);
    const Df2= ref(false);
    const Df3= ref(false);
    const Df4= ref(false);

    const showDf1 = () => {
      Df1.value = true; 
    };
    const showDf2 = () => {
      Df1.value = false;
      Df2.value = true;
    };
    const showDf3 = () => {
      Df2.value = false;
      Df3.value = true;
    };
    const showDf4 = () => {
      Df1.value = false;
      Df4.value = true;
    };

    const hideDf1 = () => {
      Df1.value = false;
    };
    const hideDf2 = () => {
      Df2.value = false;
    };
    const hideDf3 = () => {
      Df3.value = false;
    };
    const hideDf4 = () => {
      Df4.value = false;
    };
  
  function selectpilih(item) {
    selectedOption.value = item;
    isOpenpilih.value = false;
  }
  
  function generateLink(selectedOption) {
    if (selectedOption === "Lelang") {
      return "/menu/buatlelangbaru";
    } else if (selectedOption === "Tiket Konser") {
      return "/menu/buattiketkonserbaru";
    } else {
      return selectedOption === "Buat Lelang Baru"
        ? "/menu/buatlelangbaru"
        : "";
    }
  }
  
  function toggleRotation(iconId) {
    const image = document.getElementById(iconId);
    const currentRotation = image.style.transform || 'rotate(0deg)';
    const isRotated = currentRotation === 'rotate(180deg)';
  
    if (isRotated) {
      image.style.transform = 'rotate(0deg)';
    } else {
      image.style.transform = 'rotate(180deg)';
    }
  }
  
  function togglepilihSearch() {
    isOpenpilih.value = !isOpenpilih.value;
  }
  
  function hideTiketlelang() {
    showTiketlelang.value = false;
  }
  
  function confirmAction() {
    showTiketlelang.value = false;
  }
  </script>
