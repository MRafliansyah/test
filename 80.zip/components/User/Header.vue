<script setup>
import { ref, watchEffect } from 'vue';
import { getData, setData } from 'nuxt-storage/local-storage';

const userMenu = ref(false);
const userData = ref(JSON.parse(getData('userData')));
console.log(userData)

watchEffect(() => {
  const storedUserData = JSON.parse(getData('userData'));
  if (storedUserData) {
    userData.value = storedUserData;
    console.log(userData)
  }
});
</script>
<template>
  <!-- {{ userData }} -->
  <div class="flex gap-4 xl:gap-3 items-center text-dark-100 relative">
    <nuxt-icon name="shopping_cart"
      class="text-xl xl:text-base p-[6px] xl:p-1 cursor-pointer border-solid border border-dark-20 rounded-lg" />
    <nuxt-icon name="bell"
      class="text-xl xl:text-base p-[6px] xl:p-1 cursor-pointer border-solid border border-dark-20 rounded-lg" />
    <div @click="userMenu = !userMenu" class="flex gap-4 xl:gap-3 cursor-pointer items-center">
      <img src="/img/user.png" alt="User" class="w-9 xl:w-6">
      <p class="font-semibold xl:text-sm select-none text-gold-100">{{ userData ? userData.nama :"_"}}</p>
      <UserMenu v-show="userMenu" @click.stop="" class="absolute top-full" />
    </div>
  </div>
</template>

<style scoped></style>
