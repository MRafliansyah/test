<script lang="ts" setup></script>

<template>
  <div class="defaultfooter mt-52 xl:mt-36 px-60 2xl:px-48 xl:px-40 py-24 2xl:py-16 sm:p-4 bg-dark-100 dark:bg-darkGrey-100">
    <!-- Nav Wrapper -->
    <div class="flex justify-between">
      <!-- Nav -->
      <div class="column-wrapper">
        <h3>Navigasi</h3>
        <p>Beranda</p>
        <p>Lelang Terbaru</p>
        <p>Favorit</p>
      </div>
      <div class="column-wrapper">
        <h3>Tentang</h3>
        <p><NuxtLink to="/footer/aboutUs">Tentang Kami</NuxtLink></p>
        <p>Kontak Kami</p>
        <p><NuxtLink to="/footer/faq">FAQ</NuxtLink></p>
      </div>
      <div class="column-wrapper sm:hidden">
        <h3>Filter</h3>
        <p>Barang Bekas Artis</p>
        <p>Pusaka</p>
        <p>Benda Bersejarah</p>
        <p>Teknologi</p>
        <p>Fashion</p>
        <p>Tiket Konser</p>
      </div>
      <div class="column-wrapper">
        <h3>Anekaragam</h3>
        <p>About Us</p>
        <p>Contact Us</p>
        <p><NuxtLink to="/footer/faq">FAQ</NuxtLink></p>
      </div>
      <div class="column-wrapper">
        <h3>Sosial</h3>
        <p>Twitter</p>
        <p>Facebook</p>
        <p>Instagram</p>
        <p>Linkedin</p>
      </div>
    </div>

    <h4>Copyright &copy; 2023 History Outlet. All rights reserved.</h4>
  </div>
</template>

<style scoped>
.column-wrapper {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
  flex-grow: 1;
}
h3 {
  cursor: default;
  font-weight: 700;
  color: white;
}
h4 {
  color: white;
  margin-top: 72px;
}
p {
  color: rgba(255, 255, 255, .5);
  &:hover {
    color: white;
    cursor: pointer;
  }
}

@media (max-width: 1600px) {
  .column-wrapper {
    font-size: 12px;
    gap: 1rem;
  }
  h4 {
    font-size: 14px;
    margin-top: 51px;
  }
}

@media (max-width: 639px) {
  .column-wrapper {
    font-size: 8px;
    gap: .7rem;
  }
  h4 {
    font-size: 12px;
    margin-top: 48px;
  }
}
</style>
