<template>
  <!-- Informasi 1 -->
<div v-if="Df1" class="notification">
  <ModalsOverlay>
    <div class="dark:bg-darkGrey-100 bg-white flex flex-col justify-between gap-8 w-[400px] h-[529px] items-start p-6 rounded-lg font-Plus_Jakarta_Sans dark:text-white text-black">
      <div class="text-xl font-bold">
        Informasi
      </div>

      <div class="flex items-center justify-center ml-14">
        <img class="sm:w-[150px] w-[185px]" src="~/public/icons/undraw.svg" alt="Gambar" />
      </div>

      <div class="w-full -mt-6">
        Untuk membuat lelang baru, Anda harus terdaftar sebagai Artis atau Instansi yang melakukan lelang/penjualan tiket.
        <br />
        <br />
        Silahkan tekan daftar di bawah untuk melanjutkan pembuatan lelang!
      </div>

      <div class="flex flex-row justify-between ml-4 w-full items-start">
        <button class="bg-transparant self-start flex flex-col justify-center pl-8 w-[150px] h-10 cursor-pointer items-start rounded-lg -ml-4">
          <div class="text-lg font-bold flex" @click="hideDf1">
            Kembali
          </div>
        </button>

        <button class="btn-confirm bg-[linear-gradient(98deg,_#ffd849_-8%,#ffc937_30%,#ffe88c_69%,#ffd546_125%)] bg-cover bg-50%_50% bg-blend-normal text-dark-100 self-start flex flex-col justify-center w-[150px] h-10 cursor-pointer items-center rounded-lg mr-4" @click="showDf2">
          <div class="text-lg font-bold">
            Daftar
          </div>
        </button>
      </div>
    </div>
  </ModalsOverlay>
</div>
  
<!-- Daftar 2 -->
<div v-if="Df2" class="notification">
<ModalsOverlay>
      <div class="dark:bg-darkGrey-100 bg-white flex flex-col justify-center gap-2 w-[506px] h-[700px] items-start p-[40px] rounded-lg font-Plus_Jakarta_Sans">
        <div class="flex flex-row ml-1 gap-4 w-1/5 items-start">
          <img src="https://file.rendit.io/n/SPIXnjmnmvgGaQDykDp2.svg" alt="KeyboardArrowLeft" class="w-6" />
          <div class="text-lg dark:text-white text-black" @click="hideDf2">Kembali</div>
        </div>
        <div class="flex flex-col justify-between gap-4 w-full items-start">
          <div class="flex flex-col w-full">
            <div class="text-center text-2xl font-bold dark:text-white text-black">
              Daftar Lelang Disini!
            </div>
            <div class="text-center text-1xl w-full dark:text-white text-black">
              Isi form dibawah ini untuk mendaftar sebagai mitra lelang/penjual tiket konser.
            </div>
          </div>
          <div class="flex flex-col justify-between gap-4 w-full items-start">
            <div class="flex flex-row gap-4 w-3/4 items-start">
              <div id="Ellipse" class="bg-[url(https://file.rendit.io/n/LyM4XHAWZmDoPUiVFl5X.png)] bg-cover bg-50%_50% bg-blend-normal bg-no-repeat flex flex-row justify-end w-20 h-20 items-start">
                <div class="shadow-[0px_0px_16px_0px_rgba(34,_40,_49,_0.24)] bg-[linear-gradient(98deg,_#ffd849_-8%,#ffc937_30%,#ffe88c_69%,#ffd546_125%)] bg-cover bg-50%_50% bg-blend-normal bg-no-repeat flex flex-row mt-16 w-8 h-8 items-start pt-1 px-1 rounded-[41px]">
                  <img src="https://file.rendit.io/n/NR4Kyz5qYy9dsbYZzzz8.svg" alt="ModeEdit" id="ModeEdit" class="w-6" />
                </div>
              </div>
              
            </div>
            <div class="dark:text-white text-black mt-2">
              Nama Artis/Agensi
            </div>

            <div class=" -mt-2 border-solid border-white/20 bg-[#090909] flex flex-row gap-4 w-full h-12 items-start pt-3 px-4 border rounded-lg">
              <img src="~/public/icons/account.svg"/>
              <div id="Username" class="text-lg text-white/50">
                Nama Artis/Agensi
              </div>
              <input type="text" placeholder="Nama Artis/Agensi" class="text-lg sm:text-sm bg-transparent border-none outline-none w-full" />
            </div>
            
            <div class="text-xs text-inherit-50 -mt-2">
              *Nama akan digunakan sebagai nama profile pelaku lelang/penjual tiket.
            </div>
            <div class="dark:text-white text-black">
              Email Artis/Agensi
            </div>
            <div id="EmailInput" class="-mt-2 border-solid border-white/20 bg-[#090909] flex flex-row gap-4 w-full h-12 items-start pt-3 px-4 border rounded-lg">
              <img src="~/public/icons/email.svg"/>

              <div id="Email1" class="text-lg text-white/50">
                Email Artis/Agensi
              </div>

              <input type="text" placeholder="Email Artis/Agensi" class="text-lg sm:text-sm bg-transparent border-none outline-none w-full" />

            </div>
            <div class="text-xs text-inherit-50 -mt-2">
              *Pastikan email yang didaftarkan adalah email aktif!
            </div>
            <div class="dark:text-white text-black">
              Nomor Telepon Artis/Agensi
            </div>
            <div id="TeleponInput" class="-mt-2 border-solid border-white/20 bg-[#090909] flex flex-row gap-4 w-full h-12 items-start pt-3 px-4 border rounded-lg">
              <div class="flex flex-row gap-2 w-10 items-start">
                <div class="text-lg text-white">
                  +62
                </div>
                <img src="https://file.rendit.io/n/SiENY79qNngV7HQVJDa5.svg" alt="Line" id="Line" class="w-0" />
              </div>
              <div class="text-lg text-white/50">
                No. Tlp
              </div>
              <input type="text" placeholder="No. Tlp" class="text-lg sm:text-sm bg-transparent border-none outline-none w-full" />
            </div>
            <div class="text-xs text-white/50 -mt-2">
              *Pastikan nomor yang didaftarkan adalah nomor aktif!
            </div>
          </div>
        </div>

       <div class="flex gap-2 justify-center -mt-">
      
          <button class="btn-confirm bg-primary p-2 xl:p-4 font-bold rounded-lg text-sm xl:text-base dark:text-dark-100 w-[426px] h-[44px] text-[16px]" style="font-family:'Plus Jakarta Sans', sans-serif; transition: background-color 0.3s; display: flex; align-items: center; justify-content: center;" @click="showDf3">
            Daftar
          </button>
      </div>
      </div>
</ModalsOverlay>
</div>

<!-- Konfirmasi 3 -->
<div v-if="Df3" class="notification">
<ModalsOverlay>
  <div class="dark:bg-darkGrey-100 bg-white flex flex-col justify-between gap-8 w-[400px] h-[480px] items-start p-6 rounded-lg font-Plus_Jakarta_Sans dark:text-white text-black">
    <div class="text-xl font-bold">
      Konfirmasi
    </div>

    <div class="flex items-center justify-center ml-5">
      <img class="sm:w-[205px] w-[300px]" src="~/public/icons/undraw1.png" alt="Gambar" />
    </div>

    <div class="w-full -mt-6">
      Apakah anda yakin ingin menjadi partner untuk melakukan lelang? Tim HistoryOutlet akan menghubungi pihak terkait untuk melanjutkan registrasi.
    </div>

    <div class="flex flex-row justify-between ml-4 w-full items-start">
      <button class="bg-transparant self-start flex flex-col justify-center w-[150px] h-10 cursor-pointer items-center rounded-lg mr-4">
        <div class="text-lg font-bold" @click="hideDf3">
         Tidak
        </div>
      </button>
      <button class="btn-confirm bg-[linear-gradient(98deg,_#ffd849_-8%,#ffc937_30%,#ffe88c_69%,#ffd546_125%)] bg-cover bg-50%_50% bg-blend-normal text-dark-100 self-start flex flex-col justify-center w-[150px] h-10 cursor-pointer items-center rounded-lg mr-4" @click="showDf4">
        <div class="text-lg font-bold">
          Ya
        </div>
      </button>
    </div>
  </div>
</ModalsOverlay>
</div>

<!-- Konfirmasi 4 -->
<div v-if="Df4" class="notification">
<ModalsOverlay>
  <div class="dark:bg-darkGrey-100 bg-white flex flex-col justify-between gap-8 w-[400px] h-[480px] items-start p-6 rounded-lg font-Plus_Jakarta_Sans dark:text-white text-black">
    <div class="text-xl font-bold">
      Konfirmasi
    </div>

    <div class="flex items-center justify-center ml-12">
      <img class="sm:w-[150px] w-[185px]" src="~/public/icons/undraw.svg" alt="Gambar" />
    </div>

    <div class="w-full -mt-6">
      Apakah anda yakin ingin menjadi partner untuk melakukan lelang? Tim HistoryOutlet akan menghubungi pihak terkait untuk melanjutkan registrasi.
    </div>

    <div class="flex flex-row justify-between ml-4 w-full items-start">

      <button class="bg-transparant self-start flex flex-col justify-center w-[150px] h-10 cursor-pointer items-center rounded-lg mr-4">
        <div class="text-lg font-bold" @click="hideDf4">
         Tidak
        </div>
      </button>

      <button class="btn-confirm bg-[linear-gradient(98deg,_#ffd849_-8%,#ffc937_30%,#ffe88c_69%,#ffd546_125%)] bg-cover bg-50%_50% bg-blend-normal text-dark-100 self-start flex flex-col justify-center w-[150px] h-10 cursor-pointer items-center rounded-lg mr-4" @click="hideDf4">
        <div class="text-lg font-bold">
          Ya
        </div>
      </button>
    </div>
  </div>
</ModalsOverlay>
</div>


</template>

<script setup>
import { ref } from 'vue';

// Df daftar parther HO
  const Df1= ref(false);
  const Df2= ref(false);
  const Df3= ref(false);
  const Df4= ref(false);

  const showDf1 = () => {
    Df1.value = true; 
  };
  const showDf2 = () => {
    Df1.value = false;
    Df2.value = true;
  };
  const showDf3 = () => {
    Df2.value = false;
    Df3.value = true;
  };
  const showDf4 = () => {
    Df1.value = false;
    Df4.value = true;
  };

  const hideDf1 = () => {
    Df1.value = false;
  };
  const hideDf2 = () => {
    Df2.value = false;
  };
  const hideDf3 = () => {
    Df3.value = false;
  };
  const hideDf4 = () => {
    Df4.value = false;
  };
</script>
