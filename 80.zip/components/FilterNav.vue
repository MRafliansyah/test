<script setup>
const route = useRoute()
const storyRoute = computed(() => route.name.includes('story'));
</script>

<template>
  <div class="flex gap-2 justify-center sm:justify-start border-solid border-b border-dark-20 dark:border-white-20 p-2 2xl:p-1 sm:px-4 overflow-scroll no-scrollbar">
    <Button class="text-inherit-50 hover:text-inherit font-medium text-sm 2xl:text-xs active">
      Semua {{storyRoute? "Cerita" : "Barang"}}
    </Button>
    <Button class="text-inherit-50 hover:text-inherit font-medium text-sm 2xl:text-xs">
      Musisi
    </Button>
    <Button class="text-inherit-50 hover:text-inherit font-medium text-sm 2xl:text-xs">
      Seniman
    </Button>
    <Button class="text-inherit-50 hover:text-inherit font-medium text-sm 2xl:text-xs">
      Olahragawan
    </Button>
    <Button class="text-inherit-50 hover:text-inherit font-medium text-sm 2xl:text-xs">
      Aktris
    </Button>
    <Button class="text-inherit-50 hover:text-inherit font-medium text-sm 2xl:text-xs">
      Negarawan
    </Button>
    <Button v-if="!storyRoute" class="text-inherit-50 hover:text-inherit font-medium text-sm 2xl:text-xs">
      Tiket Konser
    </Button>
  </div>
</template>

<style scoped>
.active {
  color: inherit;
}
</style>
