<script setup>
import { ref } from 'vue';
import { getData, setData } from 'nuxt-storage/local-storage';
const router = useRouter()

const emit = defineEmits([
  'close',
  'register',
  'login'
])
const passwordState = ref(true)
const showPassword = computed(()=>{
  return passwordState.value? "password" : "text"
})

const emailControllerLogin = ref('');
const passwordControllerLogin = ref('');

const loginUser = async () => {
  const email = emailControllerLogin.value;
  const password = passwordControllerLogin.value;
  if(email.value !== "" && password !== ""){
    try {
      const response = await fetch(`https://654d93b6cbc325355741a4c6.mockapi.io/user?email=${email}&password=${password}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      const data = await response.json();

      if (response.ok) {
        const user = data.find(user => user.email === email && user.password === password);
        if (user) {
          const userData = {
            userId: user.userId,
            nama: user.nama,
            email: user.email,
            saldo: user.saldo,
            password: user.password,
            noTelepon: user.noTelepon,
            alamat: user.alamat,
            partner: user.partner,
            // dan seterusnya sesuai dengan data yang ingin disimpan
          };
          
          // localStorage.setItem('userData', JSON.stringify(userData));
          setData('userData', JSON.stringify(userData));
          const authStore = useAuthStore();
          authStore.login();
          console.log('Login successful!');

          // Tampilkan data pengguna ke dalam konsol
          console.log('User Data:', userData);
          emit('close')
          // Lakukan navigasi atau tindakan lain setelah login berhasil
        } else {
          console.log('Login failed. Invalid credentials.');
          // Lakukan sesuatu jika login gagal (mungkin tampilkan pesan kesalahan)
        }
      } else {
        console.error('Failed to fetch user data:', data);
      }
    } catch (error) {
      console.error('Error fetching user data:', error);
      // Tangani kesalahan jika ada masalah dengan koneksi atau permintaan
    }
  } else {
    alert("user & password tidak boleh kosong!")
  }
};
</script>

<template>
  <ModalsOverlay @click.native="emit('close')">
    <div @click.stop="" class="bg-beige p-16 2xl:p-11 rounded-lg modals-container flex flex-col gap32">
      <nuxt-icon @click="emit('close')" name="close" alt="" class="text24 self-end cursor-pointer" filled/>

      <!-- Title and subtitle -->
      <div>
        <h2 class="text-dark-100 text32 font-bold text-center mb-3 2xl:mb-2">Login Disini!</h2>
        <h3 class="text-dark-100 font-normal text24 text-center">Halo bidders... silahkan login di bawah
          untuk melakukan bidding atau transaksi lelangan.</h3>
      </div>

      <!-- Form -->
      <form @submit.prevent="loginUser" class="flex flex-col gap32">
        <!-- Input -->
        <div class="flex flex-col gap16">
          <p class="text16 text-dark-100">Email</p>
          <label class="flex relative">
            <input type="email" placeholder="Email" required v-model="emailControllerLogin"
          class="py-4 pr-4 2xl:py-3 pl-14 2xl:pl-10 rounded-lg font-normal text20 text-dark-100 placeholder:text-dark-50 w-full">
            <nuxt-icon name="email" alt="email"
              class="text24 absolute top-1/2 -translate-y-1/2 left-4 xl:left-3" filled/>
          </label>
          <p class="text16 text-dark-100">Password</p>
          <label class="flex relative">
            <input :type="showPassword" placeholder="Password" required v-model="passwordControllerLogin"
          class="py-4 2xl:py-3 px-14 2xl:px-10 rounded-lg font-normal text20 text-dark-100 placeholder:text-dark-50 w-full">
            <nuxt-icon name="lock" class="text24 absolute top-1/2 -translate-y-1/2 left-4 xl:left-3" filled/>
            <div @click="passwordState = !passwordState" class="absolute right-0 flex items-center justify-center h-full w-14 2xl:w-10 cursor-pointer">
              <nuxt-icon name="eye" class="text24" filled/>
            </div>
          </label>
        </div>

        <p class="text-blue-100 text-lg 2xl:text-sm italic cursor-pointer" @click="emit('register')">Belum punya akun?
          Daftar disini!</p>
          <button type="submit" @click="loginUser" class="py-4 2xl:py-3 bg-yellow-100 text-dark-100 font-bold text24 rounded-lg">
          Login
        </button>
      </form>

      <p class="text-lg 2xl:text-sm text-dark-100 text-center">Atau login menggunakan</p>

      <!-- Social Group -->
      <div class="flex gap16">
        <div class="bg-white flex items-center grow cursor-pointer select-none p-4 2xl:p-3 rounded-lg border-dark-20 border-solid border">
          <img src="~/assets/icons/google.svg" alt="Google Logo" class="w-6 2xl:w-5 xl:w-4 mr-4 2xl:mr-3">
          <p class="text-lg 2xl:text-base xl:text-sm text-dark-50">Google</p>
        </div>
        <div class="bg-white flex items-center grow cursor-pointer select-none p-4 2xl:p-3 rounded-lg border-dark-20 border-solid border">
          <img src="~/assets/icons/facebook.svg" alt="Facebook Logo" class="w-6 2xl:w-5 xl:w-4 mr-4 2xl:mr-3">
          <p class="text-lg 2xl:text-base xl:text-sm text-dark-50">Facebook</p>
        </div>
        <div class="bg-white flex items-center grow cursor-pointer select-none p-4 2xl:p-3 rounded-lg border-dark-20 border-solid border">
          <img src="~/assets/icons/instagram.svg" alt="Instagram Logo" class="w-6 2xl:w-5 xl:w-4 mr-4 2xl:mr-3">
          <p class="text-lg 2xl:text-base xl:text-sm text-dark-50">Instagram</p>
        </div>
      </div>
      
    </div>
  </ModalsOverlay>
</template>

<style scoped>
input {
  border: 1px solid rgba(34, 40, 49, 0.2);
}

.modals-container {
  width: 35.2vw;
}
</style>
