<script setup>
import { ref, computed, defineEmits } from 'vue';

const emit = defineEmits(['close', 'regiserSucces']);

const passwordState = ref(true);
const passwordState2 = ref(true);

const showPassword = computed(() => {
  return passwordState.value ? "password" : "text";
});

const showPassword2 = computed(() => {
  return passwordState2.value ? "password" : "text";
});

const namaController = ref('');
const emailController = ref('');
const passwordController = ref('');
const passwordController2 = ref('');

async function registerUser() {
  const nama = namaController.value;
  const email = emailController.value;
  const password = passwordController.value;
  const password2 = passwordController2.value;
  if (password == password2){
    await addUser(nama, email, password);
  } else {
    alert("password didn't match, please try again")
    passwordController.value = ""
    passwordController2.value = ""
  }
}

async function addUser(nama, email, password) {
  const alamat = '-';
  const saldo = 0;
  const noTelepon = '-';
  const partner = 'belum';
  try {
    const response = await fetch("https://654d93b6cbc325355741a4c6.mockapi.io/user", {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        nama,
        alamat,
        email,
        password,
        // password2,
        saldo,
        noTelepon,
        partner,
      }),
    });

    console.log('Response Status Code:', response.status);
    const responseBody = await response.json();
    console.log('Response Body:', responseBody);

    if (response.status === 201) {
      console.log('User added successfully!');
      // Reset form values after successful addition
      namaController.value = '';
      emailController.value = '';
      passwordController.value = '';
      // passwordController2.value = '';
      emit('regiserSucces')
    } else {
      console.log('Failed to add user.');
    }
  } catch (error) {
    console.error(error);
  }
}
</script>

<template>
  <ModalsOverlay @click.native="emit('close')">
    <div class="bg-beige p-16 2xl:p-8 rounded-lg modals-container flex flex-col gap32" @click.stop="">
      <nuxt-icon @click="emit('close')" name="close" alt="" class="text24 self-end cursor-pointer" filled/>

      <!-- Title and subtitle -->
      <div>
        <h2 class="text-dark-100 text32 font-bold text-center mb-3 2xl:mb-2">
          Daftar Disini!
        </h2>
        <h3 class="text-dark-100 font-medium px-2 text24 text-center">
          Halo bidders... belum punya akun? Silahkan daftar di bawah ini!</h3>
      </div>

      <!-- Form -->
      <form @submit.prevent="registerUser" class="flex flex-col gap32">
        <!-- Input -->
        <div class="flex flex-col gap16">
          <!-- Name -->
          <p class="text16 text-dark-100">Nama</p>
          <label class="flex relative">
            <input type="text" placeholder="Nama Lengkap" required v-model="namaController"
            class="py-3 pr-4 2xl:py-2 pl-14 2xl:pl-10 rounded-lg font-normal text20 text-dark-100 placeholder:text-dark-50 w-full">
            <nuxt-icon name="person" class="text24 absolute top-1/2 -translate-y-1/2 left-4 2xl:left-3" filled/>
          </label>

          <!-- Email -->
          <p class="text16 text-dark-100">Email</p>
          <label class="flex relative">
            <input type="email" placeholder="Email" required v-model="emailController"
  class="py-3 pr-4 2xl:py-2 pl-14 2xl:pl-10 rounded-lg font-normal text20 text-dark-100 placeholder:text-dark-50 w-full">
            <nuxt-icon name="email" class="text24 absolute top-1/2 -translate-y-1/2 left-4 2xl:left-3" filled/>
          </label>

          <!-- Password -->
          <p class="text16 text-dark-100">Password</p>
          <label class="flex relative">
            <input :type="showPassword" placeholder="Password" required v-model="passwordController"
  class="py-3 2xl:py-2 px-14 2xl:px-10 rounded-lg font-normal text20 text-dark-100 placeholder:text-dark-50 w-full">
            <nuxt-icon name="lock" class="text24 absolute top-1/2 -translate-y-1/2 left-4 2xl:left-3" filled />
            <div @click="passwordState = !passwordState"
              class="absolute right-0 flex items-center justify-center h-full w-14 2xl:w-10 cursor-pointer">
              <nuxt-icon name="eye" class="text24" filled />
            </div>
          </label>

          <!-- Retype Password -->
          <p class="text16 text-dark-100">Ulangi Password</p>
          <label class="flex relative">
            <input :type="showPassword2" placeholder="Ulangi Password" required v-model="passwordController2"
  class="py-3 2xl:py-2 px-14 2xl:px-10 rounded-lg font-normal text20 text-dark-100 placeholder:text-dark-50 w-full">
            <nuxt-icon name="lock" class="text24 absolute top-1/2 -translate-y-1/2 left-4 2xl:left-3" filled/>
            <div @click="passwordState2 = !passwordState2"
              class="absolute right-0 flex items-center justify-center h-full w-14 2xl:w-10 cursor-pointer">
              <nuxt-icon name="eye" class="text24" filled/>
            </div>
          </label>
        </div>

        <button class="py-4 2xl:py-3 bg-yellow-100 text-dark-100 font-bold text24 rounded-lg" type="submit">
          Daftar
        </button>
      </form>

      <p class="text-lg 2xl:text-base xl:text-sm text-dark-100 text-center">Atau daftar menggunakan</p>

      <!-- Social Group -->
      <div class="flex gap16">
        <div
          class="bg-white flex items-center grow cursor-pointer select-none p-4 2xl:p-3 rounded-lg border-dark-20 border-solid border">
          <img src="~/assets/icons/google.svg" alt="Google Logo" class="w-6 2xl:w-5 xl:w-4 mr-4 2xl:mr-3">
          <p class="text-lg 2xl:text-base xl:text-sm text-dark-50">Google</p>
        </div>
        <div
          class="bg-white flex items-center grow cursor-pointer select-none p-4 2xl:p-3 rounded-lg border-dark-20 border-solid border">
          <img src="~/assets/icons/facebook.svg" alt="Facebook Logo" class="w-6 2xl:w-5 xl:w-4 mr-4 2xl:mr-3">
          <p class="text-lg 2xl:text-base xl:text-sm text-dark-50">Facebook</p>
        </div>
        <div
          class="bg-white flex items-center grow cursor-pointer select-none p-4 2xl:p-3 rounded-lg border-dark-20 border-solid border">
          <img src="~/assets/icons/instagram.svg" alt="Instagram Logo" class="w-6 2xl:w-5 xl:w-4 mr-4 2xl:mr-3">
          <p class="text-lg 2xl:text-base xl:text-sm text-dark-50">Instagram</p>
        </div>
      </div>
    </div>
  </ModalsOverlay>
</template>

<style scoped>
input {
  border: 1px solid rgba(34, 40, 49, 0.2);
}

.modals-container {
  width: 35.2vw;
}
</style>