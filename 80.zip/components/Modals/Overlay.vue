<template>
  <div class="overlay-container fixed flex items-center justify-center inset-0">
      <slot />
  </div>
</template>

<style scoped>
.overlay-container {
  background-color: rgba(30, 30, 30, 0.3);
  z-index: 2;
}
</style>