<script lang="ts" setup></script>

<template>
  <button class="py-4 2xl:py-3 px-8 2xl:px-[26px] xl:px-6 sm:px-1 rounded-lg">
    <slot />
  </button>
</template>

<style scoped></style>
