<script setup>
const props = defineProps({
  // tiket: Boolean,
  lelang:null,
  tiket:null,
  product:null
})

function toProduct(id) {
  return navigateTo('/product/'+id);
}
function toTicket(id) {

  return navigateTo('/tiket/'+id);
}

</script>

<template>
  <div class="flex flex-col shadow-32 rounded-lg grow cursor-pointer bg-white dark:bg-darkGrey-100 hover:scale-105">
    <!-- Thumbnail w-[235px]-->
    <!-- {{ lelang }} -->
    <!-- {{ product }} -->


    <!-- <div>{{ product && product.recommend ? "Muncul karena true" : "" }}
    <div class="p-2">
      <img :src="`${tiket? tiket.displayPhoto : '/img/sample_makki.png'}`" alt="Sample Photo">
     </div>
    </div> -->

    <div v-if="product && product.recommend" class="shadow-[0px_0px_32px_0px_rgba(34,_40,_49,_0.24)] flex flex-col w-full items-start">
      <div class="bg-[linear-gradient(98deg,_#ffd849_-8%,#ffc937_30%,#ffe88c_69%,#ffd546_125%)] bg-cover bg-50%_50% bg-blend-normal bg-no-repeat flex flex-col gap-2 w-full  pt-2 pb-4 px-2 rounded-tl-lg rounded-tr-lg h-[210px] sm:h-[136px]">
        <div>
          <img class="h-[172px] sm:h-[102px] w-[200px]" :src="`${tiket && tiket.displayPhoto ? tiket.displayPhoto : product.displayPhoto}`" alt="Sample Photo">
        </div>
        <div class="font-['Plus_Jakarta_Sans'] text-[#222831] font-bold text-sm 2xl:text-[11px] leading-tight">
          Recommendation
        </div>
      </div>
    </div>
    <div v-else class="p-2">
      <img :src="`${tiket ? tiket.displayPhoto : '/img/sample_makki.png'}`" alt="Sample Photo">
    </div>
    
    
    <!-- Title -->
    <div class="p-4 xl:p-3 -mt-2">
      <div class="flex items-center gap-2 text-inherit-50">
        <nuxt-icon name="people" class="text-lg 2xl:text-sm" />
        <p class="text-sm 2xl:text-[10px]">{{tiket? tiket.totalParticipant:lelang?lelang.totalParticipant:product?product.totalParticipant:"-"}}</p>
      </div>
      <p class="text-sm 2xl:text-[11px] leading-tight font-bold two-lines">
        {{tiket? tiket.name:lelang?lelang.name:product?product.name:"-"}}
      </p>
      
      
    </div>

    <!-- Detail -->
    <div class="p-4 xl:p-3 border-solid border-t border-dark-20 dark:border-white-20">
      
      <p class="text-sm 2xl:text-xs">{{tiket?'OTS':'Bid'}}: <span class="font-bold">Rp {{ tiket?tiket.hargaOts.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.'):
         
        lelang?lelang.startBid:product?product.startBid.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.'):"-"}}</span></p>
      
      <p class="text-sm 2xl:text-xs">{{tiket?'Online':'Last Bid'}}: <span class="text-green-100 font-bold">Rp {{ tiket?tiket.hargaOnline.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.'): 3900.000}}</span></p>
      
      <p v-if="!tiket" class="text-sm 2xl:text-xs">Bin: <span class="text-red-100 font-bold">Rp. {{ lelang?lelang.bin:product?product.bin.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.'):"-" }}</span></p>


      <div class="flex justify-between mt-2 gap-1">
        <div>
          <p class="text-sm 2xl:text-[11px] leading-tight">Berakhir</p>
          <p class="font-bold text-sm 2xl:text-[11px] leading-tight">{{tiket? tiket.tanggal: lelang?lelang.tanggal:product?product.tanggal:"-"}}</p>
        </div>

        <button @click="tiket ? toTicket(tiket.tiketId) : product?toProduct(product.lelangId):toProduct(lelang.lelangId)" class="bg-primary p12-16 font-bold rounded-lg text16 dark:text-dark-100">
          Lihat {{tiket? 'Detail': 'Lelang'}}!
        </button>
      
      </div>
    </div>
  </div>
</template>

<style scoped>
.two-lines {
  max-height: 2.4em;
  overflow: hidden;
  text-overflow: ellipsis; 
}
</style>
