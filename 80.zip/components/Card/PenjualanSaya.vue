<template>
<div class="dark:bg-darkGrey-100 rounded-lg shadow-32 overflow-hidden h-[277px] sm:h-[189px] sm:w-full w-[700px]">
  <div class="flex">
    <!-- Thumbnail -->
    <div class="flex flex-col py-[32px] px-[32px] sm:py-[12px] sm:px-[12px]">
      <div class="sm:w-[36px] w-[96px]">
        <img src="~/public/img/sample_makki.png" alt="Gambar Makki" />
      </div>
    </div>

    <!-- Content -->
    <div class="flex flex-col py-[32px] sm:py-[11px] sm:ml-[-1px]-ml-3">
      <div class="flex items-center gap-2">
        <p class="text-[16px] leading-tight sm:hidden">Musisi</p>
        <img class="sm:hidden" src="~/public/icons/elipse1.svg" alt="Icon">
        <p class="text-[16px] leading-tight sm:hidden">Lelang</p>
        <img class="sm:hidden" src="~/public/icons/elipse1.svg" alt="Icon">
        <p class="text-green-100 text-[16px] sm:text-[12px] whitespace-nowrap">Transaksi Sukses</p>
        <img src="~/public/icons/elipse1.svg" alt="Icon" />
        <div class="bg-[rgba(255,181,99,0.2)] flex flex-col w-24 h-auto text-center">
          <div class="text-[12px] sm:text-[12px] font-['Plus_Jakarta_Sans'] text-[#ffb563] whitespace-nowrap">
            Belum Dikirim
          </div>
        </div>

      </div>

      <!-- Detail -->
      <div class="flex flex-col mt-1 xl:flex-row xl:items-center">
        <div class="flex-1">
          <!-- <p class="text-[20px] sm:text-[16px] leading-tight font-bold whitespace-nowrap">
            {{ Transaksi ? "Bass Putih Makki Omar Parikesit" : "Tiket Konser Ungu" }}
          </p> -->
          <p class="text-[20px] sm:text-[14px] leading-tight font-bold">{{Transaksi ? "Tiket Konser Ungu" : "Bass Putih Makki Omar Parikesit"}}</p>

          <p class="text-[15px] sm:text-[12px] leading-tight py-1 text-inherit-50">Total Dilihat: <span class="font-bold">100</span></p>

        </div>
      </div>
      <div class="flex flex-col xl:flex-row xl:items-center">
        <div class="flex-1">
          <p class="text-[20px] sm:text-[14px]">
            {{ Transaksi ? 'Bid' : 'Last Bid' }}: <span class="text-green-100 font-bold">Rp. 3.900.000</span>
          </p>
          <div class="py-1">
              <p class="text-[14px] sm:text-[12px] leading-tight">Status: <span class="font-bold">Publish/Draft</span></p>
            </div>
        </div>
      </div>
    </div>
  </div>

  <div class="sm:mt-3">
    <div class="flex flex-row justify-end items-center font-['Plus_Jakarta_Sans'] font-bold text-inherit-50 text-[16px] sm:text-[12px] mr-5">
      <button class="flex flex-col justify-center items-center ml-5 w-[82px] h-[44px] sm:w-[62px] sm:h-[29px] mx-4 sm:-mx-5 border border-white rounded-lg sm:mr-1">
        <span>Hapus</span>
      </button>

      <button class="btn-confirm bg-primary ml-5 rounded-lg w-[163px] h-[44px] sm:w-[97px] sm:h-[29px]">
        <div class="text-[#222831] hover:text-white mx-4" @click="showEditLelang1 = true">
          <span>Edit Lelang</span>
        </div>
      </button>
    </div>
  </div>
</div>

      
 <!-- Konfirmasi 1-->
<div v-if="showEditLelang1" class="EditLelang">
  <ModalsOverlay>
    <div class="w-10px h-10px rounded-lg flex flex-col gap-32 ml-4 text-white" style="background-color: var(--Dark-Grey-100, #242424); font-family: 'Plus Jakarta Sans', sans-serif; rounded-lg">
      <div class="h-[469px] w-[400px] sm:h-[365px] sm:w-[280px]">
        <h2 class="font-bold py-4 px-6 text-[16px] sm:text-[12px]">Konfirmasi</h2>
        <div class="flex items-center justify-center mt-[30px]">
          <img class="sm:w-[205px] w-[300px]" src="~/public/icons/undraw1.png" alt="Gambar" />
        </div>
        <p class="px-6 sm:mt-[15px] mt-[20px] text-[16px] sm:text-[12px]">
          Apakah anda ingin menghubungi pihak HO? Anda dapat melakukan custom order ataupun bertemu dengan artis secara langsung. 
        </p>
        <div class="flex mt-[26px] sm:mt-[1rem] gap-2 justify-center">
          <div>
            <button class="font-bold w-[168px] h-[44px] sm:w-[110px] sm:h-[30px] text-[16px] sm:text-[12px]" style="font-family: 'Plus Jakarta Sans', sans-serif; transition: background-color 0.3s; display: flex; align-items: center; justify-content: center;" @click="hideEditLelang1">
              Tidak
            </button>
          </div>
          <div>
            <button class="btn-confirm bg-primary p-2 xl:p-4 font-bold rounded-lg text-sm xl:text-base dark:text-dark-100 w-[168px] h-[44px] sm:w-[110px] sm:h-[24px] text-[16px] sm:text-[12px]" style="font-family:'Plus Jakarta Sans', sans-serif; transition: background-color 0.3s; display: flex; align-items: center; justify-content: center;" @click="confirmAction">
              Ya
            </button>
          </div>
        </div>
      </div>
    </div>
  </ModalsOverlay>
</div>

<!-- Konfirmasi   2  -->
<div v-if="showEditLelang2" class="EditLelang">
  <ModalsOverlay>
    <div class="w-10px h-8px rounded-lg flex flex-col gap-32 ml-4" style="background-color: var(--Dark-Grey-100, #242424); font-family: 'Plus Jakarta Sans', sans-serif; font-size: 16px;">
      <div class="h-[469px] w-[400px] sm:h-[365px] sm:w-[280px]">
        <h2 class="font-bold py-4 px-6 text-[16px] sm:text-[12px]">Konfirmasi</h2>

        <div class="flex items-center justify-center mt-[30px] sm:mt-[20px]">
          <img class="sm:w-[150px] w-[185px]" src="~/public/icons/undraw.svg" alt="Gambar" />
        </div>

        <p class="sm:mt-[15px] mt-[20px] px-6 text-[16px] sm:text-[12px]">
          Silahkan tekan tombol Whatsapp dibawah untuk berkomunikasi lebih lanjut, atau hubungi 0898-9893-9090.
        </p>
        <div class="flex mt-[26px] sm:mt-[1rem] gap-2 justify-center">
          <div>
            <button class="font-bold w-[168px] h-[44px] sm:w-[110px] sm:h-[30px] text-[16px] sm:text-[12px]" style="font-family: 'Plus Jakarta Sans', sans-serif; transition: background-color 0.3s; display: flex; align-items: center; justify-content: center;" @click="hideEditLelang2">
              Tidak
            </button>
          </div>
          <div>
            <button class="btn-confirm bg-primary p-2 xl:p-4 font-bold rounded-lg text-sm xl:text-base dark:text-dark-100 w-[168px] h-[44px] sm:w-[124px] sm:h-[30px] text-[16px] sm:text-[12px]" style="font-family: 'Plus Jakarta Sans', sans-serif; transition: background-color 0.3s; display: flex; align-items: center; justify-content: center;" @click="confirmAction">
              Buka Whatsapp
            </button>
          </div>
        </div>
      </div>
    </div>
  </ModalsOverlay>
</div>
</template>


<style scoped>
.EditLelang {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 1000;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(0, 0, 0, 0.5);
}
</style>

<script lang="ts">
  import { ref } from 'vue'; 
    
  export default {
  data() {
    return {
      showEditLelang1: false,
      showEditLelang2: false,
    };
  },
  methods: {
    
    hideEditLelang1() {
      this.showEditLelang1= false;
    },
    confirmAction() {
      this.showEditLelang2 = true;
      this.showEditLelang1 = false;
    },
    hideEditLelang2() {
      this.showEditLelang2 = false;
    },
  },
};
  </script>

