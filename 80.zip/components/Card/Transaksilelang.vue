<script setup>
import { ref, onMounted } from 'vue';
import axios from 'axios';
import { getData, setData } from 'nuxt-storage/local-storage';

const userMenu = ref(false);
// const userData = ref(null);
const userData = ref(JSON.parse(getData('userData')));
console.log(userData)

const HHO1= ref(false);
const HHO2= ref(false);

// HHO
  const showHHO1 = () => {
    HHO1.value = true; 
  };
  const showHHO2 = () => {
    HHO1.value = false;
    HHO2.value = true;
  };

  const hideHHO1 = () => {
    HHO1.value = false;
  };
  const hideHHO2 = () => {
    HHO2.value = false;
    HHO1.value = true;
  };

const LelangT = ref(null); 

const fetchLelangTs = async () => {
  try {
    const response = await axios.get('https://6550a40f7d203ab6626e02b9.mockapi.io/lelangTransaksi/');
    LelangT.value = response.data.filter(e => {return parseInt(e.userId) == parseInt(userData.value.userId)});
  } catch (error) {
    console.error('Error fetching LelangT:', error);
    // Handle error (e.g., set a flag for displaying an error message)
  }
};

onMounted(fetchLelangTs);
</script>

<template>
<!-- {{ userData }} -->
<!-- {{ LelangT }}  -->
 <div v-for="lelang, index in LelangT">
    <!-- {{ lelang }} -->
 <!-- kalah lelang -->
    <div v-if="!lelang.hasil" class="dark:bg-darkGrey-100 rounded-lg shadow-32 overflow-hidden h-[160px] sm:h-[90px] sm:w-full w-[700px]">
      <div class="flex">
        <div class="flex flex-col py-[32px] px-[32px] sm:py-[12px] sm:px-[12px]">
          <div class="sm:w-[36px] w-[96px]">
            <img src="~/public/img/sample_makki.png" alt="Gambar Makki" />
          </div>
        </div>
    
        <!-- Content -->
        <div class="flex flex-col py-[32px] sm:py-[8px] sm:ml-[-1px] -ml-3">
          <div class="flex items-center gap-2">
            <p class="text-[16px] sm:text-[12px] leading-tight sm:hidden">Musisi</p>
            <img class="sm:hidden" src="~/public/icons/elipse1.svg" alt="Icon" />
            <p class="text-[16px] leading-tight sm:hidden">Lelang</p>
            <img class="sm:hidden" src="~/public/icons/elipse1.svg" alt="Icon" />
            <p class="text-red-100 text-[16px] sm:text-[12px] whitespace-nowrap">Kalah Lelang</p>
          </div>
    
          <!-- Detail -->
          <div class="flex flex-col mt-1 xl:flex-row xl:items-center">
            <div class="flex-1">
              <p class="text-[20px] sm:text-[14px] leading-tight font-bold whitespace-nowrap">
                {{lelang ? lelang.namaLelang : "Tiket Konser Ungu"}}
              </p>
            </div>
          </div>
          <div class="flex flex-col mt-1 xl:flex-row xl:items-center">
            <div class="flex-1">
              <p class="text-[20px] sm:text-[14px]">
                {{lelang ? "Last "+lelang.caraMenang.substr(lelang.caraMenang.length - 3) : ''}}: <span class="text-red-100 font-bold">Rp {{ lelang.totalDibayar.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.') }}</span>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <!-- menang lelang -->
    <div v-else class="dark:bg-darkGrey-100 rounded-lg shadow-32 overflow-hidden h-[230px] sm:h-[140px] sm:w-full w-[700px]">
      <div class="flex">
        <!-- Thumbnail -->
        <div class="flex flex-col py-[32px] px-[32px] sm:py-[12px] sm:px-[12px]">
          <div class="sm:w-[36px] w-[96px]">
            <img src="~/public/img/sample_makki.png" alt="Gambar Makki" />
          </div>
        </div>
    
        <!-- Content -->
        <div class="flex flex-col py-[32px] sm:py-[8px] sm:ml-[-1px]-ml-3">
          <div class="flex items-center gap-2">
            <p class="text-[16px] leading-tight sm:hidden">Musisi</p>
            <img class="sm:hidden" src="~/public/icons/elipse1.svg" alt="Icon">
            <p class="text-[16px] leading-tight sm:hidden">Lelang</p>
            <img class="sm:hidden" src="~/public/icons/elipse1.svg" alt="Icon">
            <p class="text-green-100 text-[16px] sm:text-[12px] whitespace-nowrap">Menang Lelang</p>
            <img src="~/public/icons/elipse1.svg" alt="Icon" />
            <div class="bg-[rgba(255,181,99,0.2)] flex flex-col w-25 h-auto text-center">
              <div class="text-[16px] sm:text-[12px] font-['Plus_Jakarta_Sans'] text-[#ffb563] whitespace-nowrap">
                Belum Dikirim
              </div>
            </div>
          </div>
    
          <!-- Detail -->
          <div class="flex flex-col mt-1 xl:flex-row xl:items-center">
            <div class="flex-1">
              <p class="text-[20px] sm:text-[16px] leading-tight font-bold whitespace-nowrap">
                {{lelang ? lelang.namaLelang : "Tiket Konser Ungu"}}
              </p>
            </div>
          </div>
          <div class="flex flex-col mt-1 xl:flex-row xl:items-center">
            <div class="flex-1">
              <p class="text-[20px] sm:text-[16px]">
                {{lelang ? "Last "+lelang.caraMenang.substr(lelang.caraMenang.length - 3) : ''}}: <span class="text-red-100 font-bold">Rp {{lelang.totalDibayar.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.')}}</span>
              </p>
            </div>
          </div>
        </div>
      </div>
    
      <div class="sm:mt-3">
        <div class="flex flex-row justify-end items-center font-['Plus_Jakarta_Sans'] font-bold text-inherit-50 text-[16px] sm:text-[12px] mr-5">
          <button class="flex flex-col justify-center items-center ml-5 w-[152px] h-[44px] sm:w-[90px] sm:h-[24px] mx-4 sm:-mx-5">
            <NuxtLink :to="`/Menu/Transaksi/${lelang.lelangTransaksiId.toString()}`">
            <span class="hidden sm:inline">Detail</span>
              <span class="sm:hidden">Detail Transaksi</span>
            </NuxtLink>
          </button>
    
          <button class="HHO ml-5 rounded-lg w-[208px] h-[44px] sm:w-[103px] sm:h-[24px]">
            <div class="text-[#222831] mx-4" @click="showHHO1">
              <span class="hidden sm:inline">Hubungi HO</span>
              <span class="sm:hidden">Hubungi HistoryOutlet</span>
            </div>
          </button>
        </div>
      </div>
    </div>
    
  </div>
        
   <!-- Konfirmasi 1-->
  <div v-if="HHO1" class="notification">
    <ModalsOverlay>
      <div class="w-10px h-10px rounded-lg flex flex-col gap-32 ml-4 text-white" style="background-color: var(--Dark-Grey-100, #242424); font-family: 'Plus Jakarta Sans', sans-serif; rounded-lg">
        <div class="h-[469px] w-[400px] sm:h-[365px] sm:w-[280px]">
          <h2 class="font-bold py-4 px-6 text-[16px] sm:text-[12px]">Konfirmasi</h2>
          <div class="flex items-center justify-center mt-[30px]">
            <img class="sm:w-[205px] w-[300px]" src="~/public/icons/undraw1.png" alt="Gambar" />
          </div>
          <p class="px-6 sm:mt-[15px] mt-[20px] text-[16px] sm:text-[12px]">
            Apakah anda ingin menghubungi pihak HO? Anda dapat melakukan custom order ataupun bertemu dengan artis secara langsung. 
          </p>
          <div class="flex mt-[26px] sm:mt-[1rem] gap-2 justify-center">
            <div>
              <button class="font-bold w-[168px] h-[44px] sm:w-[110px] sm:h-[30px] text-[16px] sm:text-[12px]" style="font-family: 'Plus Jakarta Sans', sans-serif; transition: background-color 0.3s; display: flex; align-items: center; justify-content: center;"  @click="hideHHO1">
                Tidak
              </button>
            </div>
            <div>
              <button class="btn-confirm bg-primary p-2 xl:p-4 font-bold rounded-lg text-sm xl:text-base dark:text-dark-100 w-[168px] h-[44px] sm:w-[110px] sm:h-[24px] text-[16px] sm:text-[12px]" style="font-family:'Plus Jakarta Sans', sans-serif; transition: background-color 0.3s; display: flex; align-items: center; justify-content: center;" @click="showHHO2">
                Ya
              </button>
            </div>
          </div>
        </div>
      </div>
    </ModalsOverlay>
  </div>
  
  <!-- Konfirmasi   2  -->
  <div v-if="HHO2" class="notification">
    <ModalsOverlay>
      <div class="w-10px h-8px rounded-lg flex flex-col gap-32 ml-4" style="background-color: var(--Dark-Grey-100, #242424); font-family: 'Plus Jakarta Sans', sans-serif; font-size: 16px;">
        <div class="h-[469px] w-[400px] sm:h-[365px] sm:w-[280px]">
          <h2 class="font-bold py-4 px-6 text-[16px] sm:text-[12px]">Konfirmasi</h2>

          <div class="flex items-center justify-center mt-[30px] sm:mt-[20px]">
            <img class="sm:w-[150px] w-[185px]" src="~/public/icons/undraw.svg" alt="Gambar" />
          </div>

          <p class="sm:mt-[15px] mt-[20px] px-6 text-[16px] sm:text-[12px]">
            Silahkan tekan tombol Whatsapp dibawah untuk berkomunikasi lebih lanjut, atau hubungi 0898-9893-9090.
          </p>
          <div class="flex mt-[26px] sm:mt-[1rem] gap-2 justify-center">
            <div>
              <button class="font-bold w-[168px] h-[44px] sm:w-[110px] sm:h-[30px] text-[16px] sm:text-[12px]" style="font-family: 'Plus Jakarta Sans', sans-serif; transition: background-color 0.3s; display: flex; align-items: center; justify-content: center;" @click="hideHHO2">
                Tidak
              </button>
            </div>
            <div>
              <button class="btn-confirm bg-primary p-2 xl:p-4 font-bold rounded-lg text-sm xl:text-base dark:text-dark-100 w-[168px] h-[44px] sm:w-[124px] sm:h-[30px] text-[16px] sm:text-[12px]" style="font-family: 'Plus Jakarta Sans', sans-serif; transition: background-color 0.3s; display: flex; align-items: center; justify-content: center;">
                Buka Whatsapp
              </button>
            </div>
          </div>
        </div>
      </div>
    </ModalsOverlay>
  </div>
  </template>
  
  
<style scoped>
.notification {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 1000;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(0, 0, 0, 0.5);
}

.HHO {
  border-radius: 8px;
  background: var(--Gold-100, linear-gradient(98deg, #FFD849 0%, #FFC937 26.68%, #FFE88C 54.39%, #FFD546 94.58%));
  color: #222831;
}
</style>
  
<!-- <script lang="ts">
  import { ref } from 'vue'; 
    
  export default {
  data() {
    return {
      showConfirmation: false,
      showConfirmation2: false,
    };
  },
  methods: {
    
    hideConfirmation() {
      this.showConfirmation = false;
    },
    confirmAction() {
      this.showConfirmation2 = true;
      this.showConfirmation = false;
    },
    hideConfirmation2() {
      this.showConfirmation2 = false;
    },
  },
};
</script> -->
