<script lang="ts" setup></script>

<template>
<div class="flex flex-col shadow-32 rounded-lg grow cursor-pointer dark:bg-darkGrey-100 ml-5 mt-5 sm:mr-4">
 
    <div id="Heading" class="flex flex-row gap-3 shrink-0 items-center pb-4 px-4 rounded-tl-lg rounded-tr-lg -mt-2">
    <img class="mt-6" src="/img/Ungu.png" alt="User img">
    <div class="flex flex-col gap-1 items-start">
      <div class="text-xl font-['Plus_Jakarta_Sans'] font-bold  mt-6">
        UNGU
      </div>
      <div class="font-['Plus_Jakarta_Sans']">
        Verified Owner
      </div>
    </div>
    <img id="checkcircle" class="mt-14" src="~/public/icons/story/checkcircle.svg"/>
</div>

    <!-- img -->
    <!-- <div class="bg-[url(~/public/img/makkiomar.png)] bg-cover bg-50%_50% bg-blend-normal bg-no-repeat flex flex-col justify-end h-[284px] shrink-0 items-end pr-2 py-2 sm:w-[298px] sm:h-[190px] md:w-[298px] md:h-[190px] lg:w-[280px] lg:h-[180px] xl:h-[200px] 2xl:h-[216px]"> -->
      <div class="bg-[url(~/public/img/makkiomar.png)] bg-cover bg-50%_50% bg-blend-normal bg-no-repeat flex flex-col justify-end h-[284px] shrink-0 items-end pr-2 py-2 w-full h-[284px] sm:h-[200px] 2xl:h-[px]">


      <div id="Fav" class="bg-[#090909] flex flex-col w-8 h-8 shrink-0 items-center py-1 rounded-[50px] ">
          <img id="Fav" src="~/public/icons/story/fav.svg"/>
      </div>
  </div>
  


    <!-- Button like and share -->  
    <div id="Bottom" class="flex flex-row gap-2 shrink-0 items-center px-4 mt-4">

      <div class="flex items-center mr-12">
          <img id="Favorite" src="~/public/icons/story/like.svg" class="mr-2">
          <div class="text-lg font-['Plus_Jakarta_Sans'] font-medium">
              984
          </div>
      </div>
  
      <div class="flex items-center mr-16">
          <img id="Favorite" src="~/public/icons/story/group.svg" class="mr-2">
          <div class="text-lg font-['Plus_Jakarta_Sans'] font-medium">
              589
          </div>
      </div>
      <img id="Share" class="ml-2" src="~/public/icons/story/share.svg">
  </div>
  
  


    <!-- Story -->
    <div class="p-4 mt-30" style="font-family: 'Plus Jakarta Sans'; font-size: 16px; font-style: normal; font-weight: 400; line-height: normal;">
      Makki Omar Parikesit (lahir 23 Oktober 1971) adalah Bassis dan pendiri Ungu yang didirikan pada tahun 1996.
      <br />
      <br />
      Saat sedang mengambil gelar di Indiana University, Amerika Serikat, Makki memperkaya kemampuan bermusiknya dengan bermain bersama sebuah band yang bernama Joint Session, yang selain menjadi band keliling di sekitar Midwest, juga merupakan band pembuka beberapa konser grup musik ternama seperti Toad the Wet Sprocket dan John Mellencamp.
      <br />
      <br />
      Kembali ke Jakarta tahun 1996, Makki sempat bergabung dengan Harris Ioni dan beberapa sesi in-promptu sampai akhirnya membentuk UNGU.
    </div>
  </div>
</template>




<style scoped></style>
