import { ref, onBeforeUnmount } from "vue";

export const useCurrentTime = () => {
  const Counter = ref(new Date());
  const updateCurrentTime = () => {
    Counter.value = new Date();
  };
  const updateTimeInterval = setInterval(updateCurrentTime, 1000);
  onBeforeUnmount(() => {
    clearInterval(updateTimeInterval);
  });
  return {
    Counter,
  };