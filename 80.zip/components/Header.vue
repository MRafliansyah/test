<template>
  <div class="defaultheader flex items-center justify-between px-60 xl:px-40 sm:p-4 border-b border-solid border-dark-20 dark:border-white-20">
    
    <!-- Logo -->
    <img src="/img/logo.png" alt="Logo" class="my-6 2xl:my-4 w-[156px] 2xl:w-[126px] xl:w-28 sm:hidden">

    <!-- Navigation -->
    <div class="flex items-center gap-8 xl:gap-5 sm:gap-2">
      <NuxtLink to="/" class="text24 font-bold text-inherit-50 hover:text-inherit">
        Beranda
      </NuxtLink>
      <div class="spacer bg-dark-20 dark:bg-white-20"></div>
      <NuxtLink to="/story" class="text24 font-bold text-inherit-50 hover:text-inherit">
        Cerita
      </NuxtLink>
      <div class="spacer bg-dark-20 dark:bg-white-20"></div>
      <NuxtLink to="/favorite" class="text24 font-bold text-inherit-50 hover:text-inherit">
        Favorit
      </NuxtLink>
    </div>

    <!-- Login and Register -->
    <div v-if="!authStore.loginStatus" class="flex sm:hidden">
      <Button class="text-inherit-50 hover:text-inherit mr-4 font-bold text16" @click="modalLogin = true">Login</Button>
      <Button class="bg-primary text-dark-100 font-bold text16" @click="modalRegister = true">Daftar</Button>
    </div>

    <!-- User Header -->
    <div v-else>
      <UserHeader />
    </div>

    <!-- Modal Login and Register -->
    <ModalsLogin v-if="modalLogin" @close="modalLogin = false" @register="showRegister" @login="login" />
    <ModalsRegister v-if="modalRegister" @close="modalRegister = false" @regiserSucces="toLogin" />

  </div>
</template>

<script lang="ts" setup>
const modalLogin = ref(false)
const modalRegister = ref(false)
const authStore = useAuthStore();

const showRegister = () => {
  modalLogin.value = false
  modalRegister.value = true
}
const login = () => {
  authStore.login();
  modalLogin.value = false
}
const toLogin = () => {
  console.log("kadieu")
  modalRegister.value = false
  modalLogin.value = true
}
</script>

<style scoped>
.router-link-active {
  color: inherit;
}
.spacer {
  width: 8px;
  height: 8px;
  border-radius: 50%;
}

@media (max-width: 1400px) {
  .spacer {
    width: 6px;
    height: 6px;
  }
}

@media (max-width: 639px) {
  .spacer {
    width: 2px;
    height: 2px;
  }
}
</style>