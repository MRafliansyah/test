<script lang="ts" setup></script>

<template>
  <button class="p12-16 rounded-lg">
    <slot />
  </button>
</template>

<style scoped>
</style>
