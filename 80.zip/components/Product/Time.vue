<script lang="ts" setup></script>

<template>
  <div class="p-3 2xl:p-[10px] xl:p-2 bg-dark-100 rounded-lg w-[52px] 2xl:w-[42px] xl:w-[37px] text-white font-bold text32 text-center">
    <slot />
  </div>
</template>

<style scoped></style>
