<script lang="ts" setup></script>

<template>
  <div class="flex gap32 py-4 2xl:py-3 justify-between items-center border-solid border-y border-dark-20">
    <!-- Artist -->
    <div class="flex flex-col">
      <p class="text32 font-bold">50%</p>
      <p class="text16">Komisi Artis</p>
    </div>

    <div class="flex flex-col">
      <p class="text32 font-bold">30%</p>
      <p class="text16">Galang Dana CSR</p>
    </div>

    <div class="flex flex-col">
      <p class="text32 font-bold">20%</p>
      <p class="text16">Komisi History Outlet</p>
    </div>

    <!-- Icon -->
    <nuxt-icon name="info" class="text24 cursor-pointer" @click="showConfirmation6 = true" />
  </div>

  <!-- Informasi 6-->
<div v-if="showConfirmation6" class="notification">
  <ModalsOverlay>
    <div class="dark:bg-darkGrey-100 bg-white flex flex-col justify-between w-[400px] h-[434px] sm:w-[280px] sm:h-[330px] p-6 rounded-lg">
      <div class="text-[16px] sm:text-[12px] font-bold self-start">Informasi</div>
      <div class="font-['Plus_Jakarta_Sans'] self-center w-full text-[16px] sm:text-[12px]">
        Persenan yang ditampilkan adalah komposisi hasil pembagian hasil lelang.
        Hasil lelang akan dibagikan kepada instansi yang dipilih berdasarkan
        persetujuan dari pemilik barang dan penyedia layanan, berikut adalah CSR
        yang dipilih oleh pihak terkait.
      </div>
      <div class="flex flex-col gap-4 items-start">
        <div class="text-[18px] sm:text-[16px] font-bold text-white">CSR Donasi Air Bersih</div>
        <div class="self-stretch flex flex-row gap-2 items-start">
          <div class="font-boldtext-[16px] sm:text-[12px]">30%</div>
          <div class="text-inherit-50 w-5/6 text-[16px] sm:text-[12px]">
            Hasil 30% dari komisi penjualan akan diarahkan kepada bala bantuan Air
            Bersih.
          </div>
        </div>
      </div>
      <div class="flex mt-[26px] sm:mt-[1rem] gap-2 justify-center"  @click="hideConfirmation6">
        <button class="btn-confirm bg-primary p-2 xl:p-4 font-bold rounded-lg text-sm xl:text-base dark:text-dark-100 w-[350px] h-[44px] sm:w-[230px] sm:h-[30px] text-[16px] sm:text-[12px]" style="font-family: 'Plus Jakarta Sans', sans-serif; transition: background-color 0.3s; display: flex; align-items: center; justify-content: center;">
          OK
        </button>
    </div>
    </div>
  </ModalsOverlay>
</div>
</template>

<style scoped>
.notification {
  position: fixed;
}
</style>

<script>
export default {
  data() {
    return {
      showConfirmation6: false,
    };
  },
  methods: {
    confirmAction6() {
      this.showConfirmation6 = true;
      this.showConfirmation6 = false;
    },
    hideConfirmation6() {
      this.showConfirmation6 = false;
    },
    
  }
};

</script>