<script setup>
const props = defineProps({
  // tiket: Boolean,
  description :null
})
const activeTab = ref(1)


import { ref, onMounted } from 'vue';
import axios from 'axios';
const route = useRoute();
const ticket = ref({});

const fetchTickets = async () => {
  try {
    let config = {
      method: 'get',
      maxBodyLength: Infinity,
      url: 'https://65558d7284b36e3a431de9a5.mockapi.io/tiket/'+route.params.id,
      headers: { 
      }
    };
    const response = await axios.request(config)
    
    .then((response) => {
      console.log(response.data)   
      ticket.value = response.data;
    })
    .catch((error) => {
      console.log(error);
    })
    // ticket.value = response.data;

  } catch (error) {
    console.error('Error fetching tickets:', error);
  }
};

onMounted(fetchTickets);


</script>

<template>
  <div>
    <div class="flex gap32 p12-16 rounded-lg border border-solid border-dark-20">
      <Button @click="activeTab = 1" class="font-bold text16" :class="{ active: activeTab == 1 }">Deskripsi</Button>
      <Button @click="activeTab = 2" class="font-bold text16" :class="{ active: activeTab == 2 }">Band</Button>
      <Button @click="activeTab = 3" class="font-bold text16"
        :class="{ active: activeTab == 3 }">jadwal</Button>
    </div>

    <div class="mt-6 2xl:mt-5 xl:mt-4">

      <!-- Description -->
      <div v-show="activeTab == 1" class=" flex flex-col gap16">
        <p class="font-bold text24">Cerita</p>
        <p class="text16">{{ description?description:"-" }}</p>
      </div>

      <!-- band -->
      <div v-show="activeTab == 2" class=" flex flex-col gap16">
        <p class="font-bold text24">Band</p>
        <p class="text16">Untuk riwayat kepemilikan yang sudah terverifikasi oleh History Outlet dapat
          dilihat di bawah ini:
        </p>
      </div>

      <!-- jadwal -->
      <div v-show="activeTab == 3" class=" flex flex-col gap16">
        <p class="font-bold text24">Jadwal</p>
        <p class="text16"><span>Tanggal : </span>{{ ticket.tanggal?ticket.tanggal:"-" }}</p>
        <p class="text16"><span>Lokasi : </span>{{ ticket.lokasi?ticket.lokasi:"-" }}</p>


      </div>
    </div>
  </div>
</template>

<style scoped>
.active {
  background-color: #FFD41B;
  color: #222831;
}
</style>
