<script setup>
const props = defineProps({
  // tiket: Boolean,
  description :null,
  bidding :null,
})
const activeTab = ref(1)


// const products = ref({});
// const fetchProducts = async () => {
//   try {
//     let config = {
//       method: 'get',
//       maxBodyLength: Infinity,
//       url: 'https://6550a40f7d203ab6626e02b9.mockapi.io/lelang/'+route.params.id,
//       headers: { 
//       }
//     };
//     const response = await axios.request(config)
//     .then((response) => {
//       // console.log(response.data)   
//       Product.value = response.data
//     })
//     .catch((error) => {
//       console.log(error);
//     });

//   } catch (error) {
//     console.error('Error fetching tproducts:', error);
//   }
// };
// onMounted(fetchProducts);
</script>

<template>
  <div>
    <div class="flex gap32 p12-16 rounded-lg border border-solid border-dark-20">
      <Button @click="activeTab = 1" class="font-bold text16 text-dark-50" :class="{ active: activeTab == 1 }">Deskripsi
        Barang</Button>
      <Button @click="activeTab = 2" class="font-bold text16 text-dark-50" :class="{ active: activeTab == 2 }">History
        Kepemilikan</Button>
      <Button @click="activeTab = 3" class="font-bold text16 text-dark-50"
        :class="{ active: activeTab == 3 }">Sertifikasi</Button>
      <Button @click="activeTab = 4" class="font-bold text16 text-dark-50"
        :class="{ active: activeTab == 4 }">Bids</Button>
    </div>

    <div class="mt-6 2xl:mt-5 xl:mt-4">

      <!-- Description -->
      <div v-show="activeTab == 1" class=" flex flex-col gap16">
        <p class="font-bold text24">Deskripsi Barang</p>
        <p class="text16 ">{{ description?description:"-" }}</p>
      </div>
      <!-- {{ description }} -->
        {{ bidding }}
      <!-- History -->
      <div v-show="activeTab == 2" class=" flex flex-col gap16">
        <p class="font-bold text24">History Kepemilikan</p>
        <p class="text16 text-dark-50">Untuk riwayat kepemilikan yang sudah terverifikasi oleh History Outlet dapat
          dilihat di bawah ini:
        </p>
        <p class="text16 text-dark-50">Catatan: Jika pemilik lebih dari satu, maka pemilik nomor terakhir adalah pemilik
          barang ini.</p>

        <!-- Name -->
        <div class="flex items-center gap16">
          <img src="/img/slank.png" alt="User img" class="w-16 2xl:w-[52px] xl:w-11">
          <div class="flex flex-col gap-1 2xl:gap-[2px]">
            <p class="font-bold text24">Slank</p>
            <div class="flex items-center">
              <p class="mr-3 text16">Verified Owner</p>
              <nuxt-icon name="check_circle" class="text20 text-yellow-100" />
            </div>
            <p class="text16">Pemilik ke-1</p>
          </div>
        </div>
      </div>

      <!-- Certification -->
      <div v-show="activeTab == 3" class=" flex flex-col gap16">
        <p class="font-bold text24">Sertifikasi</p>
        <p class="text16 text-dark-50">Silahkan cek dibawah ini untuk memeriksa keaslian sertifikasi yang dipublikasikan
          oleh History Outlet.</p>

        <div class="flex flex-col gap-3 2xl:gap-2 p-4 2xl:p-3 bg-white shadow-32 rounded-lg max-w-fit">
          <p class="font-bold text16">Authentic Owner Certification</p>
          <div class="rounded-full h-2 w-[90%] bg-dark-100"></div>
          <div class="rounded-full h-2 w-[80%] bg-dark-100"></div>
          <div class="rounded-full h-2 w-[70%] bg-dark-100"></div>
          <div class="rounded-full h-2 w-[60%] bg-dark-100"></div>
          <div class="rounded-full h-2 w-[50%] bg-dark-100"></div>
        </div>
      </div>

      <!-- Bids -->
      <div v-show="activeTab == 4" class=" flex flex-col gap16">
        <div class="flex gap16 justify-between">
          <p class="font-bold text24">Bids</p>
          <Button class="text-dark-50 hover:text-dark-100 font-bold text16">Lihat Semua Bidder</Button>
        </div>

        <!-- Highest bid -->
        <div class="flex gap16 items-center">
          <img src="/img/user2.png" alt="Highest bid user" class="w-16 2xl:w-[52px] xl:w-11">
          <div class="flex flex-col gap-1 2xl:gap-[3px]">
            <p class="text-dark-50 text16">Bid tertinggi sementara:</p>
            <p class="font-bold text24">Agus Subagja</p>
            <p class="font-bold text24 text-green-100">Rp. 3.900.000</p>
          </div>
        </div>
        <div class="border border-solid border-dark-20"></div>
        <div class="flex gap16 items-center">
          <img src="/img/user2.png" alt="Highest bid user" class="w-16 2xl:w-[52px] xl:w-11">
          <div class="flex flex-col gap-1 2xl:gap-[3px]">
            <p class="text-dark-50 text16">10.30</p>
            <p class="font-bold text24">Agus Subagja</p>
            <p class="font-bold text24 text-green-100">Rp. 3.900.000</p>
          </div>
        </div>
        <div v-for="n in 5" :key="n" class="flex gap16 items-center">
          <img src="/img/user2.png" alt="Highest bid user" class="w-16 2xl:w-[52px] xl:w-11">
          <div class="flex flex-col gap-1 2xl:gap-[3px]">
            <p class="text-dark-50 text16">10.30</p>
            <p class="font-bold text24">Agus Subagja</p>
            <p class="font-bold text24 text-red-100">Rp. 3.900.000</p>
          </div>
        </div>
      </div>

    </div>
  </div>
</template>

<style scoped>
.active {
  background-color: #FFD41B;
  color: #222831;
}
</style>
