<template>
    <aside class="w-[270px] h-[1080px] bg-dark-500 text-white py-4" style="border-right: 1px solid var(--Dark-20, rgba(34, 40, 49, 0.20)); background: var(--Dark-Grey-100, #242424);">
        <!-- Navbar Konten -->
        <nav class="text-center">
      
      <div class="ml-[1rem]" style="display: flex; align-items: center;">
        <img src="~/public/icons/admin.svg"/>
        <span style="color: white; font-family: 'Plus Jakarta Sans'; font-size: 18px; font-style: normal; font-weight: 400; line-height: normal;" class="ml-3">Admin</span>
      </div>

      <p class="border-solid border-white/20 self-stretch h-px shrink-0 border-t border-b-0 mx-auto border-x-0 rounded-none mt-5" style="width: 210px;"></p>
      <p style="color: var(--White-50, rgba(255, 255, 255, 0.50)); font-family: 'Plus Jakarta Sans'; font-size: 18px; font-style: normal; font-weight: 400; line-height: normal;" class="text-left ml-6 mt-4">Menu Utama</p>  
      <ul>

    <!--Dashboard-->
    <li>
      <NuxtLink href="/dashboard">
        <button id="dashboardButton" class="bg-transparent hover:gold-20 text-white-50 py-2 px-4 mt-[32px] ml-4 hover:border-transparent rounded-lg flex items-center w-[237px] h-[56px] hover:text-white" :class="{ 'gold-20 text-white' : $route.path === '/dashboard' }" style="font-family: 'Plus Jakarta Sans'; font-size: 19px;">
          <!-- <img src="~/public/icons/dashboard.svg"/> -->
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" style="margin-right: 16px;">
            <g clip-path="url(#clip0_458_7075)">
              <path d="M3 13H11V3H3V13ZM3 21H11V15H3V21ZM13 21H21V11H13V21ZM13 3V9H21V3H13Z" fill="white" fill-opacity="0.5"/>
            </g>
            <defs>
              <clipPath id="clip0_458_7075">
                <rect width="24" height="24" fill="white" class="icons" />
              </clipPath>
            </defs>
          </svg>
           Dashboard
        </button>
      </NuxtLink>
    </li>
    
    <!--MitraButton-->
    <li>
      <NuxtLink href="/mitra">
        <button id="mitraButton" class="bg-transparent hover:gold-20 text-white-50 py-2 px-4 mt-[32px] ml-4 hover:border-transparent rounded-lg flex items-center w-[237px] h-[56px] hover:text-white" :class="{ 'gold-20 text-white' : $route.path === '/mitra' }" style="font-family: 'Plus Jakarta Sans'; font-size: 19px;">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" style="margin-right: 16px;">
            <g clip-path="url(#clip0_2120_59)">
              <path d="M12 12.75C13.63 12.75 15.07 13.14 16.24 13.65C17.32 14.13 18 15.21 18 16.38V18H6V16.39C6 15.21 6.68 14.13 7.76 13.66C8.93 13.14 10.37 12.75 12 12.75ZM4 13C5.1 13 6 12.1 6 11C6 9.9 5.1 9 4 9C2.9 9 2 9.9 2 11C2 12.1 2.9 13 4 13ZM5.13 14.1C4.76 14.04 4.39 14 4 14C3.01 14 2.07 14.21 1.22 14.58C0.48 14.9 0 15.62 0 16.43V18H4.5V16.39C4.5 15.56 4.73 14.78 5.13 14.1ZM20 13C21.1 13 22 12.1 22 11C22 9.9 21.1 9 20 9C18.9 9 18 9.9 18 11C18 12.1 18.9 13 20 13ZM24 16.43C24 15.62 23.52 14.9 22.78 14.58C21.93 14.21 20.99 14 20 14C19.61 14 19.24 14.04 18.87 14.1C19.27 14.78 19.5 15.56 19.5 16.39V18H24V16.43ZM12 6C13.66 6 15 7.34 15 9C15 10.66 13.66 12 12 12C10.34 12 9 10.66 9 9C9 7.34 10.34 6 12 6Z" fill="white" fill-opacity="0.5"/>
            </g>
            <defs>
              <clipPath id="clip0_2120_59">
                <rect width="24" height="24" fill="white"/>
              </clipPath>
            </defs>
          </svg>          
          Mitra
        </button>
      </NuxtLink>
    </li>
    
    <!--VerifikasiButton-->
    <li>
      <NuxtLink href="/verifikasi">
        <button id="verifikasiButton" class="bg-transparent hover:gold-20 text-white-50 py-2 px-4 mt-[32px] ml-4 hover:border-transparent rounded-lg flex items-center w-[237px] h-[56px] hover:text-white" :class="{ 'gold-20 text-white' : $route.path === '/verifikasi' }" style="font-family: 'Plus Jakarta Sans'; font-size: 19px;">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" style="margin-right: 16px;">
            <g clip-path="url(#clip0_1421_107)">
              <path d="M23 12L20.56 9.21L20.9 5.52L17.29 4.7L15.4 1.5L12 2.96L8.6 1.5L6.71 4.69L3.1 5.5L3.44 9.2L1 12L3.44 14.79L3.1 18.49L6.71 19.31L8.6 22.5L12 21.03L15.4 22.49L17.29 19.3L20.9 18.48L20.56 14.79L23 12ZM10.09 16.72L6.29 12.91L7.77 11.43L10.09 13.76L15.94 7.89L17.42 9.37L10.09 16.72Z" fill="white" fill-opacity="0.5"/>
            </g>
            <defs>
              <clipPath id="clip0_1421_107">
                <rect width="24" height="24" fill="white"/>
              </clipPath>
            </defs>
          </svg>
          Verifikasi
        </button>
      </NuxtLink>
    </li>
    </ul>
      
      <p class="border-solid border-white/20 self-stretch h-px shrink-0 border-t border-b-0 mx-auto border-x-0 rounded-none mt-10" style="width: 210px;"></p>
      <p style="color: var(--White-50, rgba(255, 255, 255, 0.50)); font-family: 'Plus Jakarta Sans'; font-size: 18px; font-style: normal; font-weight: 400; line-height: normal;" class="text-left ml-6 mt-10">Lainnya</p>
    
    <!--PengaturanButton-->
    <ul>
      <li>
        <NuxtLink href="/pengaturan">
          <button id="pengaturanButton" class="bg-transparent hover:gold-20 text-white-50 py-2 px-4 mt-[32px] ml-4 hover:border-transparent rounded-lg flex items-center w-[237px] h-[56px] hover:text-white" :class="{ 'gold-20 text-white' : $route.path === '/pengaturan' }" style="font-family: 'Plus Jakarta Sans'; font-size: 19px;">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" style="margin-right: 16px;">
              <g clip-path="url(#clip0_1421_276)">
                <path d="M19.14 12.94C19.18 12.64 19.2 12.33 19.2 12C19.2 11.68 19.18 11.36 19.13 11.06L21.16 9.47999C21.34 9.33999 21.39 9.06999 21.28 8.86999L19.36 5.54999C19.24 5.32999 18.99 5.25999 18.77 5.32999L16.38 6.28999C15.88 5.90999 15.35 5.58999 14.76 5.34999L14.4 2.80999C14.36 2.56999 14.16 2.39999 13.92 2.39999H10.08C9.83999 2.39999 9.64999 2.56999 9.60999 2.80999L9.24999 5.34999C8.65999 5.58999 8.11999 5.91999 7.62999 6.28999L5.23999 5.32999C5.01999 5.24999 4.76999 5.32999 4.64999 5.54999L2.73999 8.86999C2.61999 9.07999 2.65999 9.33999 2.85999 9.47999L4.88999 11.06C4.83999 11.36 4.79999 11.69 4.79999 12C4.79999 12.31 4.81999 12.64 4.86999 12.94L2.83999 14.52C2.65999 14.66 2.60999 14.93 2.71999 15.13L4.63999 18.45C4.75999 18.67 5.00999 18.74 5.22999 18.67L7.61999 17.71C8.11999 18.09 8.64999 18.41 9.23999 18.65L9.59999 21.19C9.64999 21.43 9.83999 21.6 10.08 21.6H13.92C14.16 21.6 14.36 21.43 14.39 21.19L14.75 18.65C15.34 18.41 15.88 18.09 16.37 17.71L18.76 18.67C18.98 18.75 19.23 18.67 19.35 18.45L21.27 15.13C21.39 14.91 21.34 14.66 21.15 14.52L19.14 12.94ZM12 15.6C10.02 15.6 8.39999 13.98 8.39999 12C8.39999 10.02 10.02 8.39999 12 8.39999C13.98 8.39999 15.6 10.02 15.6 12C15.6 13.98 13.98 15.6 12 15.6Z" fill="white" fill-opacity="0.5"/>
              </g>
              <defs>
                <clipPath id="clip0_1421_276">
                  <rect width="24" height="24" fill="white"/>
                </clipPath>
              </defs>
            </svg>
            Pengaturan
          </button>
        </NuxtLink>
      </li>
    </ul>  
  </nav>
</aside>
</template>


<script></script>

<style>
  .bg-transparent:hover svg path,
  .bg-transparent:active svg path {
    fill: #FFD849 !important;
  }
</style>




