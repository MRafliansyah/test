/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: 'class',
  content: [
    "./components/**/*.{js,vue,ts}",
    "./layouts/**/*.vue",
    "./pages/**/*.vue",
    "./plugins/**/*.{js,ts}",
    "./nuxt.config.{js,ts}",
    "./app.vue"
  ],
  theme: {
    screens: {
      '3xl': {'max': '1930px'},
      // => @media (max-width: 1930px) { ... }

      '2xl': {'max': '1600px'},
      // => @media (max-width: 1600px) { ... }

      'xl': {'max': '1400px'},
      // => @media (max-width: 1400px) { ... }

      'lg': {'max': '1023px'},
      // => @media (max-width: 1023px) { ... }

      'md': {'max': '767px'},
      // => @media (max-width: 767px) { ... }

      'sm': {'max': '639px'},
      // => @media (max-width: 639px) { ... }
    },
    theme: {
      colors: {
        transparent: 'transparent',
        current: 'currentColor',
        'white': '#ffffff',
        'purple': '#3f3cbb',
        'midnight': '#121063',
        'metal': '#565584',
        'tahiti': '#3ab7bf',
        'silver': '#ecebff',
        'bubble-gum': '#ff77e9',
        'bermuda': '#78dcca',
      },
    },
    boxShadow: {
      '32': '0px 0px 32px rgba(34, 40, 49, 0.24)',
      '16': '0px 0px 16px rgba(34, 40, 49, 0.24)'
    },
    extend: {
      colors: {
        dark: {
          20: '#22283133',
          50: '#22283180',
          100: '#222831'
        },
        darkGrey: {
          100: '#242424',
        },
        black:{
          100: '#090909',
        },
        white: {
          DEFAULT: '#ffffff',
          50: '#ffffff80',
          20: '#ffffff33',
        },
        yellow: {
          100: '#FFD41B'
        },
        blue: {
          100: '#2F80ED'
        },
        green: {
          100: '#379956'
        },
        red: {
          100: '#CD475C'
        },
        orange: {
          100: '#FFB563'
        },
        gold: {
          100: '#FFD849',
          200: '#FFC937',
          300: '#FFE88C',
          400: '#FFD546',
        },
        beige: '#F6F4F1',
      },
    },
  },
  plugins: [],
}

